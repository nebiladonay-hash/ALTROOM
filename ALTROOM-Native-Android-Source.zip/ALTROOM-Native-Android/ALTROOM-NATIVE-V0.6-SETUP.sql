-- Ensure the global owner role is accepted by older ALTROOM profiles schemas.
-- Existing role constraints mentioning the legacy member list are replaced idempotently.
DO $$
DECLARE
    c record;
BEGIN
    FOR c IN
        SELECT conname
        FROM pg_constraint
        WHERE conrelid = 'public.profiles'::regclass
          AND contype = 'c'
          AND pg_get_constraintdef(oid) ILIKE '%role%'
          AND pg_get_constraintdef(oid) ILIKE '%member%'
    LOOP
        EXECUTE format('ALTER TABLE public.profiles DROP CONSTRAINT %I', c.conname);
    END LOOP;

    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conrelid = 'public.profiles'::regclass
          AND conname = 'altroom_profiles_role_check'
    ) THEN
        ALTER TABLE public.profiles
            ADD CONSTRAINT altroom_profiles_role_check
            CHECK (role IN ('member', 'moderator', 'admin', 'owner'));
    END IF;
END $$;

-- ============================================================
-- PART 1: PROFILE-CUSTOMIZATION-SETUP.sql
-- ============================================================

-- ALTROOM profile customization + avatar storage setup
-- Run once in Supabase Dashboard > SQL Editor for the project used by ALTROOM.
-- This enables members to update presentation fields only; it never accepts a user ID,
-- role, approval status, or any other privileged account field.

ALTER TABLE public.profiles
    ADD COLUMN IF NOT EXISTS avatar_path text;

-- A separate public bucket is used for profile pictures (not private chat attachments).
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
    'profile-avatars',
    'profile-avatars',
    TRUE,
    4194304,
    ARRAY['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'image/avif']
)
ON CONFLICT (id) DO UPDATE SET
    public = TRUE,
    file_size_limit = 4194304,
    allowed_mime_types = ARRAY['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'image/avif'];

-- Authenticated users may upload only under their own user-ID folder.
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_policies
        WHERE schemaname = 'storage'
          AND tablename = 'objects'
          AND policyname = 'ALTROOM users upload their own profile avatar'
    ) THEN
        CREATE POLICY "ALTROOM users upload their own profile avatar"
        ON storage.objects
        FOR INSERT
        TO authenticated
        WITH CHECK (
            bucket_id = 'profile-avatars'
            AND (storage.foldername(name))[1] = (SELECT auth.uid()::text)
        );
    END IF;
END $$;

CREATE OR REPLACE FUNCTION public.update_my_altroom_profile(
    p_display_name text,
    p_bio text,
    p_interests text[],
    p_avatar_path text DEFAULT NULL,
    p_update_avatar boolean DEFAULT FALSE
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
    current_user_id uuid := auth.uid();
BEGIN
    IF current_user_id IS NULL THEN
        RAISE EXCEPTION 'You must be signed in to update your ALTROOM profile.';
    END IF;

    IF char_length(btrim(coalesce(p_display_name, ''))) < 2
       OR char_length(btrim(coalesce(p_display_name, ''))) > 40 THEN
        RAISE EXCEPTION 'Display name must be between 2 and 40 characters.';
    END IF;

    IF char_length(coalesce(p_bio, '')) > 200 THEN
        RAISE EXCEPTION 'Bio must be 200 characters or fewer.';
    END IF;

    IF coalesce(array_length(p_interests, 1), 0) > 12 THEN
        RAISE EXCEPTION 'You can add up to 12 interests.';
    END IF;

    IF EXISTS (
        SELECT 1
        FROM unnest(coalesce(p_interests, ARRAY[]::text[])) AS interest
        WHERE char_length(btrim(coalesce(interest, ''))) > 24
    ) THEN
        RAISE EXCEPTION 'Each interest must be 24 characters or fewer.';
    END IF;

    -- Reject avatar paths that attempt to point to another user's folder.
    IF coalesce(p_update_avatar, FALSE) AND p_avatar_path IS NOT NULL
       AND p_avatar_path NOT LIKE ('profile-avatars/' || current_user_id::text || '/%') THEN
        RAISE EXCEPTION 'Invalid profile picture path.';
    END IF;

    UPDATE public.profiles AS p
    SET display_name = btrim(p_display_name),
        bio = btrim(coalesce(p_bio, '')),
        interests = coalesce(p_interests, ARRAY[]::text[]),
        avatar_path = CASE WHEN p_update_avatar THEN p_avatar_path ELSE p.avatar_path END
    WHERE p.id = current_user_id;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Your ALTROOM profile could not be found.';
    END IF;
END;
$$;

REVOKE ALL ON FUNCTION public.update_my_altroom_profile(text, text, text[], text, boolean) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.update_my_altroom_profile(text, text, text[], text, boolean) FROM anon;
GRANT EXECUTE ON FUNCTION public.update_my_altroom_profile(text, text, text[], text, boolean) TO authenticated;


-- ============================================================
-- PART 2: ROOM-MODERATION-SETUP.sql
-- ============================================================

-- ALTROOM room safety and moderation migration
-- Run once in Supabase Dashboard > SQL Editor for the project configured in AltroomApi.kt.
-- New room creators become room owners automatically. Owners/moderators can remove messages,
-- restrict users from posting in that room, and promote trusted room co-moderators.
-- Any authenticated member can report a message. The app never embeds a service-role key.

-- Existing installations may not have a creator field. Add it without changing existing IDs.
ALTER TABLE public.channels
    ADD COLUMN IF NOT EXISTS created_by uuid REFERENCES public.profiles(id) ON DELETE SET NULL;

CREATE TABLE IF NOT EXISTS public.altroom_room_roles (
    channel_id text NOT NULL,
    user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    role text NOT NULL CHECK (role IN ('owner', 'moderator')),
    granted_by uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (channel_id, user_id)
);

CREATE TABLE IF NOT EXISTS public.altroom_room_bans (
    channel_id text NOT NULL,
    user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    moderator_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
    reason text NOT NULL DEFAULT 'Room safety restriction',
    created_at timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (channel_id, user_id)
);

CREATE TABLE IF NOT EXISTS public.altroom_room_reports (
    id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    channel_id text NOT NULL,
    message_id text NOT NULL,
    reporter_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    reported_user_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
    reason text NOT NULL DEFAULT 'Reported by a room member',
    status text NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'reviewed', 'dismissed', 'actioned')),
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS altroom_room_reports_open_idx
    ON public.altroom_room_reports (channel_id, status, created_at DESC);
CREATE INDEX IF NOT EXISTS altroom_room_bans_user_idx
    ON public.altroom_room_bans (channel_id, user_id);

ALTER TABLE public.altroom_room_roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.altroom_room_bans ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.altroom_room_reports ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.altroom_room_roles FROM anon, authenticated;
REVOKE ALL ON public.altroom_room_bans FROM anon, authenticated;
REVOKE ALL ON public.altroom_room_reports FROM anon, authenticated;

-- Record the authenticated creator on newly-created rooms.
CREATE OR REPLACE FUNCTION public.altroom_set_channel_creator()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
BEGIN
    IF NEW.created_by IS NULL AND auth.uid() IS NOT NULL THEN
        NEW.created_by := auth.uid();
    END IF;
    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS altroom_channels_set_creator ON public.channels;
CREATE TRIGGER altroom_channels_set_creator
BEFORE INSERT ON public.channels
FOR EACH ROW EXECUTE FUNCTION public.altroom_set_channel_creator();

-- Add the room creator as the first owner. This also supports rooms created via the existing RPC.
CREATE OR REPLACE FUNCTION public.altroom_register_channel_owner()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
BEGIN
    IF NEW.created_by IS NOT NULL THEN
        INSERT INTO public.altroom_room_roles (channel_id, user_id, role, granted_by)
        VALUES (NEW.id::text, NEW.created_by, 'owner', NEW.created_by)
        ON CONFLICT (channel_id, user_id) DO NOTHING;
    END IF;
    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS altroom_channels_register_owner ON public.channels;
CREATE TRIGGER altroom_channels_register_owner
AFTER INSERT ON public.channels
FOR EACH ROW EXECUTE FUNCTION public.altroom_register_channel_owner();

-- Global ALTROOM owners/admins/moderators and room-specific stewards can moderate a room.
CREATE OR REPLACE FUNCTION public.altroom_can_moderate_room(p_channel_id text)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
    SELECT auth.uid() IS NOT NULL AND (
        EXISTS (
            SELECT 1 FROM public.profiles p
            WHERE p.id = auth.uid() AND p.role IN ('owner', 'admin', 'moderator')
        )
        OR EXISTS (
            SELECT 1 FROM public.altroom_room_roles r
            WHERE r.channel_id = p_channel_id AND r.user_id = auth.uid()
              AND r.role IN ('owner', 'moderator')
        )
    );
$$;

CREATE OR REPLACE FUNCTION public.report_altroom_room_message(
    p_channel_id text,
    p_message_id text,
    p_reason text DEFAULT 'Reported by a room member'
)
RETURNS bigint
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
    v_reported_user uuid;
    v_report_id bigint;
BEGIN
    IF auth.uid() IS NULL THEN
        RAISE EXCEPTION 'Sign in before reporting a message.';
    END IF;

    SELECT m.user_id INTO v_reported_user
    FROM public.messages m
    WHERE m.id::text = p_message_id AND m.channel_id::text = p_channel_id
    LIMIT 1;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'That message no longer exists in this room.';
    END IF;

    INSERT INTO public.altroom_room_reports (channel_id, message_id, reporter_id, reported_user_id, reason)
    VALUES (p_channel_id, p_message_id, auth.uid(), v_reported_user, left(coalesce(nullif(btrim(p_reason), ''), 'Reported by a room member'), 300))
    RETURNING id INTO v_report_id;

    RETURN v_report_id;
END;
$$;

CREATE OR REPLACE FUNCTION public.delete_altroom_room_message(
    p_channel_id text,
    p_message_id text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
    v_deleted integer;
BEGIN
    IF NOT public.altroom_can_moderate_room(p_channel_id) THEN
        RAISE EXCEPTION 'Only this room''s owner, moderators, or an ALTROOM administrator can remove messages.';
    END IF;

    DELETE FROM public.messages m
    WHERE m.id::text = p_message_id AND m.channel_id::text = p_channel_id;
    GET DIAGNOSTICS v_deleted = ROW_COUNT;
    IF v_deleted = 0 THEN
        RAISE EXCEPTION 'That message no longer exists in this room.';
    END IF;

    UPDATE public.altroom_room_reports
       SET status = 'actioned'
     WHERE channel_id = p_channel_id AND message_id = p_message_id AND status = 'open';
END;
$$;

CREATE OR REPLACE FUNCTION public.ban_altroom_room_member(
    p_channel_id text,
    p_member_id uuid,
    p_reason text DEFAULT 'Room safety restriction'
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
BEGIN
    IF NOT public.altroom_can_moderate_room(p_channel_id) THEN
        RAISE EXCEPTION 'Only this room''s owner, moderators, or an ALTROOM administrator can restrict members.';
    END IF;
    IF p_member_id IS NULL OR p_member_id = auth.uid() THEN
        RAISE EXCEPTION 'You cannot restrict your own account.';
    END IF;
    IF EXISTS (
        SELECT 1 FROM public.altroom_room_roles r
        WHERE r.channel_id = p_channel_id AND r.user_id = p_member_id AND r.role = 'owner'
    ) THEN
        RAISE EXCEPTION 'A room owner cannot be restricted by another room moderator.';
    END IF;
    IF EXISTS (
        SELECT 1 FROM public.profiles p
        WHERE p.id = p_member_id AND p.role IN ('owner', 'admin', 'moderator')
    ) THEN
        RAISE EXCEPTION 'An ALTROOM administrator or global moderator cannot be restricted at room level.';
    END IF;

    INSERT INTO public.altroom_room_bans (channel_id, user_id, moderator_id, reason)
    VALUES (p_channel_id, p_member_id, auth.uid(), left(coalesce(nullif(btrim(p_reason), ''), 'Room safety restriction'), 300))
    ON CONFLICT (channel_id, user_id) DO UPDATE
      SET moderator_id = EXCLUDED.moderator_id, reason = EXCLUDED.reason, created_at = now();
END;
$$;

CREATE OR REPLACE FUNCTION public.promote_altroom_room_moderator(
    p_channel_id text,
    p_member_id uuid
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
BEGIN
    IF NOT public.altroom_can_moderate_room(p_channel_id) THEN
        RAISE EXCEPTION 'Only a room owner, room moderator, or ALTROOM administrator can promote co-moderators.';
    END IF;
    IF p_member_id IS NULL THEN
        RAISE EXCEPTION 'Choose a valid member.';
    END IF;
    IF NOT EXISTS (
        SELECT 1 FROM public.messages m
        WHERE m.channel_id::text = p_channel_id AND m.user_id = p_member_id
    ) THEN
        RAISE EXCEPTION 'A person must have participated in this room before being promoted.';
    END IF;

    INSERT INTO public.altroom_room_roles (channel_id, user_id, role, granted_by)
    VALUES (p_channel_id, p_member_id, 'moderator', auth.uid())
    ON CONFLICT (channel_id, user_id) DO UPDATE
      SET role = CASE WHEN public.altroom_room_roles.role = 'owner' THEN 'owner' ELSE 'moderator' END,
          granted_by = EXCLUDED.granted_by;
    DELETE FROM public.altroom_room_bans WHERE channel_id = p_channel_id AND user_id = p_member_id;
END;
$$;

CREATE OR REPLACE FUNCTION public.list_altroom_room_reports(p_channel_id text)
RETURNS TABLE(
    report_id bigint,
    message_id text,
    reported_user_id uuid,
    reason text,
    status text,
    message_body text,
    sender_name text
)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
BEGIN
    IF NOT public.altroom_can_moderate_room(p_channel_id) THEN
        RAISE EXCEPTION 'Only room stewards can view the report queue.';
    END IF;
    RETURN QUERY
    SELECT r.id, r.message_id, r.reported_user_id, r.reason, r.status,
           coalesce(nullif(m.body, ''), '[attachment or removed message]')::text,
           coalesce(p.display_name, 'ALTROOM member')::text
    FROM public.altroom_room_reports r
    LEFT JOIN public.messages m
      ON m.id::text = r.message_id AND m.channel_id::text = r.channel_id
    LEFT JOIN public.profiles p ON p.id = r.reported_user_id
    WHERE r.channel_id = p_channel_id
    ORDER BY CASE WHEN r.status = 'open' THEN 0 ELSE 1 END, r.created_at DESC
    LIMIT 200;
END;
$$;

CREATE OR REPLACE FUNCTION public.update_altroom_room_report_status(
    p_channel_id text,
    p_report_id bigint,
    p_status text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
BEGIN
    IF NOT public.altroom_can_moderate_room(p_channel_id) THEN
        RAISE EXCEPTION 'Only room stewards can update reports.';
    END IF;
    IF p_status NOT IN ('reviewed', 'dismissed', 'actioned') THEN
        RAISE EXCEPTION 'Choose a valid report status.';
    END IF;
    UPDATE public.altroom_room_reports
       SET status = p_status
     WHERE id = p_report_id AND channel_id = p_channel_id;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'That report could not be found in this room.';
    END IF;
END;
$$;

-- Enforce room restrictions server-side: hiding the room UI is not enough.
CREATE OR REPLACE FUNCTION public.altroom_reject_banned_room_message()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
BEGIN
    IF EXISTS (
        SELECT 1 FROM public.altroom_room_bans b
        WHERE b.channel_id = NEW.channel_id::text AND b.user_id::text = NEW.user_id::text
    ) THEN
        RAISE EXCEPTION 'You are restricted from posting in this room by its stewards.';
    END IF;
    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS altroom_reject_banned_room_message ON public.messages;
CREATE TRIGGER altroom_reject_banned_room_message
BEFORE INSERT ON public.messages
FOR EACH ROW EXECUTE FUNCTION public.altroom_reject_banned_room_message();

REVOKE ALL ON FUNCTION public.altroom_set_channel_creator() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.altroom_register_channel_owner() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.altroom_reject_banned_room_message() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.altroom_can_moderate_room(text) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.report_altroom_room_message(text, text, text) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.delete_altroom_room_message(text, text) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.ban_altroom_room_member(text, uuid, text) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.promote_altroom_room_moderator(text, uuid) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.list_altroom_room_reports(text) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.update_altroom_room_report_status(text, bigint, text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.altroom_can_moderate_room(text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.report_altroom_room_message(text, text, text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.delete_altroom_room_message(text, text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.ban_altroom_room_member(text, uuid, text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.promote_altroom_room_moderator(text, uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.list_altroom_room_reports(text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.update_altroom_room_report_status(text, bigint, text) TO authenticated;

-- Note for pre-existing rooms: room ownership is assigned automatically for rooms created
-- after this migration. Existing rooms with no creator metadata remain manageable by any
-- profile whose global role is admin/moderator until their owner is assigned by an admin.


-- ============================================================
-- PART 3: NATIVE-APP-V0.6-CAPACITY-AND-OPEN-SIGNUP.sql
-- ============================================================

-- ALTROOM Native Android 0.6: Open signup + scale-ready membership
-- Run after PROFILE-CUSTOMIZATION-SETUP.sql and ROOM-MODERATION-SETUP.sql.
-- Removes the old app-level 100-member limit without pretending that hosting plans have unlimited resources.
-- Adds explicit account_status so a suspended member cannot reactivate themselves through the signup RPC.

BEGIN;

ALTER TABLE public.profiles
    ADD COLUMN IF NOT EXISTS account_status text;

-- The legacy approved flag alone did not distinguish a never-activated signup from a deliberate suspension.
-- Preserve approved users as active and treat pre-existing unapproved records conservatively as suspended.
UPDATE public.profiles
SET account_status = CASE WHEN approved THEN 'active' ELSE 'suspended' END
WHERE account_status IS NULL;

ALTER TABLE public.profiles
    ALTER COLUMN account_status SET DEFAULT 'pending';
ALTER TABLE public.profiles
    ALTER COLUMN account_status SET NOT NULL;
ALTER TABLE public.profiles
    DROP CONSTRAINT IF EXISTS altroom_profiles_account_status_check;
ALTER TABLE public.profiles
    ADD CONSTRAINT altroom_profiles_account_status_check
    CHECK (account_status IN ('pending', 'active', 'suspended'));

-- New native-app signups are created pending; after auth has a session, the app calls activate_open_signup().
CREATE OR REPLACE FUNCTION public.handle_new_altroom_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
    v_display_name text;
    v_username text;
BEGIN
    v_display_name := left(coalesce(nullif(trim(new.raw_user_meta_data->>'display_name'), ''), 'New member'), 40);
    -- Use more UUID characters than older ALTROOM builds to keep auto-generated names collision-resistant at 1,000+ users.
    v_username := 'alt_' || replace(substr(new.id::text, 1, 12), '-', '');

    INSERT INTO public.profiles (id, username, display_name, approved, role, account_status)
    VALUES (new.id, v_username, v_display_name, false, 'member', 'pending')
    ON CONFLICT (id) DO NOTHING;
    RETURN new;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created_altroom ON auth.users;
CREATE TRIGGER on_auth_user_created_altroom
AFTER INSERT ON auth.users
FOR EACH ROW EXECUTE FUNCTION public.handle_new_altroom_user();

-- Deliberately no global count check: ALTROOM can grow beyond 1,000 profiles until real platform limits apply.
-- Only pending member accounts can self-activate. Staff must be activated by an administrator, and suspended accounts stay suspended.
CREATE OR REPLACE FUNCTION public.activate_open_signup()
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
    v_user uuid := auth.uid();
    v_role text;
    v_approved boolean;
    v_status text;
BEGIN
    IF v_user IS NULL THEN
        RAISE EXCEPTION 'Sign in before activating your ALTROOM account.';
    END IF;

    SELECT p.role, p.approved, p.account_status
    INTO v_role, v_approved, v_status
    FROM public.profiles p
    WHERE p.id = v_user
    FOR UPDATE;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Your ALTROOM profile could not be found. Sign out and sign in again.';
    END IF;

    IF COALESCE(v_approved, false) AND v_status = 'active' THEN
        RETURN true;
    END IF;

    IF v_status = 'suspended' THEN
        RAISE EXCEPTION 'This ALTROOM account is restricted. It cannot be reactivated by signing in.';
    END IF;

    IF COALESCE(v_role, 'member') <> 'member' THEN
        RAISE EXCEPTION 'This staff account requires an ALTROOM administrator to activate it.';
    END IF;

    UPDATE public.profiles
    SET approved = true, account_status = 'active'
    WHERE id = v_user AND role = 'member' AND account_status = 'pending';

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Your ALTROOM account could not be activated. An administrator may need to review it.';
    END IF;
    RETURN true;
END;
$$;

-- Backwards compatibility for pre-native builds. The invite value is intentionally ignored.
CREATE OR REPLACE FUNCTION public.redeem_invite(p_code text)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
BEGIN
    IF auth.uid() IS NULL THEN
        RAISE EXCEPTION 'Sign in before activating your ALTROOM account.';
    END IF;
    RETURN public.activate_open_signup();
END;
$$;

REVOKE ALL ON FUNCTION public.activate_open_signup() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.activate_open_signup() TO authenticated;
REVOKE ALL ON FUNCTION public.redeem_invite(text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.redeem_invite(text) TO authenticated;

-- Room-owner/global-staff moderation requires an active account. Individual room owners still get rights from altroom_room_roles.
CREATE OR REPLACE FUNCTION public.altroom_can_moderate_room(p_channel_id text)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
    SELECT auth.uid() IS NOT NULL AND (
        EXISTS (
            SELECT 1 FROM public.profiles p
            WHERE p.id = auth.uid()
              AND p.approved = true
              AND p.account_status = 'active'
              AND p.role IN ('owner', 'admin', 'moderator')
        )
        OR EXISTS (
            SELECT 1
            FROM public.altroom_room_roles r
            JOIN public.profiles p ON p.id = r.user_id
            WHERE r.channel_id = p_channel_id
              AND r.user_id = auth.uid()
              AND r.role IN ('owner', 'moderator')
              AND p.approved = true
              AND p.account_status = 'active'
        )
    );
$$;

REVOKE ALL ON FUNCTION public.altroom_can_moderate_room(text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.altroom_can_moderate_room(text) TO authenticated;

-- Keep older global owner consoles in sync with account_status when they suspend/restore members.
CREATE OR REPLACE FUNCTION public.altroom_owner_set_member_approval(p_member_id uuid, p_approved boolean)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM public.profiles p
        WHERE p.id = auth.uid() AND p.approved = true AND p.account_status = 'active' AND p.role = 'owner'
    ) THEN
        RAISE EXCEPTION 'Owner access only.';
    END IF;
    IF p_member_id IS NULL OR p_member_id = auth.uid() THEN
        RAISE EXCEPTION 'You cannot change your own access from this panel.';
    END IF;
    IF NOT EXISTS (
        SELECT 1 FROM public.profiles p
        WHERE p.id = p_member_id AND p.role = 'member'
    ) THEN
        RAISE EXCEPTION 'Member not found, or this account is protected staff.';
    END IF;

    UPDATE public.profiles
    SET approved = COALESCE(p_approved, false),
        account_status = CASE WHEN COALESCE(p_approved, false) THEN 'active' ELSE 'suspended' END
    WHERE id = p_member_id AND role = 'member';
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Member status was not changed.';
    END IF;
    IF NOT COALESCE(p_approved, false) AND to_regclass('public.room_members') IS NOT NULL THEN
        EXECUTE 'DELETE FROM public.room_members WHERE user_id = $1' USING p_member_id;
    END IF;
    RETURN true;
END;
$$;

REVOKE ALL ON FUNCTION public.altroom_owner_set_member_approval(uuid, boolean) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.altroom_owner_set_member_approval(uuid, boolean) TO authenticated;

COMMIT;

NOTIFY pgrst, 'reload schema';
