-- Run this one-time step after FOUNDER-SUPERADMIN-SAFETY-DESK.sql.
-- Replace the placeholder with the exact email used by YOUR existing ALTROOM login.
-- Run in the Supabase Dashboard SQL Editor as the Supabase project owner.
-- Do not publish this SQL or share account email unnecessarily.

DO $$
DECLARE
    v_owner_email text := lower(trim('YOUR_ALTROOM_LOGIN_EMAIL_HERE'));
    v_owner_id uuid;
BEGIN
    IF v_owner_email = '' OR v_owner_email = 'your_altroom_login_email_here' THEN
        RAISE EXCEPTION 'Replace YOUR_ALTROOM_LOGIN_EMAIL_HERE with the email used by your existing ALTROOM account, then run again.';
    END IF;

    SELECT u.id INTO v_owner_id
    FROM auth.users u
    WHERE lower(u.email) = v_owner_email
    LIMIT 1;

    IF v_owner_id IS NULL THEN
        RAISE EXCEPTION 'No Supabase auth account uses that email. Sign in to ALTROOM once, then run again.';
    END IF;

    UPDATE public.profiles
    SET role = 'owner', approved = TRUE, account_status = 'active'
    WHERE id = v_owner_id;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'The auth account exists but its ALTROOM profile was not found. Sign in to the app, then rerun this script.';
    END IF;
END $$;

NOTIFY pgrst, 'reload schema';
