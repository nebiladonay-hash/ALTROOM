-- ALTROOM Native Android 0.6: Open signup + scale-ready membership
-- Run after PROFILE-CUSTOMIZATION-SETUP.sql and ROOM-MODERATION-SETUP.sql.
-- Removes the old app-level 100-member limit without pretending that hosting plans have unlimited resources.
-- Adds explicit account_status so a suspended member cannot reactivate themselves through the signup RPC.

BEGIN;

ALTER TABLE public.profiles
    ADD COLUMN IF NOT EXISTS account_status text;

-- The legacy approved flag alone did not distinguish a never-activated signup from a deliberate suspension.
-- Preserve approved users as active and treat pre-existing unapproved records conservatively as suspended.
UPDATE public.profiles
SET account_status = CASE WHEN approved THEN 'active' ELSE 'suspended' END
WHERE account_status IS NULL;

ALTER TABLE public.profiles
    ALTER COLUMN account_status SET DEFAULT 'pending';
ALTER TABLE public.profiles
    ALTER COLUMN account_status SET NOT NULL;
ALTER TABLE public.profiles
    DROP CONSTRAINT IF EXISTS altroom_profiles_account_status_check;
ALTER TABLE public.profiles
    ADD CONSTRAINT altroom_profiles_account_status_check
    CHECK (account_status IN ('pending', 'active', 'suspended'));

-- New native-app signups are created pending; after auth has a session, the app calls activate_open_signup().
CREATE OR REPLACE FUNCTION public.handle_new_altroom_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
    v_display_name text;
    v_username text;
BEGIN
    v_display_name := left(coalesce(nullif(trim(new.raw_user_meta_data->>'display_name'), ''), 'New member'), 40);
    -- Use more UUID characters than older ALTROOM builds to keep auto-generated names collision-resistant at 1,000+ users.
    v_username := 'alt_' || replace(substr(new.id::text, 1, 12), '-', '');

    INSERT INTO public.profiles (id, username, display_name, approved, role, account_status)
    VALUES (new.id, v_username, v_display_name, false, 'member', 'pending')
    ON CONFLICT (id) DO NOTHING;
    RETURN new;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created_altroom ON auth.users;
CREATE TRIGGER on_auth_user_created_altroom
AFTER INSERT ON auth.users
FOR EACH ROW EXECUTE FUNCTION public.handle_new_altroom_user();

-- Deliberately no global count check: ALTROOM can grow beyond 1,000 profiles until real platform limits apply.
-- Only pending member accounts can self-activate. Staff must be activated by an administrator, and suspended accounts stay suspended.
CREATE OR REPLACE FUNCTION public.activate_open_signup()
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
    v_user uuid := auth.uid();
    v_role text;
    v_approved boolean;
    v_status text;
BEGIN
    IF v_user IS NULL THEN
        RAISE EXCEPTION 'Sign in before activating your ALTROOM account.';
    END IF;

    SELECT p.role, p.approved, p.account_status
    INTO v_role, v_approved, v_status
    FROM public.profiles p
    WHERE p.id = v_user
    FOR UPDATE;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Your ALTROOM profile could not be found. Sign out and sign in again.';
    END IF;

    IF COALESCE(v_approved, false) AND v_status = 'active' THEN
        RETURN true;
    END IF;

    IF v_status = 'suspended' THEN
        RAISE EXCEPTION 'This ALTROOM account is restricted. It cannot be reactivated by signing in.';
    END IF;

    IF COALESCE(v_role, 'member') <> 'member' THEN
        RAISE EXCEPTION 'This staff account requires an ALTROOM administrator to activate it.';
    END IF;

    UPDATE public.profiles
    SET approved = true, account_status = 'active'
    WHERE id = v_user AND role = 'member' AND account_status = 'pending';

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Your ALTROOM account could not be activated. An administrator may need to review it.';
    END IF;
    RETURN true;
END;
$$;

-- Backwards compatibility for pre-native builds. The invite value is intentionally ignored.
CREATE OR REPLACE FUNCTION public.redeem_invite(p_code text)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
BEGIN
    IF auth.uid() IS NULL THEN
        RAISE EXCEPTION 'Sign in before activating your ALTROOM account.';
    END IF;
    RETURN public.activate_open_signup();
END;
$$;

REVOKE ALL ON FUNCTION public.activate_open_signup() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.activate_open_signup() TO authenticated;
REVOKE ALL ON FUNCTION public.redeem_invite(text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.redeem_invite(text) TO authenticated;

-- Room-owner/global-staff moderation requires an active account. Individual room owners still get rights from altroom_room_roles.
CREATE OR REPLACE FUNCTION public.altroom_can_moderate_room(p_channel_id text)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
    SELECT auth.uid() IS NOT NULL AND (
        EXISTS (
            SELECT 1 FROM public.profiles p
            WHERE p.id = auth.uid()
              AND p.approved = true
              AND p.account_status = 'active'
              AND p.role IN ('owner', 'admin', 'moderator')
        )
        OR EXISTS (
            SELECT 1
            FROM public.altroom_room_roles r
            JOIN public.profiles p ON p.id = r.user_id
            WHERE r.channel_id = p_channel_id
              AND r.user_id = auth.uid()
              AND r.role IN ('owner', 'moderator')
              AND p.approved = true
              AND p.account_status = 'active'
        )
    );
$$;

REVOKE ALL ON FUNCTION public.altroom_can_moderate_room(text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.altroom_can_moderate_room(text) TO authenticated;

-- Keep older global owner consoles in sync with account_status when they suspend/restore members.
CREATE OR REPLACE FUNCTION public.altroom_owner_set_member_approval(p_member_id uuid, p_approved boolean)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM public.profiles p
        WHERE p.id = auth.uid() AND p.approved = true AND p.account_status = 'active' AND p.role = 'owner'
    ) THEN
        RAISE EXCEPTION 'Owner access only.';
    END IF;
    IF p_member_id IS NULL OR p_member_id = auth.uid() THEN
        RAISE EXCEPTION 'You cannot change your own access from this panel.';
    END IF;
    IF NOT EXISTS (
        SELECT 1 FROM public.profiles p
        WHERE p.id = p_member_id AND p.role = 'member'
    ) THEN
        RAISE EXCEPTION 'Member not found, or this account is protected staff.';
    END IF;

    UPDATE public.profiles
    SET approved = COALESCE(p_approved, false),
        account_status = CASE WHEN COALESCE(p_approved, false) THEN 'active' ELSE 'suspended' END
    WHERE id = p_member_id AND role = 'member';
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Member status was not changed.';
    END IF;
    IF NOT COALESCE(p_approved, false) AND to_regclass('public.room_members') IS NOT NULL THEN
        EXECUTE 'DELETE FROM public.room_members WHERE user_id = $1' USING p_member_id;
    END IF;
    RETURN true;
END;
$$;

REVOKE ALL ON FUNCTION public.altroom_owner_set_member_approval(uuid, boolean) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.altroom_owner_set_member_approval(uuid, boolean) TO authenticated;

COMMIT;

NOTIFY pgrst, 'reload schema';
