-- ALTROOM profile customization + avatar storage setup
-- Run once in Supabase Dashboard > SQL Editor for the project used by ALTROOM.
-- This enables members to update presentation fields only; it never accepts a user ID,
-- role, approval status, or any other privileged account field.

ALTER TABLE public.profiles
    ADD COLUMN IF NOT EXISTS avatar_path text;

-- A separate public bucket is used for profile pictures (not private chat attachments).
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
    'profile-avatars',
    'profile-avatars',
    TRUE,
    4194304,
    ARRAY['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'image/avif']
)
ON CONFLICT (id) DO UPDATE SET
    public = TRUE,
    file_size_limit = 4194304,
    allowed_mime_types = ARRAY['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'image/avif'];

-- Authenticated users may upload only under their own user-ID folder.
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_policies
        WHERE schemaname = 'storage'
          AND tablename = 'objects'
          AND policyname = 'ALTROOM users upload their own profile avatar'
    ) THEN
        CREATE POLICY "ALTROOM users upload their own profile avatar"
        ON storage.objects
        FOR INSERT
        TO authenticated
        WITH CHECK (
            bucket_id = 'profile-avatars'
            AND (storage.foldername(name))[1] = (SELECT auth.uid()::text)
        );
    END IF;
END $$;

CREATE OR REPLACE FUNCTION public.update_my_altroom_profile(
    p_display_name text,
    p_bio text,
    p_interests text[],
    p_avatar_path text DEFAULT NULL,
    p_update_avatar boolean DEFAULT FALSE
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
    current_user_id uuid := auth.uid();
BEGIN
    IF current_user_id IS NULL THEN
        RAISE EXCEPTION 'You must be signed in to update your ALTROOM profile.';
    END IF;

    IF char_length(btrim(coalesce(p_display_name, ''))) < 2
       OR char_length(btrim(coalesce(p_display_name, ''))) > 40 THEN
        RAISE EXCEPTION 'Display name must be between 2 and 40 characters.';
    END IF;

    IF char_length(coalesce(p_bio, '')) > 200 THEN
        RAISE EXCEPTION 'Bio must be 200 characters or fewer.';
    END IF;

    IF coalesce(array_length(p_interests, 1), 0) > 12 THEN
        RAISE EXCEPTION 'You can add up to 12 interests.';
    END IF;

    IF EXISTS (
        SELECT 1
        FROM unnest(coalesce(p_interests, ARRAY[]::text[])) AS interest
        WHERE char_length(btrim(coalesce(interest, ''))) > 24
    ) THEN
        RAISE EXCEPTION 'Each interest must be 24 characters or fewer.';
    END IF;

    -- Reject avatar paths that attempt to point to another user's folder.
    IF coalesce(p_update_avatar, FALSE) AND p_avatar_path IS NOT NULL
       AND p_avatar_path NOT LIKE ('profile-avatars/' || current_user_id::text || '/%') THEN
        RAISE EXCEPTION 'Invalid profile picture path.';
    END IF;

    UPDATE public.profiles AS p
    SET display_name = btrim(p_display_name),
        bio = btrim(coalesce(p_bio, '')),
        interests = coalesce(p_interests, ARRAY[]::text[]),
        avatar_path = CASE WHEN p_update_avatar THEN p_avatar_path ELSE p.avatar_path END
    WHERE p.id = current_user_id;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Your ALTROOM profile could not be found.';
    END IF;
END;
$$;

REVOKE ALL ON FUNCTION public.update_my_altroom_profile(text, text, text[], text, boolean) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.update_my_altroom_profile(text, text, text[], text, boolean) FROM anon;
GRANT EXECUTE ON FUNCTION public.update_my_altroom_profile(text, text, text[], text, boolean) TO authenticated;
