# ALTROOM Native Android — v0.7.0

This is the **native Kotlin + Jetpack Compose Android app**, not the ALTROOM website. It uses the existing Supabase project and keeps the client-side publishable key only; it does not contain a service-role key.

## v0.7.0 changes

- **Shorts:** full-bleed vertical clips, immersive screen, no in-app volume slider or persistent bottom navigation overlay, separated action rail/caption area, tap once to pause/resume and double-tap to like. Playback pauses when ALTROOM loses foreground focus and releases the player when the clip leaves composition. Phone media-volume keys still control sound.
- **Comments:** draggable Material 3 bottom sheet rather than a centered mini-dialog, with one-level threaded replies.
- **Session repair:** authenticated Supabase requests retry once after an HTTP 401 by refreshing the saved access token and storing Supabase's rotated refresh token. If the refresh token is no longer usable, the user is sent to sign in again instead of being stuck in a 401 loop.
- **Identity:** the yellow FOUNDER profile marker is replaced by a compact monochrome four-point ALTROOM mark; owner permissions are unchanged.
- **Messages and profiles:** cleaner private-chat presentation; existing content-sized message bubbles and the editable display name, avatar, bio, and interest tags remain.
- **Art wall:** artwork is shown as a creator-led social feed post with a share action.
- **Calls:** the unnecessary browser-fallback panel was removed. The app goes directly to the existing embedded call after Android permissions are granted. Calls still use the hosted Jitsi provider.
- **Existing features preserved:** community rooms, profile photos, private text/media messaging, read/unread indicators, Shorts likes/saves/sharing, art uploads, member safety tools, open signup, and account moderation.

## Required Supabase migration for replies

Run `SHORTS-COMMENT-REPLIES.sql` in the **same Supabase project configured in `AltroomApi.kt`**. It is idempotent and preserves current comments. A fresh database can instead apply the updated `SHORTS-INTERACTIONS-AND-BADGES.sql` after the original native setup.

Do **not** re-run `ALTROOM-NATIVE-V0.6-SETUP.sql`, the founder setup, or other base migrations just because you are installing this APK. Only run a migration if the feature it installs is not already present, and follow that script's ordering/comments.

## Build with GitHub Actions (phone-friendly)

1. Upload `ALTROOM-Native-Android-Source.zip` to the root of `nebiladonay-hash/altroom-native-android`, replacing the old file with the **exact same name**. Upload the ZIP itself, not the outer Upgrade Kit.
2. Keep the repository's existing `.github/workflows/build.yml` if it already triggers on that exact filename. Otherwise replace it with `ALTROOM-Android-Build-Workflow-v0.7.0.yml` from the upgrade kit, saved as `.github/workflows/build.yml`.
3. Open GitHub **Actions** and wait for the workflow to finish successfully. Download `ALTROOM-Android-APK-v0.7.0` only from a green run. The build workflow—not this source package—is what confirms Android compilation.
4. Install the APK from the successful artifact. If Android warns that it cannot update because the signing key differs, stop and check the signing/build history instead of repeatedly uninstalling the app.

## Honest limitations / known investigation boundary

- The source was checked for Kotlin parser/structural errors, but it **has not been confirmed by a full Android SDK/Gradle build here**. This environment does not have the Android SDK/Gradle cache and cannot reach the Gradle download host. GitHub Actions must pass before the APK should be installed.
- The old exact message `Update failed (401): JWS FAILED` was not found in the supplied native source, so that specific updater code path cannot be confirmed as repaired from this archive. This version does address the concrete `ALTROOM request failed (401): JWT expired` behavior for authenticated Supabase API requests.
- Calls have been streamlined but still run through hosted Jitsi. Replacing it with direct WebRTC is not a UI-only change: a WebRTC call needs an offer/answer + ICE signaling path and STUN/TURN configuration. The present update does not invent a backend or claim native peer-to-peer calls are already implemented.

## Safety and privacy

- Never put a Supabase service-role key into Android source or a client ZIP.
- Owner safety tools are server-checked; a badge or local preference does not grant owner permissions.
- Jitsi is a third-party hosted service and this implementation does not guarantee end-to-end private calls.


## v0.8.1 reliability and navigation update

- The Shorts page retains the normal Android system bars and the ALTROOM tab bar, so switching back to Rooms, DMs, Art, or Profile no longer requires the phone Back button.
- Shorts use fit scaling instead of aggressive zoom, and the right-side actions reserve space away from the caption area.
- Supabase access tokens are refreshed shortly before expiration; authenticated requests retry once after a 401 using the refreshed session. Safe GET requests retry briefly after common mobile-network resets. Write requests are not automatically duplicated.
- Founder Safety Desk includes a founder-only New Signups section with an unread badge and Android notification. Existing users are baseline-recorded on the first v0.8.1 check, so historical members are not falsely announced as new. The checker polls while the owner is using the app and catches up on resume.
- Temporary background connection failures are no longer displayed as raw exception strings.

The app still relies on the existing Supabase project and schema. No new SQL migration is required for these client-side changes. The APK should be accepted only after the v0.8.1 GitHub Actions build succeeds.
