# ALTROOM Native Android — Room Stewardship & UI Update 0.5.0-alpha

This is ALTROOM's native Kotlin + Jetpack Compose Android client. It connects to the existing Supabase project using the public publishable key; no service-role key is included.

## What's changed in 0.5.0-alpha

- **Room safety and moderation:** room creators become room owners; room owners/moderators can review room messages, remove harmful messages, restrict users from posting in a room, and promote trusted participants to room co-moderators. Any signed-in member can report a message. Server-side triggers enforce posting restrictions; hiding controls in the app alone is not treated as security.
- **No app-imposed 100-member cap:** approved profiles are fetched in pages of 500 rather than one fixed 100-profile query. DM conversations are paginated too. Actual capacity depends on the Supabase plan, database/storage limits, API configuration, and device/network performance; this app does not promise unlimited capacity.
- **Shorts:** creator avatars are larger and explicitly clickable, with a `VIEW PROFILE` prompt. The full-width solid black rectangles behind the Shorts header and creator/caption panel have been removed; the controls remain floating over the video.
- **Private chat spacing:** incoming and outgoing messages now use more distinct bubble widths/shapes, more vertical separation, and clearer alignment.
- **Signal Drop ✳ (new):** a quick-send row of small expressive signals (same frequency, I'm here, afterdark, need backup, I see you, just existing) for rooms and DMs. Signals are saved as ordinary messages, so this needs no extra table.
- **Existing features retained:** profile editing, avatar resolution, persistent unread DM indicators, private message alerts, the vertical Shorts feed and 30-second upload check, audio-message progress/playback speed/download, art wall, named rooms, and the hosted Jitsi call invitation flow.

## One-time setup

1. In Supabase Dashboard → SQL Editor, run `PROFILE-CUSTOMIZATION-SETUP.sql` if profile editing/avatar storage has not already been set up.
2. Run `ROOM-MODERATION-SETUP.sql`. This creates room-role/report/ban tables and secure RPCs, registers the creator as owner for newly created rooms, and enforces room restrictions on message inserts.
3. For rooms that existed before the moderation migration and have no creator metadata, existing global ALTROOM admins/moderators can still manage them. Their owners need to be assigned to those old rooms by an administrator; the migration intentionally does not let the first random member claim an existing room.

## Capacity note

There is no 100-profile ceiling in the client. Profiles are fetched page by page, and direct-message conversation lists are paginated. Supabase still has project/plan, database, storage, API, and rate limits. For a large community, monitor database load and storage use and enable appropriate RLS/realtime/push configuration before expecting high concurrent traffic.

## Notifications and calls

Message checks run approximately every 10 seconds while ALTROOM is open. WorkManager provides a background backup with a target interval of 15 minutes, but Android battery rules and network availability can delay it. This is **not real-time push delivery**. Reliable immediate push notifications require Firebase Cloud Messaging plus server-side delivery configuration.

Calls use the hosted Jitsi WebView invite-and-join flow, with a button to open the same meeting in the device browser if the embedded view does not start. This is not a custom private calling server or a guarantee of end-to-end privacy. Hosted meeting rooms may be accessible to anyone who obtains the room name.

## Build with GitHub Actions

1. Upload this archive's contents as the root file `ALTROOM-Native-Android-Source.zip` (that exact repository filename) and commit it.
2. Keep the existing root `.github/workflows/build.yml` workflow.
3. Open GitHub Actions, wait for a green build, and download the APK from that run's `ALTROOM-Android-APK` artifact.
4. Install the APK. If Android says it cannot install over the previous test build because it was signed differently, uninstall the older test app first; uninstalling clears its saved session, so keep your sign-in details.

## Verification status

This source has been edited in the runtime but **has not been compiled or tested on a physical device here** because Android SDK and Gradle are not installed in this runtime. The GitHub Actions run is the first compilation check. Test moderation only after running the SQL migration and test room management using two accounts.
