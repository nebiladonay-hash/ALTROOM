-- ALTROOM Shorts comment replies. Idempotent: safe to run once or re-run.
-- Run in the SAME Supabase project used by ALTROOM.
begin;

alter table public.short_video_comments
    add column if not exists parent_comment_id uuid
    references public.short_video_comments(id) on delete cascade;

create index if not exists short_video_comments_parent_idx
    on public.short_video_comments (parent_comment_id, created_at asc);

-- Replies may only point to a comment on the same clip.
create or replace function public.altroom_validate_short_comment_parent()
returns trigger
language plpgsql
security definer
set search_path = public, pg_temp
as $$
begin
    if new.parent_comment_id is not null and not exists (
        select 1 from public.short_video_comments parent
        where parent.id = new.parent_comment_id
          and parent.video_id = new.video_id
    ) then
        raise exception 'A reply must belong to the same Shorts clip as its parent comment.';
    end if;
    return new;
end;
$$;

drop trigger if exists altroom_validate_short_comment_parent_trigger on public.short_video_comments;
create trigger altroom_validate_short_comment_parent_trigger
before insert or update of parent_comment_id, video_id
on public.short_video_comments
for each row execute function public.altroom_validate_short_comment_parent();

commit;
