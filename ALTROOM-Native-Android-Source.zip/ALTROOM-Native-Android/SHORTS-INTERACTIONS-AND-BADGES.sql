-- ALTROOM Native v0.6.2: Shorts comments and saved clips.
-- Run once in Supabase SQL Editor after the original ALTROOM setup.
-- Existing videos and likes are preserved.

begin;

create table if not exists public.short_video_saves (
    video_id uuid not null references public.short_videos(id) on delete cascade,
    user_id uuid not null references public.profiles(id) on delete cascade,
    created_at timestamptz not null default now(),
    primary key (video_id, user_id)
);

create index if not exists short_video_saves_user_created_idx
    on public.short_video_saves (user_id, created_at desc);

alter table public.short_video_saves enable row level security;
grant select, insert, delete on public.short_video_saves to authenticated;

drop policy if exists "Members can read their own saved shorts" on public.short_video_saves;
create policy "Members can read their own saved shorts"
    on public.short_video_saves for select to authenticated
    using (user_id = auth.uid());

drop policy if exists "Members can save shorts for themselves" on public.short_video_saves;
create policy "Members can save shorts for themselves"
    on public.short_video_saves for insert to authenticated
    with check (user_id = auth.uid());

drop policy if exists "Members can unsave their own shorts" on public.short_video_saves;
create policy "Members can unsave their own shorts"
    on public.short_video_saves for delete to authenticated
    using (user_id = auth.uid());

create table if not exists public.short_video_comments (
    id uuid primary key default gen_random_uuid(),
    video_id uuid not null references public.short_videos(id) on delete cascade,
    user_id uuid not null references public.profiles(id) on delete cascade,
    body text not null check (char_length(btrim(body)) between 1 and 1000),
    created_at timestamptz not null default now(),
    parent_comment_id uuid references public.short_video_comments(id) on delete cascade
);

alter table public.short_video_comments
    add column if not exists parent_comment_id uuid references public.short_video_comments(id) on delete cascade;

create index if not exists short_video_comments_video_created_idx
    on public.short_video_comments (video_id, created_at asc);

create index if not exists short_video_comments_user_created_idx
    on public.short_video_comments (user_id, created_at desc);

create index if not exists short_video_comments_parent_idx
    on public.short_video_comments (parent_comment_id, created_at asc);

alter table public.short_video_comments enable row level security;
grant select, insert, delete on public.short_video_comments to authenticated;

drop policy if exists "Members can read shorts comments" on public.short_video_comments;
create policy "Members can read shorts comments"
    on public.short_video_comments for select to authenticated
    using (true);

drop policy if exists "Members can comment as themselves" on public.short_video_comments;
create policy "Members can comment as themselves"
    on public.short_video_comments for insert to authenticated
    with check (user_id = auth.uid());

drop policy if exists "Comment authors or clip owners can delete comments" on public.short_video_comments;
create policy "Comment authors or clip owners can delete comments"
    on public.short_video_comments for delete to authenticated
    using (
        user_id = auth.uid()
        or exists (
            select 1
            from public.short_videos as video
            where video.id = short_video_comments.video_id
              and video.user_id = auth.uid()
        )
    );

-- Replies must reference a comment on the same clip.
create or replace function public.altroom_validate_short_comment_parent()
returns trigger
language plpgsql
security definer
set search_path = public, pg_temp
as $$
begin
    if new.parent_comment_id is not null and not exists (
        select 1 from public.short_video_comments parent
        where parent.id = new.parent_comment_id
          and parent.video_id = new.video_id
    ) then
        raise exception 'A reply must belong to the same Shorts clip as its parent comment.';
    end if;
    return new;
end;
$$;

drop trigger if exists altroom_validate_short_comment_parent_trigger on public.short_video_comments;
create trigger altroom_validate_short_comment_parent_trigger
before insert or update of parent_comment_id, video_id
on public.short_video_comments
for each row execute function public.altroom_validate_short_comment_parent();

commit;
