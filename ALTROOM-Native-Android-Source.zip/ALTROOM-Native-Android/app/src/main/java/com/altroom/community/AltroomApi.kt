package com.altroom.community

// ALTROOM_BUILD_FINGERPRINT: 0.8.1

import android.net.Uri
import android.util.Base64
import android.content.SharedPreferences
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

private const val SUPABASE_URL = "https://kzehbmmaudxcgoezmxyf.supabase.co"
// This is the public client-side Supabase publishable key already used by ALTROOM's website.
// Never put a Supabase service-role key in an Android app.
private const val SUPABASE_PUBLISHABLE_KEY = "sb_publishable_GoCFt2-p_8y2F8HSmr8eOQ_-b8EARIR"

private class ApiResponseException(val statusCode: Int, val detail: String) : IOException("ALTROOM request failed ($statusCode): $detail")

class AltroomApi(private val sessionPrefs: SharedPreferences? = null) {
    private val refreshLock = Any()
    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(40, TimeUnit.SECONDS)
        .writeTimeout(40, TimeUnit.SECONDS)
        .build()

    private fun encode(value: String): String = URLEncoder.encode(value, Charsets.UTF_8.name())

    private fun request(
        method: String,
        path: String,
        token: String? = null,
        jsonBody: String? = null,
        binaryBody: ByteArray? = null,
        contentType: String = "application/json",
        extraHeaders: Map<String, String> = emptyMap()
    ): String {
        // Auth endpoints (sign-in, sign-up, token refresh) must never inherit a stale session.
        val authEndpoint = path.startsWith("auth/v1/")
        var firstToken = if (authEndpoint) {
            token?.takeIf { it.isNotBlank() }
        } else {
            sessionPrefs?.getString("access_token", "").orEmpty().takeIf { it.isNotBlank() }
                ?: token?.takeIf { it.isNotBlank() }
        }

        // Refresh shortly before expiry instead of letting the user hit the common JWT-expired
        // failure while scrolling, opening comments, or sending a message.
        if (!authEndpoint && !firstToken.isNullOrBlank() && jwtExpiresSoon(firstToken)) {
            firstToken = try { refreshAfterUnauthorized(firstToken) } catch (e: Exception) {
                // Let the normal request/retry path produce one clear, recoverable session error.
                firstToken
            }
        }

        return try {
            requestWithTransportRetry(method, path, firstToken, jsonBody, binaryBody, contentType, extraHeaders)
        } catch (e: ApiResponseException) {
            if (e.statusCode != 401 || authEndpoint) throw e
            val retryToken = try {
                refreshAfterUnauthorized(firstToken.orEmpty())
            } catch (refreshError: Exception) {
                throw IOException("Your ALTROOM session could not be renewed. Please sign in again if this continues.", refreshError)
            }
            try {
                requestWithTransportRetry(method, path, retryToken, jsonBody, binaryBody, contentType, extraHeaders)
            } catch (retryError: ApiResponseException) {
                if (retryError.statusCode == 401) {
                    throw IOException("ALTROOM could not renew this session. Please sign in again; your account and messages are unchanged.", retryError)
                }
                throw retryError
            }
        }
    }

    /** Retries safe reads after brief mobile-network drops; writes are never blindly duplicated. */
    private fun requestWithTransportRetry(
        method: String,
        path: String,
        token: String? = null,
        jsonBody: String? = null,
        binaryBody: ByteArray? = null,
        contentType: String = "application/json",
        extraHeaders: Map<String, String> = emptyMap()
    ): String {
        var lastError: IOException? = null
        repeat(3) { attempt ->
            try {
                return requestOnce(method, path, token, jsonBody, binaryBody, contentType, extraHeaders)
            } catch (e: ApiResponseException) {
                throw e
            } catch (e: IOException) {
                lastError = e
                if (!method.equals("GET", ignoreCase = true) || attempt >= 2 || !isTransientTransportError(e)) throw e
                try {
                    Thread.sleep(250L * (attempt + 1))
                } catch (interrupted: InterruptedException) {
                    Thread.currentThread().interrupt()
                    throw IOException("Request interrupted while reconnecting.", interrupted)
                }
            }
        }
        throw lastError ?: IOException("ALTROOM could not complete the request.")
    }

    private fun isTransientTransportError(error: Throwable): Boolean {
        var current: Throwable? = error
        while (current != null) {
            val message = current.message.orEmpty().lowercase()
            if (listOf(
                    "connection reset", "connection aborted", "socket closed", "unexpected end of stream",
                    "failed to connect", "timed out", "timeout", "network is unreachable", "software caused connection abort"
                ).any { it in message }) return true
            current = current.cause
        }
        return false
    }

    private fun jwtExpiresSoon(token: String): Boolean {
        return try {
            val parts = token.split('.')
            if (parts.size < 2) return false
            val payload = String(
                Base64.decode(parts[1], Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING),
                Charsets.UTF_8
            )
            val expiry = JSONObject(payload).optLong("exp", 0L)
            expiry > 0L && expiry <= System.currentTimeMillis() / 1000L + 45L
        } catch (_: Exception) {
            false
        }
    }

    private fun refreshAfterUnauthorized(expiredToken: String): String = synchronized(refreshLock) {
        val prefs = sessionPrefs ?: throw IOException("No saved ALTROOM session is available to refresh.")
        // If another request already refreshed the session, reuse its token rather than rotating
        // the refresh token twice. Supabase refresh tokens rotate on use.
        val latest = prefs.getString("access_token", "").orEmpty()
        if (latest.isNotBlank() && latest != expiredToken && !jwtExpiresSoon(latest)) return@synchronized latest
        val refreshToken = prefs.getString("refresh_token", "").orEmpty()
        if (refreshToken.isBlank()) throw IOException("No ALTROOM refresh token is saved.")
        try {
            val response = JSONObject(requestOnce(
                "POST",
                "auth/v1/token?grant_type=refresh_token",
                token = null,
                jsonBody = JSONObject().put("refresh_token", refreshToken).toString()
            ))
            val freshAccess = response.optString("access_token")
            val freshRefresh = response.optString("refresh_token")
            val freshUserId = response.optJSONObject("user")?.optString("id").orEmpty()
            if (freshAccess.isBlank() || freshRefresh.isBlank()) throw IOException("Supabase did not return a new session.")
            val edit = prefs.edit().putString("access_token", freshAccess).putString("refresh_token", freshRefresh)
            if (freshUserId.isNotBlank()) edit.putString("user_id", freshUserId)
            edit.apply()
            freshAccess
        } catch (e: Exception) {
            throw IOException("Your ALTROOM session could not be refreshed.", e)
        }
    }

    private fun requestOnce(
        method: String,
        path: String,
        token: String? = null,
        jsonBody: String? = null,
        binaryBody: ByteArray? = null,
        contentType: String = "application/json",
        extraHeaders: Map<String, String> = emptyMap()
    ): String {
        val url = if (path.startsWith("http")) path else "$SUPABASE_URL/$path"
        val body: RequestBody? = when {
            binaryBody != null -> binaryBody.toRequestBody(contentType.toMediaTypeOrNull())
            jsonBody != null -> jsonBody.toRequestBody("application/json; charset=utf-8".toMediaTypeOrNull())
            method in listOf("POST", "PUT", "PATCH") -> ByteArray(0).toRequestBody(null)
            else -> null
        }
        val builder = Request.Builder().url(url)
            .header("apikey", SUPABASE_PUBLISHABLE_KEY)
            .header("Accept", "application/json")
        // A publishable key is not a JWT. Only a real access token belongs in Authorization.
        if (!token.isNullOrBlank()) builder.header("Authorization", "Bearer $token")
        extraHeaders.forEach { (k, v) -> builder.header(k, v) }
        when (method.uppercase()) {
            "GET" -> builder.get()
            "POST" -> builder.post(body ?: ByteArray(0).toRequestBody(null))
            "PATCH" -> builder.patch(body ?: ByteArray(0).toRequestBody(null))
            "PUT" -> builder.put(body ?: ByteArray(0).toRequestBody(null))
            "DELETE" -> builder.delete(body)
            else -> throw IllegalArgumentException("Unsupported request method")
        }
        http.newCall(builder.build()).execute().use { response ->
            val responseText = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val reason = try {
                    val obj = JSONObject(responseText)
                    obj.optString("msg").ifBlank { obj.optString("message") }
                        .ifBlank { obj.optString("error_description") }
                        .ifBlank { obj.optString("error") }
                } catch (_: Exception) { "" }
                val detail = reason.ifBlank { responseText.take(500) }.ifBlank { response.message }
                throw ApiResponseException(response.code, detail)
            }
            return responseText
        }
    }

    suspend fun signIn(email: String, password: String): AuthResult = withContext(Dispatchers.IO) {
        val data = JSONObject(request("POST", "auth/v1/token?grant_type=password", jsonBody = JSONObject()
            .put("email", email.trim()).put("password", password).toString()))
        AuthResult(data.optString("access_token"), data.optJSONObject("user")?.optString("id").orEmpty(), data.optString("refresh_token"))
    }

    suspend fun refreshSession(refreshToken: String): AuthResult = withContext(Dispatchers.IO) {
        val data = JSONObject(request("POST", "auth/v1/token?grant_type=refresh_token", jsonBody = JSONObject().put("refresh_token", refreshToken).toString()))
        AuthResult(data.optString("access_token"), data.optJSONObject("user")?.optString("id").orEmpty(), data.optString("refresh_token"))
    }

    suspend fun signUp(displayName: String, email: String, password: String): AuthResult = withContext(Dispatchers.IO) {
        val metadata = JSONObject().put("display_name", displayName.trim())
        val payload = JSONObject().put("email", email.trim()).put("password", password).put("data", metadata)
        val data = JSONObject(request("POST", "auth/v1/signup", jsonBody = payload.toString()))
        val user = data.optJSONObject("user") ?: data
        AuthResult(data.optString("access_token"), user.optString("id"), data.optString("refresh_token"))
    }

    /** Activate only a pending open-signup account. Server-side account_status protects suspended users. */
    suspend fun activateOpenSignup(token: String) = withContext(Dispatchers.IO) {
        request("POST", "rest/v1/rpc/activate_open_signup", token, "{}")
    }

    /** Legacy compatibility for older builds; new native builds never ask for an invite code. */
    suspend fun redeemInvite(token: String, code: String) = withContext(Dispatchers.IO) {
        request("POST", "rest/v1/rpc/redeem_invite", token, JSONObject().put("p_code", code.trim()).toString())
    }

    suspend fun profile(token: String, userId: String): AltroomProfile = withContext(Dispatchers.IO) {
        val rows = JSONArray(request("GET", "rest/v1/profiles?select=id,username,display_name,bio,interests,approved,role,avatar_path&id=eq.${encode(userId)}&limit=1", token))
        if (rows.length() == 0) throw IOException("Your ALTROOM profile hasn't been created yet. Sign out and sign in again.")
        profileFrom(rows.getJSONObject(0), token)
    }

    suspend fun rooms(token: String): List<AltroomRoom> = withContext(Dispatchers.IO) {
        val rows = JSONArray(request("GET", "rest/v1/channels?select=id,slug,name,description&order=name.asc", token))
        (0 until rows.length()).map { i -> rows.getJSONObject(i).let { AltroomRoom(it.optString("id"), it.optString("slug"), it.optString("name"), it.optString("description")) } }
    }

    suspend fun joinRoom(token: String, roomId: String) = withContext(Dispatchers.IO) {
        request("POST", "rest/v1/rpc/join_altroom_room", token, JSONObject().put("p_channel_id", roomId).toString())
    }

    suspend fun createRoom(token: String, name: String, description: String): String = withContext(Dispatchers.IO) {
        val raw = request("POST", "rest/v1/rpc/create_altroom_channel", token,
            JSONObject().put("p_name", name.trim()).put("p_description", description.trim().ifBlank { JSONObject.NULL }).toString())
        val id = try {
            val arr = JSONArray(raw)
            if (arr.length() > 0) arr.getJSONObject(0).optString("id") else ""
        } catch (_: Exception) {
            try { JSONObject(raw).optString("id") } catch (_: Exception) { raw.trim().trim('"') }
        }
        if (id.isBlank() || id == "null") throw IOException("ALTROOM did not return the new room ID. Refresh the room list.")
        id
    }

    suspend fun canModerateRoom(token: String, roomId: String): Boolean = withContext(Dispatchers.IO) {
        request("POST", "rest/v1/rpc/altroom_can_moderate_room", token, JSONObject().put("p_channel_id", roomId).toString()).trim().equals("true", ignoreCase = true)
    }

    suspend fun reportRoomMessage(token: String, roomId: String, messageId: String, reason: String) = withContext(Dispatchers.IO) {
        request("POST", "rest/v1/rpc/report_altroom_room_message", token,
            JSONObject().put("p_channel_id", roomId).put("p_message_id", messageId).put("p_reason", reason.take(300)).toString())
    }

    suspend fun deleteRoomMessage(token: String, roomId: String, messageId: String) = withContext(Dispatchers.IO) {
        // Room owner/moderator deletion; the RPC independently checks room-scoped privileges.
        request("POST", "rest/v1/rpc/delete_altroom_room_message", token,
            JSONObject().put("p_channel_id", roomId).put("p_message_id", messageId).toString())
    }

    suspend fun roomReports(token: String, roomId: String): List<RoomModerationReport> = withContext(Dispatchers.IO) {
        val rows = JSONArray(request("POST", "rest/v1/rpc/list_altroom_room_reports", token,
            JSONObject().put("p_channel_id", roomId).toString()))
        (0 until rows.length()).map { i ->
            val o = rows.getJSONObject(i)
            RoomModerationReport(
                o.optString("report_id"), o.optString("message_id"), o.optString("reported_user_id").takeUnless { it == "null" }.orEmpty(),
                o.optString("reason"), o.optString("status"), o.optString("message_body"), o.optString("sender_name")
            )
        }
    }

    suspend fun updateRoomReportStatus(token: String, roomId: String, reportId: String, status: String) = withContext(Dispatchers.IO) {
        request("POST", "rest/v1/rpc/update_altroom_room_report_status", token,
            JSONObject().put("p_channel_id", roomId).put("p_report_id", reportId.toLongOrNull() ?: throw IOException("Invalid report ID."))
                .put("p_status", status).toString())
    }

    suspend fun banRoomMember(token: String, roomId: String, memberId: String, reason: String) = withContext(Dispatchers.IO) {
        request("POST", "rest/v1/rpc/ban_altroom_room_member", token,
            JSONObject().put("p_channel_id", roomId).put("p_member_id", memberId).put("p_reason", reason.take(300)).toString())
    }

    suspend fun promoteRoomModerator(token: String, roomId: String, memberId: String) = withContext(Dispatchers.IO) {
        request("POST", "rest/v1/rpc/promote_altroom_room_moderator", token,
            JSONObject().put("p_channel_id", roomId).put("p_member_id", memberId).toString())
    }

    suspend fun roomMessages(token: String, roomId: String): List<AltroomMessage> = withContext(Dispatchers.IO) {
        val query = "rest/v1/messages?select=id,channel_id,user_id,kind,body,media_path,sticker_text,sticker_emoji,created_at,profiles(display_name,username)&channel_id=eq.${encode(roomId)}&order=created_at.asc&limit=100"
        val rows = JSONArray(request("GET", query, token))
        (0 until rows.length()).map { i -> messageFrom(rows.getJSONObject(i), token) }
    }

    suspend fun sendRoomMessage(token: String, roomId: String, userId: String, body: String) = withContext(Dispatchers.IO) {
        val payload = JSONObject().put("channel_id", roomId.toLongOrNull() ?: roomId)
            .put("user_id", userId).put("kind", "text").put("body", body.trim())
        request("POST", "rest/v1/messages", token, payload.toString(), extraHeaders = mapOf("Prefer" to "return=minimal"))
    }

    suspend fun sendRoomMedia(token: String, roomId: String, userId: String, kind: String, bytes: ByteArray, mime: String, extension: String) = withContext(Dispatchers.IO) {
        val path = "$userId/messages/${System.currentTimeMillis()}.$extension"
        request("POST", "storage/v1/object/chat-media/${Uri.encode(path, "/")}", token, binaryBody = bytes, contentType = mime,
            extraHeaders = mapOf("x-upsert" to "false", "cache-control" to "3600"))
        try {
            val payload = JSONObject().put("channel_id", roomId.toLongOrNull() ?: roomId).put("user_id", userId)
                .put("kind", kind).put("body", "").put("media_path", path)
            request("POST", "rest/v1/messages", token, payload.toString(), extraHeaders = mapOf("Prefer" to "return=minimal"))
        } catch (e: Exception) {
            try { request("DELETE", "storage/v1/object/chat-media", token, JSONObject().put("prefixes", JSONArray().put(path)).toString()) } catch (_: Exception) {}
            throw e
        }
    }

    /** Fetch all approved profiles in pages. The app itself no longer imposes a 100-member ceiling. */
    suspend fun members(token: String): List<AltroomProfile> = withContext(Dispatchers.IO) {
        val result = mutableListOf<AltroomProfile>()
        val pageSize = 500
        var offset = 0
        while (true) {
            val query = "rest/v1/profiles?select=id,username,display_name,bio,interests,approved,role,avatar_path&approved=eq.true&order=display_name.asc,id.asc&limit=$pageSize&offset=$offset"
            val rows = JSONArray(request("GET", query, token))
            for (i in 0 until rows.length()) result += profileFrom(rows.getJSONObject(i), token)
            if (rows.length() < pageSize) break
            offset += pageSize
        }
        result
    }

    /** Paginate conversations too, so a member with many DMs isn't silently capped at 60. */
    suspend fun conversations(token: String, userId: String): List<PrivateConversation> = withContext(Dispatchers.IO) {
        val result = mutableListOf<PrivateConversation>()
        val orExpr = "(user_a.eq.$userId,user_b.eq.$userId)"
        val pageSize = 500
        var offset = 0
        while (true) {
            val query = "rest/v1/private_conversations?select=id,user_a,user_b,last_message_at&or=${encode(orExpr)}&order=last_message_at.desc.nullslast,id.asc&limit=$pageSize&offset=$offset"
            val rows = JSONArray(request("GET", query, token))
            for (i in 0 until rows.length()) {
                val row = rows.getJSONObject(i)
                result += PrivateConversation(row.optString("id"), row.optString("user_a"), row.optString("user_b"), row.optString("last_message_at"))
            }
            if (rows.length() < pageSize) break
            offset += pageSize
        }
        result
    }

    suspend fun openConversation(token: String, otherUserId: String): String = withContext(Dispatchers.IO) {
        val result = request("POST", "rest/v1/rpc/open_private_conversation", token, JSONObject().put("p_other_user", otherUserId).toString()).trim()
        if (result.startsWith("{")) {
            val obj = JSONObject(result)
            obj.optString("id").ifBlank { obj.optString("conversation_id") }
        } else result.trim('"')
    }

    suspend fun privateMessages(token: String, conversationId: String): List<AltroomMessage> = withContext(Dispatchers.IO) {
        val query = "rest/v1/private_messages?select=id,conversation_id,sender_id,kind,body,media_path,created_at,profiles:profiles!private_messages_sender_id_fkey(display_name,username)&conversation_id=eq.${encode(conversationId)}&order=created_at.asc&limit=100"
        val rows = JSONArray(request("GET", query, token))
        (0 until rows.length()).map { i ->
            val o = rows.getJSONObject(i)
            val p = o.optJSONObject("profiles")
            AltroomMessage(o.optString("id"), conversationId, o.optString("sender_id"), o.optString("kind"), o.optString("body"), o.optString("created_at"), p?.optString("display_name").orEmpty().ifBlank { "ALTROOM member" }, p?.optString("username").orEmpty(), o.optString("media_path"), mediaUrl = signedUrl(token, "private-chat-media", o.optString("media_path")))
        }
    }

    suspend fun sendPrivateMessage(token: String, conversationId: String, userId: String, body: String) = withContext(Dispatchers.IO) {
        val payload = JSONObject().put("conversation_id", conversationId).put("sender_id", userId).put("kind", "text").put("body", body.trim())
        request("POST", "rest/v1/private_messages", token, payload.toString(), extraHeaders = mapOf("Prefer" to "return=minimal"))
    }

    suspend fun sendPrivateMedia(token: String, conversationId: String, userId: String, kind: String, bytes: ByteArray, mime: String, extension: String) = withContext(Dispatchers.IO) {
        // Direct messages use their own private bucket and participant-scoped path.
        // Expected layout: conversation_id / uploader_user_id / filename.
        val path = "$conversationId/$userId/messages/${System.currentTimeMillis()}.$extension"
        request("POST", "storage/v1/object/private-chat-media/${Uri.encode(path, "/")}", token, binaryBody = bytes, contentType = mime,
            extraHeaders = mapOf("x-upsert" to "false", "cache-control" to "3600"))
        try {
            val payload = JSONObject().put("conversation_id", conversationId).put("sender_id", userId)
                .put("kind", kind).put("body", "").put("media_path", path)
            request("POST", "rest/v1/private_messages", token, payload.toString(), extraHeaders = mapOf("Prefer" to "return=minimal"))
        } catch (e: Exception) {
            try { request("DELETE", "storage/v1/object/private-chat-media", token, JSONObject().put("prefixes", JSONArray().put(path)).toString()) } catch (_: Exception) {}
            throw e
        }
    }

    suspend fun shortClips(token: String, userId: String): List<ShortClip> = withContext(Dispatchers.IO) {
        val rows = JSONArray(request("GET", "rest/v1/short_videos?select=id,user_id,caption,media_path,created_at&order=created_at.desc&limit=50", token))
        val base = (0 until rows.length()).map { i -> rows.getJSONObject(i) }
        val likes = if (base.isNotEmpty()) {
            val ids = base.map { it.optString("id") }.filter { it.isNotBlank() }
            val inExpr = "(${ids.joinToString(",")})"
            try { JSONArray(request("GET", "rest/v1/short_video_likes?select=video_id,user_id&video_id=in.${encode(inExpr)}", token)) } catch (_: Exception) { JSONArray() }
        } else JSONArray()
        val likeRows = mutableMapOf<String, MutableList<String>>()
        for (i in 0 until likes.length()) {
            val row = likes.getJSONObject(i)
            likeRows.getOrPut(row.optString("video_id")) { mutableListOf() }.add(row.optString("user_id"))
        }
        val ids = base.map { it.optString("id") }.filter { it.isNotBlank() }
        val inExpr = "(${ids.joinToString(",")})"
        val saves = if (ids.isNotEmpty()) {
            try { JSONArray(request("GET", "rest/v1/short_video_saves?select=video_id,user_id&video_id=in.${encode(inExpr)}", token)) } catch (_: Exception) { JSONArray() }
        } else JSONArray()
        val saveRows = mutableMapOf<String, MutableSet<String>>()
        for (i in 0 until saves.length()) {
            val row = saves.getJSONObject(i)
            saveRows.getOrPut(row.optString("video_id")) { mutableSetOf() }.add(row.optString("user_id"))
        }
        val commentCounts = mutableMapOf<String, Int>()
        if (ids.isNotEmpty()) {
            try {
                val comments = JSONArray(request("GET", "rest/v1/short_video_comments?select=video_id&video_id=in.${encode(inExpr)}", token))
                for (i in 0 until comments.length()) {
                    val videoId = comments.getJSONObject(i).optString("video_id")
                    commentCounts[videoId] = (commentCounts[videoId] ?: 0) + 1
                }
            } catch (_: Exception) { /* Interaction migration may not have been applied yet. */ }
        }
        base.map { o ->
            val id = o.optString("id")
            val likers = likeRows[id].orEmpty()
            val savers = saveRows[id].orEmpty()
            ShortClip(
                id, o.optString("user_id"), o.optString("caption"), o.optString("created_at"),
                signedUrl(token, "chat-media", o.optString("media_path")), likers.size, userId in likers,
                userId in savers, commentCounts[id] ?: 0
            )
        }
    }

    suspend fun toggleLike(token: String, userId: String, videoId: String, currentlyLiked: Boolean) = withContext(Dispatchers.IO) {
        if (currentlyLiked) {
            request("DELETE", "rest/v1/short_video_likes?video_id=eq.${encode(videoId)}&user_id=eq.${encode(userId)}", token, extraHeaders = mapOf("Prefer" to "return=minimal"))
        } else {
            request("POST", "rest/v1/short_video_likes", token, JSONObject().put("video_id", videoId).put("user_id", userId).toString(), extraHeaders = mapOf("Prefer" to "return=minimal"))
        }
    }

    suspend fun toggleShortSave(token: String, userId: String, videoId: String, currentlySaved: Boolean) = withContext(Dispatchers.IO) {
        if (currentlySaved) {
            request("DELETE", "rest/v1/short_video_saves?video_id=eq.${encode(videoId)}&user_id=eq.${encode(userId)}", token, extraHeaders = mapOf("Prefer" to "return=minimal"))
        } else {
            request("POST", "rest/v1/short_video_saves", token, JSONObject().put("video_id", videoId).put("user_id", userId).toString(), extraHeaders = mapOf("Prefer" to "return=minimal"))
        }
    }

    suspend fun shortComments(token: String, videoId: String): List<ShortClipComment> = withContext(Dispatchers.IO) {
        val query = "rest/v1/short_video_comments?select=id,video_id,user_id,body,created_at,parent_comment_id,profiles:profiles!short_video_comments_user_id_fkey(display_name,username)&video_id=eq.${encode(videoId)}&order=created_at.asc&limit=100"
        val rows = JSONArray(request("GET", query, token))
        (0 until rows.length()).map { i ->
            val o = rows.getJSONObject(i)
            val profile = o.optJSONObject("profiles")
            ShortClipComment(
                o.optString("id"), o.optString("video_id"), o.optString("user_id"), o.optString("body"),
                o.optString("created_at"), profile?.optString("display_name").orEmpty().ifBlank { "ALTROOM member" },
                profile?.optString("username").orEmpty(), o.optString("parent_comment_id").takeUnless { it.isBlank() || it == "null" }
            )
        }
    }

    suspend fun postShortComment(token: String, userId: String, videoId: String, body: String, parentCommentId: String? = null) = withContext(Dispatchers.IO) {
        val text = body.trim()
        if (text.isBlank()) throw IOException("Write a comment first.")
        if (text.length > 1000) throw IOException("Comments must be 1,000 characters or fewer.")
        val payload = JSONObject().put("video_id", videoId).put("user_id", userId).put("body", text)
        if (!parentCommentId.isNullOrBlank()) payload.put("parent_comment_id", parentCommentId)
        request(
            "POST", "rest/v1/short_video_comments", token,
            payload.toString(),
            extraHeaders = mapOf("Prefer" to "return=minimal")
        )
    }

    suspend fun gallery(token: String): List<AltroomArtwork> = withContext(Dispatchers.IO) {
        val rows = JSONArray(request("GET", "rest/v1/artworks?select=id,user_id,title,caption,media_path,created_at,profiles(display_name,username)&order=created_at.desc&limit=60", token))
        (0 until rows.length()).map { i ->
            val o = rows.getJSONObject(i)
            val p = o.optJSONObject("profiles")
            AltroomArtwork(o.optString("id"), o.optString("user_id"), o.optString("title"), o.optString("caption"), o.optString("created_at"), p?.optString("display_name").orEmpty().ifBlank { "ALTROOM member" }, p?.optString("username").orEmpty(), signedUrl(token, "chat-media", o.optString("media_path")))
        }
    }

    suspend fun uploadArtwork(token: String, userId: String, title: String, caption: String, bytes: ByteArray, mime: String, extension: String) = withContext(Dispatchers.IO) {
        val path = "$userId/artwork-${System.currentTimeMillis()}.$extension"
        request("POST", "storage/v1/object/chat-media/${Uri.encode(path, "/")}", token, binaryBody = bytes, contentType = mime,
            extraHeaders = mapOf("x-upsert" to "false", "cache-control" to "3600"))
        try {
            request("POST", "rest/v1/artworks", token, JSONObject().put("user_id", userId).put("title", title.trim()).put("caption", caption.trim()).put("media_path", path).toString(), extraHeaders = mapOf("Prefer" to "return=minimal"))
        } catch (e: Exception) {
            try { request("DELETE", "storage/v1/object/chat-media", token, JSONObject().put("prefixes", JSONArray().put(path)).toString()) } catch (_: Exception) {}
            throw e
        }
    }

    suspend fun uploadClip(token: String, userId: String, caption: String, bytes: ByteArray, mime: String, extension: String) = withContext(Dispatchers.IO) {
        val path = "$userId/shorts/${System.currentTimeMillis()}.$extension"
        request("POST", "storage/v1/object/chat-media/${Uri.encode(path, "/")}", token, binaryBody = bytes, contentType = mime,
            extraHeaders = mapOf("x-upsert" to "false", "cache-control" to "3600"))
        try {
            request("POST", "rest/v1/short_videos", token, JSONObject().put("user_id", userId).put("caption", caption.take(220)).put("media_path", path).toString(), extraHeaders = mapOf("Prefer" to "return=minimal"))
        } catch (e: Exception) {
            try { request("DELETE", "storage/v1/object/chat-media", token, JSONObject().put("prefixes", JSONArray().put(path)).toString()) } catch (_: Exception) {}
            throw e
        }
    }

    private fun signedUrl(token: String, bucket: String, path: String): String {
        if (path.isBlank()) return ""
        return try {
            val result = JSONObject(request("POST", "storage/v1/object/sign/$bucket/${Uri.encode(path, "/")}", token, JSONObject().put("expiresIn", 3600).toString()))
            val signed = result.optString("signedURL").ifBlank { result.optString("signedUrl") }
            when {
                signed.startsWith("https://") || signed.startsWith("http://") -> signed
                signed.startsWith("/") -> "$SUPABASE_URL/storage/v1$signed"
                signed.isNotBlank() -> "$SUPABASE_URL/storage/v1/$signed"
                else -> ""
            }
        } catch (_: Exception) { "" }
    }

    /**
     * New avatars live in their own PUBLIC bucket, separate from private chat media.
     * Also accept absolute avatar URLs and legacy paths from the previous chat-media bucket.
     */
    private fun avatarUrl(token: String, storedPath: String): String {
        val path = storedPath.trim()
        if (path.isBlank()) return ""
        if (path.startsWith("https://") || path.startsWith("http://")) return path
        if (path.startsWith("profile-avatars/")) {
            val objectPath = path.removePrefix("profile-avatars/")
            return "$SUPABASE_URL/storage/v1/object/public/profile-avatars/${Uri.encode(objectPath, "/")}"
        }
        // Legacy avatars were stored in the private chat-media bucket.
        return signedUrl(token, "chat-media", path)
    }

    suspend fun updateProfile(token: String, displayName: String, bio: String, interests: List<String>, avatarPath: String? = null) = withContext(Dispatchers.IO) {
        // A narrowly scoped SECURITY DEFINER RPC is used so this client can update
        // presentation fields only—not approved status, role, or account identifiers.
        val payload = JSONObject()
            .put("p_display_name", displayName.trim())
            .put("p_bio", bio.trim())
            .put("p_interests", JSONArray(interests))
            .put("p_avatar_path", avatarPath ?: JSONObject.NULL)
            .put("p_update_avatar", avatarPath != null)
        request("POST", "rest/v1/rpc/update_my_altroom_profile", token, payload.toString())
    }

    suspend fun uploadProfileAvatar(token: String, userId: String, bytes: ByteArray, mime: String, extension: String): String = withContext(Dispatchers.IO) {
        // Keep avatars separate from private message attachments. The database stores the
        // bucket prefix so profileFrom() can build a stable public URL without signing errors.
        val objectPath = "$userId/avatar-${System.currentTimeMillis()}.$extension"
        request("POST", "storage/v1/object/profile-avatars/${Uri.encode(objectPath, "/")}", token, binaryBody = bytes, contentType = mime,
            extraHeaders = mapOf("x-upsert" to "false", "cache-control" to "3600"))
        "profile-avatars/$objectPath"
    }

    suspend fun recentPrivateMessages(token: String): List<AltroomMessage> = withContext(Dispatchers.IO) {
        val query = "rest/v1/private_messages?select=id,conversation_id,sender_id,kind,body,created_at,profiles:profiles!private_messages_sender_id_fkey(display_name,username)&order=created_at.desc&limit=100"
        val rows = JSONArray(request("GET", query, token))
        (0 until rows.length()).map { i ->
            val o = rows.getJSONObject(i)
            val p = o.optJSONObject("profiles")
            AltroomMessage(o.optString("id"), o.optString("conversation_id"), o.optString("sender_id"), o.optString("kind"), o.optString("body"), o.optString("created_at"), p?.optString("display_name").orEmpty().ifBlank { "ALTROOM member" }, p?.optString("username").orEmpty())
        }
    }

    /** Owner-only moderation queues. Authorization is enforced again by SECURITY DEFINER RPCs in Supabase. */
    suspend fun ownerRecentPrivateMessages(token: String): List<AltroomModerationMessage> = withContext(Dispatchers.IO) {
        val rows = JSONArray(request("POST", "rest/v1/rpc/altroom_owner_recent_private_messages", token,
            JSONObject().put("p_limit", 150).toString()))
        (0 until rows.length()).map { i -> rows.getJSONObject(i).toOwnerModerationMessage() }
    }

    suspend fun ownerRecentRoomMessages(token: String): List<AltroomModerationMessage> = withContext(Dispatchers.IO) {
        val rows = JSONArray(request("POST", "rest/v1/rpc/altroom_owner_recent_room_messages", token,
            JSONObject().put("p_limit", 150).toString()))
        (0 until rows.length()).map { i -> rows.getJSONObject(i).toOwnerModerationMessage() }
    }

    suspend fun ownerMembers(token: String): List<AltroomAdminMember> = withContext(Dispatchers.IO) {
        val rows = JSONArray(request("POST", "rest/v1/rpc/altroom_owner_list_members", token, "{}"))
        (0 until rows.length()).map { i ->
            val o = rows.getJSONObject(i)
            AltroomAdminMember(
                id = o.optString("member_id"),
                username = o.optString("username"),
                displayName = o.optString("display_name").ifBlank { "ALTROOM member" },
                role = o.optString("role", "member"),
                approved = o.optBoolean("approved"),
                accountStatus = o.optString("account_status", "pending")
            )
        }
    }

    suspend fun ownerDeletePrivateMessage(token: String, messageId: String, reason: String = "Community safety review") = withContext(Dispatchers.IO) {
        request("POST", "rest/v1/rpc/altroom_owner_delete_private_message", token,
            JSONObject().put("p_message_id", messageId).put("p_reason", reason.take(300)).toString())
    }

    suspend fun ownerDeleteRoomMessage(token: String, roomId: String, messageId: String) = withContext(Dispatchers.IO) {
        // The owner-only RPC confirms global owner access and writes the moderation audit entry.
        request("POST", "rest/v1/rpc/altroom_owner_delete_room_message", token,
            JSONObject().put("p_channel_id", roomId).put("p_message_id", messageId).put("p_reason", "Founder community safety review").toString())
    }

    suspend fun ownerSetMemberApproval(token: String, memberId: String, approved: Boolean) = withContext(Dispatchers.IO) {
        request("POST", "rest/v1/rpc/altroom_owner_set_member_status", token,
            JSONObject().put("p_member_id", memberId).put("p_approved", approved).put("p_reason", "Founder community safety review").toString())
    }

    private fun JSONObject.toOwnerModerationMessage(): AltroomModerationMessage = AltroomModerationMessage(
        id = optString("message_id"),
        contextId = optString("context_id"),
        contextLabel = optString("context_label").ifBlank { "ALTROOM conversation" },
        userId = optString("sender_id"),
        displayName = optString("sender_name").ifBlank { "ALTROOM member" },
        username = optString("sender_username"),
        kind = optString("kind", "text"),
        body = optString("body"),
        createdAt = optString("created_at")
    )

    private fun profileFrom(o: JSONObject, token: String): AltroomProfile {
        val interestsJson = o.optJSONArray("interests") ?: JSONArray()
        val interests = (0 until interestsJson.length()).map { interestsJson.optString(it) }.filter { it.isNotBlank() }
        // Avatar paths uploaded by profile editing are stored as `profile-avatars/<uid>/<file>`.
        // They must be resolved from the public avatar bucket, not the private chat-media bucket.
        // avatarUrl() also keeps support for legacy chat-media avatar paths and absolute URLs.
        return AltroomProfile(
            o.optString("id"),
            o.optString("username"),
            o.optString("display_name").ifBlank { "ALTROOM member" },
            o.optString("bio"),
            interests,
            o.optBoolean("approved"),
            o.optString("role", "member"),
            avatarUrl(token, o.optString("avatar_path"))
        )
    }

    private fun messageFrom(o: JSONObject, token: String): AltroomMessage {
        val p = o.optJSONObject("profiles")
        return AltroomMessage(o.optString("id"), o.optString("channel_id"), o.optString("user_id"), o.optString("kind"), o.optString("body"), o.optString("created_at"), p?.optString("display_name").orEmpty().ifBlank { "ALTROOM member" }, p?.optString("username").orEmpty(), o.optString("media_path"), o.optString("sticker_text"), o.optString("sticker_emoji"), signedUrl(token, "chat-media", o.optString("media_path")))
    }
}

data class AuthResult(val accessToken: String, val userId: String, val refreshToken: String)
data class RoomModerationReport(val id: String, val messageId: String, val reportedUserId: String, val reason: String, val status: String, val messageBody: String, val senderName: String)
data class AltroomProfile(val id: String, val username: String, val displayName: String, val bio: String, val interests: List<String>, val approved: Boolean, val role: String, val avatarUrl: String = "")
data class AltroomRoom(val id: String, val slug: String, val name: String, val description: String)
data class AltroomMessage(val id: String, val contextId: String, val userId: String, val kind: String, val body: String, val createdAt: String, val displayName: String, val username: String, val mediaPath: String = "", val stickerText: String = "", val stickerEmoji: String = "", val mediaUrl: String = "")
data class PrivateConversation(val id: String, val userA: String, val userB: String, val lastMessageAt: String)
data class ShortClip(
    val id: String, val userId: String, val caption: String, val createdAt: String, val mediaUrl: String,
    val likeCount: Int, val likedByMe: Boolean, val savedByMe: Boolean = false, val commentCount: Int = 0
)
data class ShortClipComment(
    val id: String, val videoId: String, val userId: String, val body: String, val createdAt: String,
    val displayName: String, val username: String, val parentCommentId: String? = null
)
data class AltroomModerationMessage(
    val id: String,
    val contextId: String,
    val contextLabel: String,
    val userId: String,
    val displayName: String,
    val username: String,
    val kind: String,
    val body: String,
    val createdAt: String
)

data class AltroomAdminMember(
    val id: String,
    val username: String,
    val displayName: String,
    val role: String,
    val approved: Boolean,
    val accountStatus: String
)

data class AltroomArtwork(val id: String, val userId: String, val title: String, val caption: String, val createdAt: String, val displayName: String, val username: String, val imageUrl: String)
