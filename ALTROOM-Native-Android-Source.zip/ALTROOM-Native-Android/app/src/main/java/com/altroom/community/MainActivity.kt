package com.altroom.community

// ALTROOM_BUILD_FINGERPRINT: 0.8.1

import android.Manifest
import android.app.Activity
import android.app.DownloadManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.annotation.SuppressLint
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.net.Uri
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.os.Bundle
import android.os.Build
import android.os.Environment
import android.provider.OpenableColumns
import android.view.ViewGroup
import android.widget.MediaController
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.verticalScroll
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Comment
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Forum
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayCircleFilled
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import coil.compose.AsyncImage
import coil.compose.AsyncImagePainter
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.concurrent.TimeUnit

private val Ink = Color(0xFF090909)
private val Panel = Color(0xFF151515)
private val Panel2 = Color(0xFF202020)
private val Paper = Color(0xFFF0EEE6)
private val Muted = Color(0xFFA4A29B)
private val Rule = Color(0xFF45443F)
private val Stamp = Color(0xFFC94A3C)
private val FounderGold = Color(0xFFFFC86B)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val notificationConstraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()
        val notificationWork = PeriodicWorkRequestBuilder<AltroomMessageNotificationWorker>(15, TimeUnit.MINUTES)
            .setConstraints(notificationConstraints)
            .build()
        WorkManager.getInstance(applicationContext).enqueueUniquePeriodicWork(
            "altroom-private-message-background-check",
            ExistingPeriodicWorkPolicy.KEEP,
            notificationWork
        )
        window.statusBarColor = android.graphics.Color.rgb(9, 9, 9)
        window.navigationBarColor = android.graphics.Color.rgb(9, 9, 9)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                ALTROOM_MESSAGE_CHANNEL,
                "ALTROOM messages",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "New private messages in ALTROOM"
                setShowBadge(true)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
            val signupChannel = NotificationChannel(
                ALTROOM_SIGNUP_CHANNEL,
                "ALTROOM new signups",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "New accounts joining ALTROOM"
                setShowBadge(true)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(signupChannel)
        }
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Paper,
                    onPrimary = Ink,
                    background = Ink,
                    onBackground = Paper,
                    surface = Panel,
                    onSurface = Paper,
                    secondary = Muted,
                    error = Color(0xFFFF8477)
                )
            ) { Surface(modifier = Modifier.fillMaxSize(), color = Ink) { AltroomApp() } }
        }
    }

    override fun onStart() {
        super.onStart()
        getSharedPreferences("altroom_native_session", Context.MODE_PRIVATE)
            .edit().putBoolean("app_is_foreground", true).apply()
    }

    override fun onStop() {
        getSharedPreferences("altroom_native_session", Context.MODE_PRIVATE)
            .edit().putBoolean("app_is_foreground", false).apply()
        super.onStop()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AltroomApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("altroom_native_session", Context.MODE_PRIVATE) }
    val api = remember { AltroomApi(prefs) }
    val scope = rememberCoroutineScope()

    var accessToken by remember { mutableStateOf(prefs.getString("access_token", "").orEmpty()) }
    var userId by remember { mutableStateOf(prefs.getString("user_id", "").orEmpty()) }
    var profile by remember { mutableStateOf<AltroomProfile?>(null) }
    var page by remember { mutableStateOf("loading") }

    // Keep system bars and in-app navigation visible, including while watching Shorts.
    DisposableEffect(context) {
        val activity = context.findAltroomActivity()
        activity?.setAltroomImmersiveMode(false)
        onDispose { activity?.setAltroomImmersiveMode(false) }
    }
    var tab by remember { mutableStateOf("rooms") }
    var lastNonShortsTab by remember { mutableStateOf("rooms") }
    var authMode by remember { mutableStateOf("login") }
    var authName by remember { mutableStateOf("") }
    var authEmail by remember { mutableStateOf("") }
    var authPassword by remember { mutableStateOf("") }
    var newRoomName by remember { mutableStateOf("") }
    var newRoomDescription by remember { mutableStateOf("") }
    var showCreateRoomDialog by remember { mutableStateOf(false) }
    var showRoomSafetyDialog by remember { mutableStateOf(false) }
    var showSignalDialog by remember { mutableStateOf(false) }
    var canModerateSelectedRoom by remember { mutableStateOf(false) }
    var roomReports by remember { mutableStateOf<List<RoomModerationReport>>(emptyList()) }
    var showProfileEditor by remember { mutableStateOf(false) }
    var viewedProfile by remember { mutableStateOf<AltroomProfile?>(null) }
    var selectedAvatarUri by remember { mutableStateOf<Uri?>(null) }
    var editDisplayName by remember { mutableStateOf("") }
    var editBio by remember { mutableStateOf("") }
    var editInterests by remember { mutableStateOf("") }
    var unreadConversations by remember {
        mutableStateOf(prefs.getStringSet("unread_conversations", emptySet())?.toSet() ?: emptySet())
    }
    var unreadMessageCounts by remember {
        mutableStateOf(decodeUnreadMessageCounts(prefs.getStringSet("unread_message_counts", emptySet())))
    }
    var knownPrivateMessageIds by remember {
        mutableStateOf(prefs.getStringSet("known_private_message_ids", null)?.toSet())
    }
    var busy by remember { mutableStateOf(false) }
    var errorText by remember { mutableStateOf("") }
    var infoText by remember { mutableStateOf("") }
    var rooms by remember { mutableStateOf<List<AltroomRoom>>(emptyList()) }
    var selectedRoom by remember { mutableStateOf<AltroomRoom?>(null) }
    var roomMessages by remember { mutableStateOf<List<AltroomMessage>>(emptyList()) }
    var roomDraft by remember { mutableStateOf("") }
    var members by remember { mutableStateOf<List<AltroomProfile>>(emptyList()) }
    var conversations by remember { mutableStateOf<List<PrivateConversation>>(emptyList()) }
    var selectedConversation by remember { mutableStateOf<PrivateConversation?>(null) }
    var privateOther by remember { mutableStateOf<AltroomProfile?>(null) }
    var privateMessages by remember { mutableStateOf<List<AltroomMessage>>(emptyList()) }
    var privateDraft by remember { mutableStateOf("") }
    var clips by remember { mutableStateOf<List<ShortClip>>(emptyList()) }
    var artworks by remember { mutableStateOf<List<AltroomArtwork>>(emptyList()) }
    var selectedVideoUri by remember { mutableStateOf<Uri?>(null) }
    var selectedImageUri by remember { mutableStateOf<Uri?>(null) }
    var selectedChatMediaUri by remember { mutableStateOf<Uri?>(null) }
    var selectedChatMediaKind by remember { mutableStateOf("image") }
    var showChatAttachments by remember { mutableStateOf(false) }
    var callKind by remember { mutableStateOf("video") }
    var callRoomName by remember { mutableStateOf("") }
    var callTitle by remember { mutableStateOf("ALTROOM CALL") }
    var pendingCallKind by remember { mutableStateOf("video") }
    var pendingCallRoomName by remember { mutableStateOf("") }
    var pendingCallTitle by remember { mutableStateOf("ALTROOM CALL") }
    var callReturnPage by remember { mutableStateOf("rooms") }
    var clipCaption by remember { mutableStateOf("") }
    var artTitle by remember { mutableStateOf("") }
    var artCaption by remember { mutableStateOf("") }
    var adminSection by remember { mutableStateOf("private") }
    var adminPrivateMessages by remember { mutableStateOf<List<AltroomModerationMessage>>(emptyList()) }
    var adminRoomMessages by remember { mutableStateOf<List<AltroomModerationMessage>>(emptyList()) }
    var adminMembers by remember { mutableStateOf<List<AltroomAdminMember>>(emptyList()) }
    var pendingSignupIds by remember {
        mutableStateOf(prefs.getStringSet("owner_pending_signup_ids", emptySet())?.toSet() ?: emptySet())
    }
    var pendingAdminMessage by remember { mutableStateOf<AltroomModerationMessage?>(null) }
    var pendingAdminMessageSource by remember { mutableStateOf("private") }
    var pendingAdminMember by remember { mutableStateOf<AltroomAdminMember?>(null) }
    var pendingAdminMemberActive by remember { mutableStateOf(false) }

    val callPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
        val audioOkay = grants[Manifest.permission.RECORD_AUDIO] == true || context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val cameraOkay = pendingCallKind != "video" || grants[Manifest.permission.CAMERA] == true || context.checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        if (audioOkay && cameraOkay) {
            callKind = pendingCallKind
            callRoomName = pendingCallRoomName
            callTitle = pendingCallTitle
            callReturnPage = page
            page = "call"
        } else {
            errorText = if (pendingCallKind == "video") "ALTROOM needs microphone and camera access to start a video call." else "ALTROOM needs microphone access to start an audio call."
        }
    }
    val notificationPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    fun beginProfileEdit() {
        val me = profile
        editDisplayName = me?.displayName.orEmpty()
        editBio = me?.bio.orEmpty()
        editInterests = me?.interests.orEmpty().joinToString(", ")
        selectedAvatarUri = null
        showProfileEditor = true
    }

    fun clearUnread(conversationId: String) {
        val updated = unreadConversations - conversationId
        unreadConversations = updated
        // Clear the OS notification too; otherwise a stale number badge remains after reading the chat.
        try { context.getSystemService(NotificationManager::class.java).cancel(conversationId.hashCode()) } catch (_: Exception) { }
        val updatedCounts = unreadMessageCounts - conversationId
        unreadMessageCounts = updatedCounts
        prefs.edit()
            .putStringSet("unread_conversations", updated)
            .putStringSet("unread_message_counts", encodeUnreadMessageCounts(updatedCounts))
            .apply()
    }

    LaunchedEffect(accessToken) {
        if (accessToken.isNotBlank() && Build.VERSION.SDK_INT >= 33 &&
            context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    suspend fun loadSession(token: String, uid: String, refreshToken: String = prefs.getString("refresh_token", "").orEmpty()) {
        accessToken = token
        userId = uid
        prefs.edit().putString("access_token", token).putString("user_id", uid).putString("refresh_token", refreshToken).apply()
        var loaded = api.profile(token, uid)
        prefs.edit().putString("profile_role", loaded.role).apply()
        val currentAccess = prefs.getString("access_token", token).orEmpty()
        if (currentAccess.isNotBlank() && currentAccess != accessToken) accessToken = currentAccess
        if (!loaded.approved) {
            // Open signup: a genuinely pending new account can activate itself.
            // The server refuses suspended accounts, so signing in cannot undo moderation.
            try {
                api.activateOpenSignup(token)
                loaded = api.profile(token, uid)
            } catch (activationError: Exception) {
                profile = loaded
                page = "pending"
                tab = "rooms"
                errorText = readableError(activationError)
                infoText = "ALTROOM uses open signup. If this account is restricted, only an authorized administrator can restore it."
                return
            }
        }
        profile = loaded
        page = if (loaded.approved) "rooms" else "pending"
        tab = "rooms"
        errorText = ""
        infoText = ""
    }

    fun task(showBusy: Boolean = true, work: suspend () -> Unit) {
        scope.launch {
            if (showBusy) busy = true
            errorText = ""
            infoText = ""
            try { work() }
            catch (ce: CancellationException) { throw ce }
            catch (e: Exception) {
                val message = readableError(e)
                if (message.contains("session expired", ignoreCase = true) || message.contains("sign in again", ignoreCase = true)) {
                    prefs.edit().remove("access_token").remove("refresh_token").remove("user_id").apply()
                    accessToken = ""; userId = ""; profile = null; page = "auth"
                    infoText = "Your ALTROOM session expired. Sign in again; your account and messages are unchanged."
                    errorText = ""
                } else if (isTransientNetworkError(e)) {
                    errorText = "Connection hiccup. Tap again in a moment; ALTROOM will keep trying to reconnect."
                } else errorText = message
            }
            finally {
                val savedAccess = prefs.getString("access_token", "").orEmpty()
                if (savedAccess.isNotBlank() && savedAccess != accessToken) accessToken = savedAccess
                if (showBusy) busy = false
            }
        }
    }
    suspend fun refreshOwnerDesk() {
        if (profile?.role != "owner") throw IOException("Founder owner access only. Your current account does not have the owner role.")
        adminPrivateMessages = api.ownerRecentPrivateMessages(accessToken)
        adminRoomMessages = api.ownerRecentRoomMessages(accessToken)
        adminMembers = api.ownerMembers(accessToken)
        val savedPending = prefs.getStringSet("owner_pending_signup_ids", emptySet())?.toSet() ?: emptySet()
        if (savedPending != pendingSignupIds) pendingSignupIds = savedPending
    }

    fun requestCall(kind: String, roomName: String, title: String) {
        pendingCallKind = kind
        pendingCallRoomName = roomName
        pendingCallTitle = title
        val required = mutableListOf<String>()
        if (context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) required += Manifest.permission.RECORD_AUDIO
        if (kind == "video" && context.checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) required += Manifest.permission.CAMERA
        if (required.isEmpty()) {
            callKind = kind
            callRoomName = roomName
            callTitle = title
            callReturnPage = page
            page = "call"
        } else callPermissionLauncher.launch(required.toTypedArray())
    }

    fun makeCall(kind: String, isPrivate: Boolean) {
        val roomName = "ALTROOM-${kind.uppercase()}-${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val title = if (isPrivate) "${kind.uppercase()} CALL · ${privateOther?.displayName ?: "PRIVATE CHAT"}" else "${kind.uppercase()} CALL · ${selectedRoom?.name ?: "COMMUNITY ROOM"}"
        task {
            if (isPrivate) {
                val conversation = selectedConversation ?: throw IOException("Open a private conversation first.")
                api.sendPrivateMessage(accessToken, conversation.id, userId, "ALTROOM_CALL|$kind|$roomName")
                privateMessages = api.privateMessages(accessToken, conversation.id)
            } else {
                val room = selectedRoom ?: throw IOException("Enter a community room first.")
                api.sendRoomMessage(accessToken, room.id, userId, "ALTROOM_CALL|$kind|$roomName")
                roomMessages = api.roomMessages(accessToken, room.id)
            }
            requestCall(kind, roomName, title)
        }
    }

    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        selectedVideoUri = uri
        clipCaption = ""
    }
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        selectedImageUri = uri
        artTitle = ""
        artCaption = ""
    }
    val chatMediaPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) selectedChatMediaUri = uri
    }
    val avatarPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) selectedAvatarUri = uri
    }


    LaunchedEffect(Unit) {
        if (accessToken.isBlank() || userId.isBlank()) {
            page = "auth"
        } else {
            try { loadSession(accessToken, userId) }
            catch (_: Exception) {
                val savedRefresh = prefs.getString("refresh_token", "").orEmpty()
                try {
                    if (savedRefresh.isBlank()) throw IOException("No refresh token saved")
                    val fresh = api.refreshSession(savedRefresh)
                    if (fresh.accessToken.isBlank() || fresh.userId.isBlank()) throw IOException("Session refresh failed")
                    loadSession(fresh.accessToken, fresh.userId, fresh.refreshToken)
                } catch (_: Exception) {
                    prefs.edit().remove("access_token").remove("refresh_token").remove("user_id").apply()
                    accessToken = ""; userId = ""; profile = null; page = "auth"
                    infoText = "Your saved session expired. Sign in again. Your local message counts and preferences are preserved."
                }
            }
        }
    }

    LaunchedEffect(page, accessToken, userId, selectedRoom?.id, selectedConversation?.id) {
        if (accessToken.isBlank() || userId.isBlank()) return@LaunchedEffect
        try {
            when (page) {
                "rooms" -> rooms = api.rooms(accessToken)
                "private" -> {
                    members = api.members(accessToken)
                    conversations = api.conversations(accessToken, userId)
                }
                "room" -> {
                    val target = selectedRoom ?: return@LaunchedEffect
                    // Keep creator avatars and message profile links available in every room.
                    members = try { api.members(accessToken) } catch (_: Exception) { members }
                    canModerateSelectedRoom = try { api.canModerateRoom(accessToken, target.id) } catch (_: Exception) { false }
                    while (isActive) {
                        roomMessages = api.roomMessages(accessToken, target.id)
                        delay(5_000)
                    }
                }
                "privateThread" -> {
                    val target = selectedConversation ?: return@LaunchedEffect
                    while (isActive) {
                        privateMessages = api.privateMessages(accessToken, target.id)
                        delay(5_000)
                    }
                }
                "shorts" -> {
                    clips = api.shortClips(accessToken, userId)
                    members = try { api.members(accessToken) } catch (_: Exception) { members }
                }
                "gallery" -> artworks = api.gallery(accessToken)
                "admin" -> refreshOwnerDesk()
            }
        } catch (ce: CancellationException) { throw ce }
        catch (e: Exception) {
            val message = readableError(e)
            if (message.contains("session expired", ignoreCase = true) || message.contains("sign in again", ignoreCase = true)) {
                prefs.edit().remove("access_token").remove("refresh_token").remove("user_id").apply()
                accessToken = ""; userId = ""; profile = null; page = "auth"
                infoText = "Your ALTROOM session expired. Sign in again; your account and messages are unchanged."
                errorText = ""
            } else if (isTransientNetworkError(e)) {
                // Background load will be retried when the user changes section or refreshes.
                errorText = ""
            } else errorText = message
        }
    }

    // Owner-only new-signup watcher. The first read is a baseline; only accounts created later
    // trigger a badge/notification. It runs while ALTROOM is foregrounded and catches up on resume.
    LaunchedEffect(accessToken, userId, profile?.role) {
        if (accessToken.isBlank() || userId.isBlank() || profile?.role != "owner") return@LaunchedEffect
        while (isActive) {
            if (prefs.getBoolean("app_is_foreground", true)) {
                try {
                    val savedPending = prefs.getStringSet("owner_pending_signup_ids", emptySet())?.toSet() ?: emptySet()
                    if (savedPending != pendingSignupIds) pendingSignupIds = savedPending
                    val currentMembers = api.ownerMembers(accessToken)
                    adminMembers = currentMembers
                    val currentIds = currentMembers.map { it.id }.filter { it.isNotBlank() }.toSet()
                    val storedKnown = prefs.getStringSet("owner_known_member_ids", null)?.toSet()
                    if (storedKnown == null) {
                        // Baseline existing members during upgrade; do not spam the founder with old accounts.
                        prefs.edit().putStringSet("owner_known_member_ids", currentIds).apply()
                    } else {
                        val addedIds = currentIds - storedKnown
                        if (addedIds.isNotEmpty()) {
                            val pending = pendingSignupIds + addedIds
                            pendingSignupIds = pending
                            prefs.edit()
                                .putStringSet("owner_pending_signup_ids", pending)
                                .putStringSet("owner_known_member_ids", storedKnown + currentIds)
                                .apply()
                            currentMembers.filter { it.id in addedIds }.forEach { newMember ->
                                context.showAltroomSignupNotification("signup:${newMember.id}".hashCode(), newMember.displayName)
                            }
                        } else {
                            prefs.edit().putStringSet("owner_known_member_ids", storedKnown + currentIds).apply()
                        }
                    }
                } catch (ce: CancellationException) {
                    throw ce
                } catch (_: Exception) {
                    // Temporary offline/reset failures are intentionally silent; the next poll retries.
                }
            }
            delay(120_000)
        }
    }

    // Poll recent private messages while ALTROOM is running. Each unread message
    // increments a persistent per-conversation count used by the tab, chat list and notifications.
    LaunchedEffect(accessToken, userId, page, selectedConversation?.id) {
        if (accessToken.isBlank() || userId.isBlank()) return@LaunchedEffect
        while (isActive) {
            try {
                val recent = api.recentPrivateMessages(accessToken)
                val savedAccess = prefs.getString("access_token", "").orEmpty()
                if (savedAccess.isNotBlank() && savedAccess != accessToken) accessToken = savedAccess
                val ids = recent.map { it.id }.toSet()
                val storedKnown = prefs.getStringSet("known_private_message_ids", null)?.toSet()
                val known = storedKnown ?: knownPrivateMessageIds
                val savedUnread = prefs.getStringSet("unread_conversations", emptySet())?.toSet() ?: emptySet()
                var nextCounts = decodeUnreadMessageCounts(prefs.getStringSet("unread_message_counts", emptySet()))
                if (savedUnread != unreadConversations) unreadConversations = savedUnread
                if (nextCounts != unreadMessageCounts) unreadMessageCounts = nextCounts
                if (known == null) {
                    knownPrivateMessageIds = ids
                    prefs.edit().putStringSet("known_private_message_ids", ids).apply()
                } else {
                    val freshIncoming = recent.filter { it.id !in known && it.userId != userId }.asReversed()
                    var nextUnread = savedUnread
                    freshIncoming.forEach { message ->
                        if (page == "privateThread" && selectedConversation?.id == message.contextId) {
                            nextUnread = nextUnread - message.contextId
                            nextCounts = nextCounts - message.contextId
                        } else {
                            nextUnread = nextUnread + message.contextId
                            val count = (nextCounts[message.contextId] ?: 0) + 1
                            nextCounts = nextCounts + (message.contextId to count)
                            val body = if (message.body.startsWith("ALTROOM_CALL|")) {
                                val callType = message.body.split('|').getOrNull(1)?.takeIf { it in listOf("audio", "video") } ?: "voice"
                                "Started a $callType call. Tap the call card to join."
                            } else message.body.takeIf { it.isNotBlank() }?.take(120) ?: when (message.kind) {
                                "audio" -> "Sent you an audio message 🎧"
                                "image" -> "Sent you a photo ▧"
                                "video" -> "Sent you a video ▶"
                                else -> "Sent you a message ✉"
                            }
                            context.showAltroomMessageNotification(message.contextId.hashCode(), message.displayName, body, count)
                        }
                    }
                    unreadConversations = nextUnread
                    unreadMessageCounts = nextCounts
                    val updatedKnown = (known + ids).toList().takeLast(300).toSet()
                    knownPrivateMessageIds = updatedKnown
                    prefs.edit()
                        .putStringSet("known_private_message_ids", updatedKnown)
                        .putStringSet("unread_conversations", nextUnread)
                        .putStringSet("unread_message_counts", encodeUnreadMessageCounts(nextCounts))
                        .apply()
                }
                if (page == "private") conversations = api.conversations(accessToken, userId)
            } catch (ce: CancellationException) {
                throw ce
            } catch (e: Exception) {
                val message = readableError(e)
                if (message.contains("session expired", ignoreCase = true) || message.contains("sign in again", ignoreCase = true)) {
                    prefs.edit().remove("access_token").remove("refresh_token").remove("user_id").apply()
                    accessToken = ""; userId = ""; profile = null; page = "auth"
                    infoText = "Your ALTROOM session expired. Sign in again; local message counts are preserved."
                }
                // Brief connectivity failures are ignored; expired sessions are not silently looped.
            }
            delay(10_000)
        }
    }

    fun switchTab(next: String) {
        if (next != "shorts") lastNonShortsTab = next
        tab = next
        page = next
        selectedRoom = null
        selectedConversation = null
        privateOther = null
        errorText = ""
    }

    fun signOut() {
        prefs.edit().clear().apply()
        accessToken = ""; userId = ""; profile = null; selectedRoom = null
        selectedConversation = null; roomMessages = emptyList(); privateMessages = emptyList()
        unreadConversations = emptySet(); unreadMessageCounts = emptyMap(); knownPrivateMessageIds = null
        page = "auth"; tab = "rooms"; authMode = "login"
    }

    BackHandler(enabled = page == "room" || page == "privateThread" || page == "pending" || page == "call" || page == "shorts" || page == "admin") {
        when (page) {
            "room" -> { selectedRoom = null; page = "rooms"; tab = "rooms" }
            "privateThread" -> { selectedConversation = null; privateOther = null; page = "private"; tab = "private" }
            "pending" -> { signOut() }
            "call" -> { page = callReturnPage }
            "shorts" -> { switchTab(lastNonShortsTab.ifBlank { "rooms" }) }
            "admin" -> { page = "profile"; tab = "profile" }
        }
    }

    Column(
        Modifier.fillMaxSize().background(Ink).animateContentSize(animationSpec = tween(durationMillis = 220))
            .padding(WindowInsets.navigationBars.asPaddingValues())
    ) {
        if (page != "auth" && page != "loading" && page != "shorts" && page != "call") {
            Row(
                Modifier.fillMaxWidth().background(Ink).padding(horizontal = 18.dp, vertical = 15.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(29.dp).background(Paper), contentAlignment = Alignment.Center) {
                        Text("✳", color = Ink, fontSize = 19.sp, fontWeight = FontWeight.Black)
                    }
                    Spacer(Modifier.width(9.dp))
                    Column {
                        Text("ALTROOM", color = Paper, fontSize = 21.sp, fontWeight = FontWeight.Black, letterSpacing = (-0.7).sp)
                        Text("A PLACE FOR THE OTHER ONES · v0.8.1", color = Muted, fontSize = 8.sp, letterSpacing = 1.0.sp)
                    }
                }
                if (profile != null) {
                    ProfileAvatar(profile = profile, size = 40.dp, modifier = Modifier.clickable { beginProfileEdit() }, contextDescription = "Customize your profile")
                }
            }
            Divider(color = Rule, thickness = 1.dp)
        }

        if (errorText.isNotBlank() && page != "auth" && page != "shorts" && page != "call") {
            Column(Modifier.fillMaxWidth().background(Color(0xFF321A18)).padding(horizontal = 15.dp, vertical = 9.dp)) {
                Text(errorText, color = Color(0xFFFFC1B9), fontSize = 12.sp)
                TextButton(onClick = { errorText = "" }) { Text("Dismiss", color = Paper, fontSize = 11.sp) }
            }
        }
        if (infoText.isNotBlank() && page != "auth" && page != "shorts" && page != "call") {
            Text(infoText, Modifier.fillMaxWidth().background(Panel).padding(12.dp), color = Paper, fontSize = 12.sp)
        }

        when (page) {
            "loading" -> CenterState("OPENING THE ROOM", "Connecting to your ALTROOM account…", true, Modifier.fillMaxSize())
            "auth" -> AuthScreen(
                mode = authMode, name = authName, onName = { authName = it }, email = authEmail, onEmail = { authEmail = it },
                password = authPassword, onPassword = { authPassword = it }, busy = busy, info = infoText, error = errorText,
                onMode = { authMode = it; errorText = ""; infoText = "" },
                onSubmit = {
                    task {
                        if (authEmail.isBlank() || authPassword.isBlank()) throw IOException("Enter your email and password.")
                        if (authMode == "signup") {
                            if (authName.isBlank()) throw IOException("Choose a display name first.")
                            if (authPassword.length < 6) throw IOException("Use a password with at least 6 characters.")
                            val result = api.signUp(authName, authEmail, authPassword)
                            if (result.accessToken.isBlank() || result.userId.isBlank()) {
                                infoText = "Your account request was sent. Check your email to verify it, then sign in."
                                authMode = "login"
                            } else {
                                try { loadSession(result.accessToken, result.userId, result.refreshToken) }
                                catch (e: Exception) { accessToken = result.accessToken; userId = result.userId; prefs.edit().putString("access_token", accessToken).putString("user_id", userId).putString("refresh_token", result.refreshToken).apply(); page = "pending"; infoText = "Your account was created. Verify your email if prompted, then sign in to finish activation." }
                            }
                        } else {
                            val result = api.signIn(authEmail, authPassword)
                            if (result.accessToken.isBlank() || result.userId.isBlank()) throw IOException("Sign in did not return a session. Verify your email and try again.")
                            loadSession(result.accessToken, result.userId, result.refreshToken)
                        }
                    }
                }
            )
            "pending" -> PendingAccessScreen(
                info = errorText,
                onRetry = { task { loadSession(accessToken, userId) } },
                onSignOut = { signOut() }
            )
            "rooms" -> {
                SectionHeading("COMMUNITY ROOMS", "Find your corner. Room stewards keep things safe.", action = { newRoomName = ""; newRoomDescription = ""; showCreateRoomDialog = true }, actionLabel = "+ ROOM")
                if (rooms.isEmpty()) CenterState("THE ROOMS ARE QUIET", "Pull to refresh or check your connection.", false, Modifier.weight(1f))
                else LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 15.dp), verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 22.dp)) {
                    items(rooms, key = { it.id }) { room -> RoomCard(room) {
                        task {
                            api.joinRoom(accessToken, room.id)
                            selectedRoom = room
                            roomMessages = emptyList()
                            roomReports = emptyList()
                            canModerateSelectedRoom = false
                            page = "room"; tab = "rooms"
                        }
                    } }
                }
            }
            "room" -> {
                selectedRoom?.let { room ->
                    Row(Modifier.fillMaxWidth().padding(horizontal = 13.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { selectedRoom = null; page = "rooms"; tab = "rooms" }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Paper) }
                        Column(Modifier.weight(1f)) { Text(room.name.uppercase(), color = Paper, fontWeight = FontWeight.Black, fontSize = 17.sp); Text(room.description, color = Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                        TextButton(onClick = {
                            showRoomSafetyDialog = true
                            if (canModerateSelectedRoom) task(false) { roomReports = api.roomReports(accessToken, room.id) }
                        }, contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 4.dp, vertical = 4.dp)) {
                            Text(if (canModerateSelectedRoom) "⚑ MOD" else "⚑ SAFE", color = Stamp, fontWeight = FontWeight.Black, fontSize = 9.sp)
                        }
                        IconButton(onClick = { makeCall("audio", false) }, modifier = Modifier.size(38.dp)) { Icon(Icons.Default.Call, contentDescription = "Start audio call", tint = Paper) }
                        IconButton(onClick = { makeCall("video", false) }, modifier = Modifier.size(38.dp)) { Icon(Icons.Default.Videocam, contentDescription = "Start video call", tint = Stamp) }
                    }
                    Divider(color = Rule)
                    if (roomMessages.isEmpty()) CenterState("START THE CONVERSATION", "Write the first message. It's only visible in this room.", false, Modifier.weight(1f))
                    else LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 13.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 14.dp)) {
                        items(roomMessages, key = { it.id }) { msg -> MessageCard(
                            msg,
                            own = msg.userId == userId,
                            profile = if (msg.userId == userId) profile else members.firstOrNull { it.id == msg.userId },
                            onProfileClick = {
                                if (msg.userId == userId) beginProfileEdit() else task(false) {
                                    viewedProfile = members.firstOrNull { it.id == msg.userId } ?: api.profile(accessToken, msg.userId)
                                }
                            },
                            onJoinCall = { kind, name -> requestCall(kind, name, "${kind.uppercase()} CALL · ${room.name}") }
                        ) }
                    }
                    Composer(draft = roomDraft, onDraft = { roomDraft = it }, hint = "Message #${room.slug}", busy = busy, onAttach = { showChatAttachments = true }, onSignal = { showSignalDialog = true }, onSend = {
                        val text = roomDraft.trim()
                        if (text.isNotBlank()) task {
                            api.sendRoomMessage(accessToken, room.id, userId, text)
                            roomDraft = ""
                            roomMessages = api.roomMessages(accessToken, room.id)
                        }
                    })
                }
            }
            "private" -> {
                val myInterestKeys = profile?.interests.orEmpty().map { it.trim().lowercase(Locale.ROOT) }.filter { it.isNotBlank() }.toSet()
                val orbitMatches = members.asSequence()
                    .filter { it.id != userId && myInterestKeys.isNotEmpty() }
                    .map { member -> member to member.interests.count { it.trim().lowercase(Locale.ROOT) in myInterestKeys } }
                    .filter { it.second > 0 }
                    .sortedByDescending { it.second }
                    .take(3)
                    .toList()
                SectionHeading("MESSAGES", "Private chats, shared media, and calls — all in the right conversation.", action = { task(false) { members = api.members(accessToken); conversations = api.conversations(accessToken, userId) } }, actionLabel = "↻")
                LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 15.dp), verticalArrangement = Arrangement.spacedBy(9.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 20.dp)) {
                    item {
                        Column(Modifier.fillMaxWidth().background(Color(0xFF211A19), RoundedCornerShape(12.dp)).border(1.dp, Color(0xFF6B3F38), RoundedCornerShape(12.dp)).padding(13.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("✳ FIND YOUR ORBIT", color = Stamp, fontWeight = FontWeight.Black, fontSize = 12.sp, letterSpacing = 1.sp)
                            Text(
                                if (myInterestKeys.isEmpty()) "Add interests to your profile to discover people on your wavelength."
                                else if (orbitMatches.isEmpty()) "Your orbit is still forming. Add more interests or check back as people join."
                                else "People who share the things you're into appear below. Tap one to start a private chat.",
                                color = Muted, fontSize = 11.sp, lineHeight = 16.sp
                            )
                        }
                    }
                    items(orbitMatches, key = { "orbit-${it.first.id}" }) { match ->
                        val member = match.first
                        val sharedCount = match.second
                        MemberCard(
                            member,
                            subtitle = "✳ $sharedCount shared interest${if (sharedCount == 1) "" else "s"} · tap to message",
                            onProfileClick = { viewedProfile = member }
                        ) {
                            task {
                                val id = api.openConversation(accessToken, member.id)
                                if (id.isBlank()) throw IOException("ALTROOM couldn't open that private conversation.")
                                clearUnread(id)
                                selectedConversation = PrivateConversation(id, userId, member.id, "")
                                privateOther = member
                                privateMessages = api.privateMessages(accessToken, id)
                                page = "privateThread"; tab = "private"
                            }
                        }
                    }
                    item { Text("YOUR CHATS", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Black, letterSpacing = 1.4.sp, modifier = Modifier.padding(vertical = 4.dp)) }
                    if (conversations.isEmpty()) item { EmptyCard("NO PRIVATE CHATS YET", "Choose a member below to start a conversation.") }
                    items(conversations, key = { "c-${it.id}" }) { conv ->
                        val otherId = if (conv.userA == userId) conv.userB else conv.userA
                        val other = members.firstOrNull { it.id == otherId }
                        MemberCard(
                            other,
                            subtitle = if (conv.id in unreadConversations) "NEW MESSAGE · Open chat" else "Open private chat",
                            unreadCount = unreadMessageCounts[conv.id] ?: if (conv.id in unreadConversations) 1 else 0,
                            onProfileClick = { if (other != null) viewedProfile = other }
                        ) {
                            clearUnread(conv.id)
                            task {
                                selectedConversation = conv
                                privateOther = other
                                privateMessages = api.privateMessages(accessToken, conv.id)
                                page = "privateThread"; tab = "private"
                            }
                        }
                    }
                    item { Spacer(Modifier.height(8.dp)); Text("MEMBERS", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Black, letterSpacing = 1.4.sp, modifier = Modifier.padding(vertical = 4.dp)) }
                    items(members.filter { it.id != userId }, key = { "m-${it.id}" }) { member ->
                        MemberCard(member, subtitle = "@${member.username}", onProfileClick = { viewedProfile = member }) {
                            task {
                                val id = api.openConversation(accessToken, member.id)
                                if (id.isBlank()) throw IOException("ALTROOM couldn't open that private conversation.")
                                clearUnread(id)
                                selectedConversation = PrivateConversation(id, userId, member.id, "")
                                privateOther = member
                                privateMessages = api.privateMessages(accessToken, id)
                                page = "privateThread"; tab = "private"
                            }
                        }
                    }
                }
            }
            "privateThread" -> {
                Row(Modifier.fillMaxWidth().padding(horizontal = 13.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { selectedConversation = null; privateOther = null; page = "private"; tab = "private" }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Paper) }
                    ProfileAvatar(profile = privateOther, size = 42.dp, modifier = Modifier.clickable { privateOther?.let { viewedProfile = it } }, contextDescription = "View contact profile")
                    Spacer(Modifier.width(8.dp))
                    Column(Modifier.weight(1f).clickable { privateOther?.let { viewedProfile = it } }) {
                        Text(privateOther?.displayName ?: "Private chat", color = Paper, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("@${privateOther?.username ?: "member"} · private chat", color = Muted, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    IconButton(onClick = { makeCall("audio", true) }, modifier = Modifier.size(38.dp)) { Icon(Icons.Default.Call, contentDescription = "Start private audio call", tint = Paper) }
                    IconButton(onClick = { makeCall("video", true) }, modifier = Modifier.size(38.dp)) { Icon(Icons.Default.Videocam, contentDescription = "Start private video call", tint = Stamp) }
                }
                Divider(color = Rule)
                if (privateMessages.isEmpty()) CenterState("A PRIVATE CONVERSATION", "Say hello. Only the two participants can see it.", false, Modifier.weight(1f))
                else LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 13.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(15.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 18.dp)) {
                    items(privateMessages, key = { it.id }) { msg -> MessageCard(
                        msg,
                        own = msg.userId == userId,
                        profile = if (msg.userId == userId) profile else if (privateOther?.id == msg.userId) privateOther else members.firstOrNull { it.id == msg.userId },
                        onProfileClick = {
                            if (msg.userId == userId) beginProfileEdit() else task(false) {
                                viewedProfile = if (privateOther?.id == msg.userId) privateOther else members.firstOrNull { it.id == msg.userId } ?: api.profile(accessToken, msg.userId)
                            }
                        },
                        onJoinCall = { kind, name -> requestCall(kind, name, "${kind.uppercase()} CALL · ${privateOther?.displayName ?: "PRIVATE CHAT"}") },
                        privateStyle = true
                    ) }
                }
                Composer(draft = privateDraft, onDraft = { privateDraft = it }, hint = "Private message…", busy = busy, onAttach = { showChatAttachments = true }, onSignal = { showSignalDialog = true }, onSend = {
                    val text = privateDraft.trim(); val conv = selectedConversation
                    if (text.isNotBlank() && conv != null) task {
                        api.sendPrivateMessage(accessToken, conv.id, userId, text)
                        privateDraft = ""
                        privateMessages = api.privateMessages(accessToken, conv.id)
                    }
                })
            }
            "admin" -> {
                Column(Modifier.weight(1f).fillMaxWidth()) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 15.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text("FOUNDER SAFETY DESK", color = Paper, fontWeight = FontWeight.Black, fontSize = 19.sp, letterSpacing = (-.4).sp)
                            Text("PRIVATE OWNER AREA · MESSAGE MODERATION", color = FounderGold, fontWeight = FontWeight.Black, fontSize = 9.sp, letterSpacing = .5.sp, modifier = Modifier.padding(top = 3.dp))
                        }
                        TextButton(onClick = { page = "profile"; tab = "profile" }) { Text("CLOSE", color = Muted, fontWeight = FontWeight.Black, fontSize = 10.sp) }
                    }
                    Column(Modifier.fillMaxWidth().padding(horizontal = 15.dp, vertical = 2.dp).background(Color(0xFF211C16), RoundedCornerShape(10.dp)).border(1.dp, FounderGold.copy(alpha = .7f), RoundedCornerShape(10.dp)).padding(11.dp)) {
                        Text("FOUNDER / SUPER ADMIN", color = FounderGold, fontWeight = FontWeight.Black, fontSize = 11.sp, letterSpacing = .6.sp)
                        Text("Review recent private messages across conversations, remove harmful room messages, and suspend or restore member accounts. Private-message review is recorded in the moderation audit log; use access only for safety and policy enforcement.", color = Muted, fontSize = 10.sp, lineHeight = 15.sp, modifier = Modifier.padding(top = 5.dp))
                    }
                    Row(Modifier.fillMaxWidth().padding(horizontal = 7.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                        TextButton(onClick = { adminSection = "private" }, modifier = Modifier.weight(1f), contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 1.dp, vertical = 6.dp)) { Text(if (adminSection == "private") "● DM" else "DM", color = if (adminSection == "private") FounderGold else Muted, fontSize = 9.sp, fontWeight = FontWeight.Black, maxLines = 1) }
                        TextButton(onClick = { adminSection = "rooms" }, modifier = Modifier.weight(1f), contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 1.dp, vertical = 6.dp)) { Text(if (adminSection == "rooms") "● ROOMS" else "ROOMS", color = if (adminSection == "rooms") FounderGold else Muted, fontSize = 9.sp, fontWeight = FontWeight.Black, maxLines = 1) }
                        TextButton(onClick = { adminSection = "members" }, modifier = Modifier.weight(1f), contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 1.dp, vertical = 6.dp)) { Text(if (adminSection == "members") "● MEMBERS" else "MEMBERS", color = if (adminSection == "members") FounderGold else Muted, fontSize = 9.sp, fontWeight = FontWeight.Black, maxLines = 1) }
                        TextButton(onClick = { adminSection = "signups" }, modifier = Modifier.weight(1.15f), contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 1.dp, vertical = 6.dp)) {
                            Text(if (pendingSignupIds.isNotEmpty()) "✦ NEW ${pendingSignupIds.size.coerceAtMost(99)}" else if (adminSection == "signups") "● SIGNUPS" else "SIGNUPS", color = if (adminSection == "signups" || pendingSignupIds.isNotEmpty()) FounderGold else Muted, fontSize = 8.sp, fontWeight = FontWeight.Black, maxLines = 1)
                        }
                        IconButton(onClick = { task { refreshOwnerDesk() } }, modifier = Modifier.size(34.dp).background(Panel2, RoundedCornerShape(8.dp))) { Icon(Icons.Default.Refresh, contentDescription = "Refresh owner safety desk", tint = Paper, modifier = Modifier.size(18.dp)) }
                    }
                    when (adminSection) {
                        "private" -> {
                            if (adminPrivateMessages.isEmpty()) CenterState("NO RECENT PRIVATE MESSAGES", "Private-chat moderation results will appear here after the owner migration is installed.", false, Modifier.weight(1f))
                            else LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 18.dp)) {
                                items(adminPrivateMessages, key = { "owner-dm-${it.id}" }) { message ->
                                    OwnerModerationMessageCard(message, privateMessage = true, onDelete = { pendingAdminMessage = message; pendingAdminMessageSource = "private" })
                                }
                            }
                        }
                        "rooms" -> {
                            if (adminRoomMessages.isEmpty()) CenterState("NO RECENT ROOM MESSAGES", "Room posts from across ALTROOM appear here for global moderation.", false, Modifier.weight(1f))
                            else LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 18.dp)) {
                                items(adminRoomMessages, key = { "owner-room-${it.id}" }) { message ->
                                    OwnerModerationMessageCard(message, privateMessage = false, onDelete = { pendingAdminMessage = message; pendingAdminMessageSource = "rooms" })
                                }
                            }
                        }
                        "members" -> {
                            if (adminMembers.isEmpty()) CenterState("NO MEMBER RECORDS", "Refresh to load active, pending, and suspended accounts.", false, Modifier.weight(1f))
                            else LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 18.dp)) {
                                items(adminMembers, key = { "owner-member-${it.id}" }) { member ->
                                    OwnerAdminMemberCard(member, onChangeStatus = { active -> pendingAdminMember = member; pendingAdminMemberActive = active })
                                }
                            }
                        }
                        else -> {
                            val newMembers = adminMembers.filter { it.id in pendingSignupIds }
                            Column(Modifier.weight(1f).fillMaxWidth()) {
                                Row(Modifier.fillMaxWidth().padding(horizontal = 13.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text("NEW SIGNUPS", color = Paper, fontWeight = FontWeight.Black, fontSize = 14.sp)
                                        Text("New accounts detected after alerts were initialized", color = Muted, fontSize = 10.sp)
                                    }
                                    TextButton(onClick = {
                                        pendingSignupIds = emptySet()
                                        prefs.edit().putStringSet("owner_pending_signup_ids", emptySet()).apply()
                                    }, enabled = pendingSignupIds.isNotEmpty()) { Text("MARK REVIEWED", color = FounderGold, fontSize = 9.sp, fontWeight = FontWeight.Black) }
                                }
                                if (newMembers.isEmpty()) {
                                    CenterState("NO NEW SIGNUPS", "New accounts will appear here with a founder-only badge and notification.", false, Modifier.weight(1f))
                                } else {
                                    LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 18.dp)) {
                                        items(newMembers, key = { "owner-signup-${it.id}" }) { member ->
                                            OwnerAdminMemberCard(member, onChangeStatus = { active -> pendingAdminMember = member; pendingAdminMemberActive = active })
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            "call" -> {
                CallScreen(title = callTitle, kind = callKind, roomName = callRoomName, onClose = { page = callReturnPage })
            }
            "shorts" -> {
                if (clips.isEmpty()) {
                    Column(Modifier.weight(1f).fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        Text("VIDEO CLUB", color = Paper, fontWeight = FontWeight.Black, fontSize = 24.sp, letterSpacing = (-.7).sp)
                        Text("Vertical clips · no more than 30 seconds", color = Muted, fontSize = 12.sp)
                        Button(onClick = { videoPicker.launch("video/*") }, colors = ButtonDefaults.buttonColors(containerColor = Paper, contentColor = Ink), shape = RoundedCornerShape(8.dp)) {
                            Icon(Icons.Default.VideoLibrary, contentDescription = "Post a short video")
                            Spacer(Modifier.width(8.dp)); Text("POST THE FIRST CLIP", fontWeight = FontWeight.Black)
                        }
                        CenterState("THE FEED IS QUIET", "Post the first strange little clip. Keep it under 30 seconds.", false, Modifier.weight(1f))
                    }
                } else {
                    val shortsPager = rememberPagerState(pageCount = { clips.size })
                    VerticalPager(state = shortsPager, modifier = Modifier.weight(1f).fillMaxWidth(), pageSpacing = 0.dp) { pageIndex ->
                        val clip = clips[pageIndex]
                        val clipAuthor = members.firstOrNull { it.id == clip.userId }
                        ClipCard(
                            clip = clip,
                            author = clipAuthor,
                            active = shortsPager.currentPage == pageIndex,
                            api = api,
                            accessToken = accessToken,
                            userId = userId,
                            onAuthorClick = {
                                task(false) { viewedProfile = clipAuthor ?: api.profile(accessToken, clip.userId) }
                            },
                            onLike = {
                                task(false) {
                                    api.toggleLike(accessToken, userId, clip.id, clip.likedByMe)
                                    clips = api.shortClips(accessToken, userId)
                                }
                            },
                            onSave = {
                                task(false) {
                                    api.toggleShortSave(accessToken, userId, clip.id, clip.savedByMe)
                                    clips = api.shortClips(accessToken, userId)
                                }
                            },
                            onCommentsPosted = {
                                task(false) { clips = api.shortClips(accessToken, userId) }
                            },
                            onPost = { videoPicker.launch("video/*") },
                            onExitShorts = { switchTab(lastNonShortsTab.ifBlank { "rooms" }) }
                        )
                    }
                }
            }
            "gallery" -> {
                SectionHeading("ART / DIY WALL", "Made by members. Hand-made, half-finished, entirely yours.", action = { imagePicker.launch("image/*") }, actionLabel = "+ ART")
                if (artworks.isEmpty()) CenterState("THE WALL IS WAITING", "Share the first drawing, collage, photo, or work in progress.", false, Modifier.weight(1f))
                else LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 13.dp), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 18.dp)) {
                    items(artworks, key = { it.id }) { art -> ArtworkCard(art) {
                        task(false) { viewedProfile = members.firstOrNull { it.id == art.userId } ?: api.profile(accessToken, art.userId) }
                    } }
                }
            }
            "profile" -> {
                val me = profile
                Column(
                    Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("YOUR PATCH", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Black, letterSpacing = 1.7.sp, modifier = Modifier.weight(1f))
                        TextButton(onClick = { beginProfileEdit() }) { Icon(Icons.Default.Edit, contentDescription = "Edit profile", tint = Stamp, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(5.dp)); Text("EDIT PROFILE", color = Stamp, fontWeight = FontWeight.Black, fontSize = 10.sp) }
                    }
                    Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).border(1.dp, Rule, RoundedCornerShape(18.dp)).padding(15.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        ProfileAvatar(profile = me, size = 88.dp, modifier = Modifier.clickable { beginProfileEdit() }, contextDescription = "Tap to customize your profile picture")
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(me?.displayName ?: "ALTROOM MEMBER", color = Paper, fontSize = 25.sp, fontWeight = FontWeight.Black, lineHeight = 29.sp)
                            Text("@${me?.username ?: "member"}", color = Stamp, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            if (me?.role == "owner") {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    FounderBadge()
                                    Text("ALTROOM ORIGINAL", color = Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = .7.sp)
                                }
                            }
                            Text("TAP YOUR PHOTO TO CHANGE IT", color = Muted, fontSize = 9.sp, letterSpacing = .5.sp)
                        }
                    }
                    if (!me?.bio.isNullOrBlank()) Text(me?.bio.orEmpty(), color = Paper, fontSize = 14.sp, lineHeight = 21.sp)
                    else Text("Your bio is your little corner of the internet. Add a line about what makes you, you.", color = Muted, fontSize = 13.sp, lineHeight = 19.sp)
                    RuleLine()
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("INTERESTS", color = Muted, fontWeight = FontWeight.Black, fontSize = 10.sp, letterSpacing = 1.4.sp, modifier = Modifier.weight(1f))
                        TextButton(onClick = { beginProfileEdit() }) { Text("＋ ADD / EDIT", color = Stamp, fontSize = 9.sp, fontWeight = FontWeight.Black) }
                    }
                    if (me?.interests.isNullOrEmpty()) Text("No interests added yet.", color = Muted, fontSize = 13.sp)
                    else Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) { me!!.interests.forEach { Tag(it) } }
                    RuleLine()
                    Text("YOUR ALTROOM", color = Paper, fontWeight = FontWeight.Black, fontSize = 12.sp, letterSpacing = .8.sp)
                    Text("A home for odd interests, art, tiny videos, private chats, audio messages, and people who get it.", color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
                    if (me?.role == "owner") {
                        Button(onClick = {
                            val storedPending = prefs.getStringSet("owner_pending_signup_ids", emptySet())?.toSet() ?: emptySet()
                            pendingSignupIds = storedPending
                            adminSection = if (storedPending.isNotEmpty()) "signups" else "private"
                            errorText = ""
                            page = "admin"
                        }, modifier = Modifier.fillMaxWidth().height(49.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3A2A18), contentColor = FounderGold), shape = RoundedCornerShape(9.dp), border = BorderStroke(1.dp, FounderGold)) {
                            Text(
                                if (pendingSignupIds.isNotEmpty()) "✳ FOUNDER DESK · ${pendingSignupIds.size} NEW SIGNUP${if (pendingSignupIds.size == 1) "" else "S"}"
                                else "✳ FOUNDER SAFETY DESK · SUPER ADMIN",
                                fontWeight = FontWeight.Black, fontSize = 11.sp, letterSpacing = .2.sp
                            )
                        }
                    }
                    Button(onClick = { signOut() }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Panel2, contentColor = Paper), shape = RoundedCornerShape(9.dp)) {
                        Icon(Icons.Default.Logout, contentDescription = "Sign out"); Spacer(Modifier.width(8.dp)); Text("SIGN OUT", fontWeight = FontWeight.Black, letterSpacing = 1.sp)
                    }
                    Spacer(Modifier.height(8.dp))
                }
            }
            else -> CenterState("ALTROOM", "Returning to the room…", true)
        }

        if (page in listOf("rooms", "private", "shorts", "gallery", "profile")) {
            Divider(color = Rule)
            Row(
                Modifier.fillMaxWidth().background(Panel).padding(horizontal = 6.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(3.dp), verticalAlignment = Alignment.CenterVertically
            ) {
                NavChip("ROOMS", Icons.Default.Forum, tab == "rooms", Modifier.weight(1f)) { switchTab("rooms") }
                NavChip("DMs", Icons.Default.ChatBubbleOutline, tab == "private", Modifier.weight(1f), badgeCount = unreadMessageCounts.values.sum().takeIf { it > 0 } ?: unreadConversations.size) { switchTab("private") }
                NavChip("SHORTS", Icons.Default.PlayCircleFilled, tab == "shorts", Modifier.weight(1f)) { switchTab("shorts") }
                NavChip("ART", Icons.Default.Palette, tab == "gallery", Modifier.weight(1f)) { switchTab("gallery") }
                NavChip("ME", Icons.Default.Person, tab == "profile", Modifier.weight(1f)) { switchTab("profile") }
                // Only the account whose Supabase profile role is owner sees this private entry.
                if (profile?.role == "owner") {
                    NavChip(
                        label = "OWNER",
                        icon = Icons.Default.Notifications,
                        active = page == "admin",
                        modifier = Modifier.weight(1f),
                        badgeCount = pendingSignupIds.size
                    ) {
                        adminSection = "signups"
                        errorText = ""
                        infoText = ""
                        page = "admin"
                    }
                }
            }
        }
    }

    if (showChatAttachments) {
        AlertDialog(
            onDismissRequest = { showChatAttachments = false },
            containerColor = Panel,
            title = { Text("ADD TO THE CONVERSATION", color = Paper, fontWeight = FontWeight.Black) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Text("Choose a photo or an audio file. Keep media under 6 MB.", color = Muted, fontSize = 12.sp, lineHeight = 17.sp)
                    Button(onClick = { showChatAttachments = false; selectedChatMediaKind = "image"; chatMediaPicker.launch("image/*") }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Panel2, contentColor = Paper), shape = RoundedCornerShape(3.dp)) { Icon(Icons.Default.Image, null); Spacer(Modifier.width(8.dp)); Text("PHOTO / IMAGE") }
                    Button(onClick = { showChatAttachments = false; selectedChatMediaKind = "audio"; chatMediaPicker.launch("audio/*") }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Panel2, contentColor = Paper), shape = RoundedCornerShape(3.dp)) { Icon(Icons.Default.GraphicEq, null); Spacer(Modifier.width(8.dp)); Text("AUDIO FILE") }
                }
            },
            confirmButton = { TextButton(onClick = { showChatAttachments = false }) { Text("DONE", color = Muted) } }
        )
    }

    if (selectedChatMediaUri != null) {
        AlertDialog(
            onDismissRequest = { selectedChatMediaUri = null },
            containerColor = Panel,
            title = { Text(if (selectedChatMediaKind == "image") "SEND IMAGE" else "SEND AUDIO", color = Paper, fontWeight = FontWeight.Black) },
            text = { Text("This file will be sent to ${if (page == "privateThread") "your private conversation" else "the current room"}.", color = Muted, fontSize = 12.sp) },
            confirmButton = { TextButton(enabled = !busy, onClick = {
                val uri = selectedChatMediaUri ?: return@TextButton
                val kind = selectedChatMediaKind
                task {
                    val limit = 6 * 1024 * 1024
                    val bytes = readPickedBytes(context, uri, limit)
                    val mime = context.contentResolver.getType(uri) ?: if (kind == "image") "image/jpeg" else "audio/mpeg"
                    if (kind == "image" && !mime.startsWith("image/")) throw IOException("Choose an image file.")
                    if (kind == "audio" && !mime.startsWith("audio/")) throw IOException("Choose an audio file.")
                    val ext = when (mime) {
                        "image/png" -> "png"; "image/webp" -> "webp"; "image/gif" -> "gif"; "image/avif" -> "avif"
                        "audio/wav", "audio/x-wav" -> "wav"; "audio/ogg" -> "ogg"; "audio/mp4" -> "m4a"; "audio/aac" -> "aac"; "audio/flac" -> "flac"; else -> if (kind == "image") "jpg" else "mp3"
                    }
                    if (page == "room") {
                        val room = selectedRoom ?: throw IOException("Enter a room first.")
                        api.sendRoomMedia(accessToken, room.id, userId, kind, bytes, mime, ext)
                        roomMessages = api.roomMessages(accessToken, room.id)
                    } else if (page == "privateThread") {
                        val conv = selectedConversation ?: throw IOException("Open a private conversation first.")
                        api.sendPrivateMedia(accessToken, conv.id, userId, kind, bytes, mime, ext)
                        privateMessages = api.privateMessages(accessToken, conv.id)
                    } else throw IOException("Open a room or private conversation before attaching media.")
                    selectedChatMediaUri = null
                    infoText = if (kind == "image") "Image sent." else "Audio sent."
                }
            }) { Text(if (busy) "SENDING…" else "SEND FILE →", color = Paper, fontWeight = FontWeight.Black) } },
            dismissButton = { TextButton(onClick = { selectedChatMediaUri = null }) { Text("CANCEL", color = Muted) } }
        )
    }

    if (showProfileEditor) {
        AlertDialog(
            onDismissRequest = { showProfileEditor = false; selectedAvatarUri = null },
            containerColor = Panel,
            title = { Text("CUSTOMIZE YOUR PATCH", color = Paper, fontWeight = FontWeight.Black, fontSize = 17.sp) },
            text = {
                Column(Modifier.fillMaxWidth().heightIn(max = 520.dp).verticalScroll(rememberScrollState()), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(contentAlignment = Alignment.BottomEnd) {
                        if (selectedAvatarUri != null) {
                            AsyncImage(model = selectedAvatarUri, contentDescription = "Selected profile picture", contentScale = ContentScale.Crop, modifier = Modifier.size(94.dp).clip(RoundedCornerShape(50)).clickable { avatarPicker.launch("image/*") })
                        } else {
                            ProfileAvatar(profile = profile, size = 94.dp, modifier = Modifier.clickable { avatarPicker.launch("image/*") }, contextDescription = "Choose profile picture")
                        }
                        Box(Modifier.size(30.dp).background(Stamp, RoundedCornerShape(50)).clickable { avatarPicker.launch("image/*") }, contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.PhotoCamera, contentDescription = "Change profile picture", tint = Paper, modifier = Modifier.size(16.dp))
                        }
                    }
                    Text("TAP PHOTO TO CHANGE", color = Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = .8.sp)
                    AltField("Display name", editDisplayName, { editDisplayName = it })
                    AltField("Bio · what are you into?", editBio, { editBio = it }, singleLine = false)
                    AltField("Interests · comma separated", editInterests, { editInterests = it }, singleLine = false)
                    Text("Your username and account identity stay the same. Interests appear as profile tags.", color = Muted, fontSize = 10.sp, lineHeight = 15.sp)
                }
            },
            confirmButton = {
                TextButton(enabled = !busy, onClick = {
                    val name = editDisplayName.trim()
                    val bio = editBio.trim()
                    val interests = editInterests.split(",", "\n").map { it.trim() }.filter { it.isNotBlank() }.distinct().take(12)
                    if (name.length !in 2..40) { errorText = "Display name must be 2–40 characters."; return@TextButton }
                    if (bio.length > 200) { errorText = "Bio must be 200 characters or fewer."; return@TextButton }
                    if (interests.any { it.length > 24 }) { errorText = "Each interest must be 24 characters or fewer."; return@TextButton }
                    val avatarUri = selectedAvatarUri
                    task {
                        var avatarPath: String? = null
                        if (avatarUri != null) {
                            val bytes = readPickedBytes(context, avatarUri, 4 * 1024 * 1024)
                            val mime = context.contentResolver.getType(avatarUri) ?: "image/jpeg"
                            if (mime !in listOf("image/jpeg", "image/png", "image/webp", "image/gif", "image/avif")) {
                                throw IOException("Choose a JPG, PNG, WebP, GIF, or AVIF image for your profile picture.")
                            }
                            val ext = when (mime) { "image/png" -> "png"; "image/webp" -> "webp"; "image/gif" -> "gif"; "image/avif" -> "avif"; else -> "jpg" }
                            avatarPath = api.uploadProfileAvatar(accessToken, userId, bytes, mime, ext)
                        }
                        api.updateProfile(accessToken, name, bio, interests, avatarPath)
                        profile = api.profile(accessToken, userId)
                        members = api.members(accessToken)
                        selectedAvatarUri = null
                        showProfileEditor = false
                        infoText = "Your profile has been updated. ✳"
                    }
                }) { Text(if (busy) "SAVING…" else "SAVE PROFILE ✓", color = Stamp, fontWeight = FontWeight.Black) }
            },
            dismissButton = { TextButton(onClick = { showProfileEditor = false; selectedAvatarUri = null }) { Text("CANCEL", color = Muted) } }
        )
    }

    if (viewedProfile != null) {
        val member = viewedProfile!!
        AlertDialog(
            onDismissRequest = { viewedProfile = null },
            containerColor = Panel,
            title = { Text("MEMBER PATCH", color = Paper, fontWeight = FontWeight.Black, fontSize = 16.sp) },
            text = {
                Column(Modifier.fillMaxWidth().heightIn(max = 440.dp).verticalScroll(rememberScrollState()), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    ProfileAvatar(profile = member, size = 100.dp, contextDescription = "Member profile picture")
                    Text(member.displayName, color = Paper, fontWeight = FontWeight.Black, fontSize = 23.sp)
                    Text("@${member.username}", color = Stamp, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    if (member.role == "owner") {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            FounderBadge()
                            Text("ALTROOM ORIGINAL", color = Muted, fontWeight = FontWeight.Bold, fontSize = 9.sp, letterSpacing = .7.sp)
                        }
                    }
                    if (member.bio.isNotBlank()) Text(member.bio, color = Paper, fontSize = 13.sp, lineHeight = 19.sp)
                    if (member.interests.isNotEmpty()) {
                        Text("INTERESTS", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Black, letterSpacing = 1.2.sp)
                        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) { member.interests.forEach { Tag(it) } }
                    }
                }
            },
            confirmButton = {
                TextButton(enabled = !busy, onClick = {
                    viewedProfile = null
                    task {
                        val id = api.openConversation(accessToken, member.id)
                        if (id.isBlank()) throw IOException("ALTROOM couldn't open that private conversation.")
                        clearUnread(id)
                        selectedConversation = PrivateConversation(id, userId, member.id, "")
                        privateOther = member
                        privateMessages = api.privateMessages(accessToken, id)
                        page = "privateThread"; tab = "private"
                    }
                }) { Icon(Icons.Default.Send, contentDescription = "Message member", tint = Stamp); Spacer(Modifier.width(6.dp)); Text("MESSAGE", color = Stamp, fontWeight = FontWeight.Black) }
            },
            dismissButton = { TextButton(onClick = { viewedProfile = null }) { Text("CLOSE", color = Muted) } }
        )
    }

    if (pendingAdminMessage != null) {
        val target = pendingAdminMessage!!
        AlertDialog(
            onDismissRequest = { pendingAdminMessage = null },
            containerColor = Panel,
            title = { Text("REMOVE MESSAGE?", color = Paper, fontWeight = FontWeight.Black) },
            text = { Text("This removes the selected ${if (pendingAdminMessageSource == "private") "private message from the conversation" else "room message from the room"}. The action is recorded in the founder moderation log. This cannot be undone from ALTROOM.", color = Muted, fontSize = 12.sp, lineHeight = 18.sp) },
            confirmButton = {
                TextButton(enabled = !busy, onClick = {
                    val source = pendingAdminMessageSource
                    pendingAdminMessage = null
                    task {
                        if (source == "private") {
                            api.ownerDeletePrivateMessage(accessToken, target.id)
                            adminPrivateMessages = api.ownerRecentPrivateMessages(accessToken)
                        } else {
                            api.ownerDeleteRoomMessage(accessToken, target.contextId, target.id)
                            adminRoomMessages = api.ownerRecentRoomMessages(accessToken)
                        }
                        infoText = "Message removed and moderation action recorded."
                    }
                }) { Text(if (busy) "REMOVING…" else "REMOVE MESSAGE", color = Stamp, fontWeight = FontWeight.Black) }
            },
            dismissButton = { TextButton(onClick = { pendingAdminMessage = null }) { Text("CANCEL", color = Muted) } }
        )
    }

    if (pendingAdminMember != null) {
        val target = pendingAdminMember!!
        val active = pendingAdminMemberActive
        AlertDialog(
            onDismissRequest = { pendingAdminMember = null },
            containerColor = Panel,
            title = { Text(if (active) "RESTORE MEMBER?" else "SUSPEND MEMBER?", color = Paper, fontWeight = FontWeight.Black) },
            text = { Text(if (active) "${target.displayName} will be allowed to access ALTROOM again." else "${target.displayName} will lose access to ALTROOM until restored by the founder. Protected staff and owner accounts cannot be changed here.", color = Muted, fontSize = 12.sp, lineHeight = 18.sp) },
            confirmButton = {
                TextButton(enabled = !busy, onClick = {
                    pendingAdminMember = null
                    task {
                        api.ownerSetMemberApproval(accessToken, target.id, active)
                        adminMembers = api.ownerMembers(accessToken)
                        infoText = if (active) "Member access restored." else "Member account suspended."
                    }
                }) { Text(if (active) "RESTORE ACCESS" else "SUSPEND ACCOUNT", color = if (active) FounderGold else Stamp, fontWeight = FontWeight.Black) }
            },
            dismissButton = { TextButton(onClick = { pendingAdminMember = null }) { Text("CANCEL", color = Muted) } }
        )
    }

    if (showRoomSafetyDialog) {
        val room = selectedRoom
        AlertDialog(
            onDismissRequest = { showRoomSafetyDialog = false },
            containerColor = Panel,
            title = { Text(if (canModerateSelectedRoom) "ROOM STEWARD TOOLS" else "ROOM SAFETY DESK", color = Paper, fontWeight = FontWeight.Black) },
            text = {
                Column(Modifier.fillMaxWidth().heightIn(max = 470.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        if (canModerateSelectedRoom) "You're a steward here. Reported or harmful posts can be removed, repeat offenders can be banned from posting, and trusted members can be promoted to co-stewards."
                        else "See something harmful? Report a message so room stewards can review it. Room creators and moderators can remove posts and restrict repeat offenders.",
                        color = Muted, fontSize = 12.sp, lineHeight = 17.sp
                    )
                    if (canModerateSelectedRoom) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("REPORT QUEUE", color = Paper, fontWeight = FontWeight.Black, fontSize = 11.sp, letterSpacing = .7.sp, modifier = Modifier.weight(1f))
                            TextButton(onClick = { val target = room; if (target != null) task(false) { roomReports = api.roomReports(accessToken, target.id) } }) {
                                Text("REFRESH ↻", color = Stamp, fontWeight = FontWeight.Black, fontSize = 9.sp)
                            }
                        }
                        val openReports = roomReports.filter { it.status == "open" }
                        if (openReports.isEmpty()) {
                            Text("No open reports. The room is quiet for now.", color = Muted, fontSize = 11.sp)
                        } else openReports.forEach { report ->
                            Column(Modifier.fillMaxWidth().background(Color(0xFF2B1A18), RoundedCornerShape(10.dp)).border(1.dp, Stamp, RoundedCornerShape(10.dp)).padding(10.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                Text("REPORTED · ${report.senderName}", color = Stamp, fontSize = 10.sp, fontWeight = FontWeight.Black)
                                Text(report.messageBody.take(130), color = Paper, fontSize = 12.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
                                Text("Reason: ${report.reason}", color = Muted, fontSize = 10.sp)
                                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                                    TextButton(enabled = !busy, onClick = {
                                        val target = room ?: return@TextButton
                                        task {
                                            api.deleteRoomMessage(accessToken, target.id, report.messageId)
                                            roomMessages = api.roomMessages(accessToken, target.id)
                                            roomReports = api.roomReports(accessToken, target.id)
                                            infoText = "Reported message removed."
                                        }
                                    }, contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 6.dp, vertical = 3.dp)) { Text("REMOVE", color = Stamp, fontWeight = FontWeight.Black, fontSize = 9.sp) }
                                    TextButton(enabled = !busy && report.reportedUserId.isNotBlank(), onClick = {
                                        val target = room ?: return@TextButton
                                        task {
                                            api.banRoomMember(accessToken, target.id, report.reportedUserId, "Restricted after report review")
                                            api.updateRoomReportStatus(accessToken, target.id, report.id, "actioned")
                                            roomReports = api.roomReports(accessToken, target.id)
                                            infoText = "Member restricted from posting in this room."
                                        }
                                    }, contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 6.dp, vertical = 3.dp)) { Text("RESTRICT", color = Stamp, fontWeight = FontWeight.Black, fontSize = 9.sp) }
                                    TextButton(enabled = !busy, onClick = {
                                        val target = room ?: return@TextButton
                                        task {
                                            api.updateRoomReportStatus(accessToken, target.id, report.id, "reviewed")
                                            roomReports = api.roomReports(accessToken, target.id)
                                        }
                                    }, contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 6.dp, vertical = 3.dp)) { Text("REVIEWED ✓", color = Paper, fontWeight = FontWeight.Black, fontSize = 9.sp) }
                                }
                                TextButton(enabled = !busy, onClick = {
                                    val target = room ?: return@TextButton
                                    task {
                                        api.updateRoomReportStatus(accessToken, target.id, report.id, "dismissed")
                                        roomReports = api.roomReports(accessToken, target.id)
                                    }
                                }, contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 5.dp, vertical = 2.dp)) { Text("DISMISS REPORT", color = Muted, fontWeight = FontWeight.Black, fontSize = 8.sp) }
                            }
                        }
                        Divider(color = Rule, modifier = Modifier.padding(vertical = 4.dp))
                        Text("RECENT ROOM MESSAGES", color = Paper, fontWeight = FontWeight.Black, fontSize = 11.sp, letterSpacing = .7.sp)
                    }
                    if (roomMessages.isEmpty()) Text("No messages to review yet.", color = Muted, fontSize = 12.sp)
                    roomMessages.takeLast(100).asReversed().forEach { msg ->
                        Column(Modifier.fillMaxWidth().background(Panel2, RoundedCornerShape(10.dp)).border(1.dp, Rule, RoundedCornerShape(10.dp)).padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("${msg.displayName}  ·  ${timeLabel(msg.createdAt)}", color = Stamp, fontWeight = FontWeight.Black, fontSize = 10.sp)
                            Text((msg.body.ifBlank { "[${msg.kind} attachment]" }).take(150), color = Paper, fontSize = 12.sp, lineHeight = 16.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                TextButton(enabled = !busy, onClick = {
                                    val target = room ?: return@TextButton
                                    task {
                                        api.reportRoomMessage(accessToken, target.id, msg.id, "Reported by a room member")
                                        infoText = "Report sent to room stewards. Thanks for helping keep this space safe."
                                    }
                                }, contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 7.dp, vertical = 4.dp)) { Text("⚑ REPORT", color = Muted, fontWeight = FontWeight.Black, fontSize = 9.sp) }
                                if (canModerateSelectedRoom && msg.userId != userId) {
                                    TextButton(enabled = !busy, onClick = {
                                        val target = room ?: return@TextButton
                                        task {
                                            api.deleteRoomMessage(accessToken, target.id, msg.id)
                                            roomMessages = api.roomMessages(accessToken, target.id)
                                            infoText = "Message removed from this room."
                                        }
                                    }, contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 7.dp, vertical = 4.dp)) { Text("✕ DELETE", color = Stamp, fontWeight = FontWeight.Black, fontSize = 9.sp) }
                                    TextButton(enabled = !busy && msg.userId.isNotBlank(), onClick = {
                                        val target = room ?: return@TextButton
                                        task {
                                            api.banRoomMember(accessToken, target.id, msg.userId, "Room safety restriction")
                                            infoText = "Member restricted from posting in this room."
                                        }
                                    }, contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 7.dp, vertical = 4.dp)) { Text("⛔ RESTRICT", color = Stamp, fontWeight = FontWeight.Black, fontSize = 9.sp) }
                                    TextButton(enabled = !busy && msg.userId.isNotBlank(), onClick = {
                                        val target = room ?: return@TextButton
                                        task {
                                            api.promoteRoomModerator(accessToken, target.id, msg.userId)
                                            infoText = "Trusted member added as a room co-steward."
                                        }
                                    }, contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 7.dp, vertical = 4.dp)) { Text("✳ MAKE MOD", color = Paper, fontWeight = FontWeight.Black, fontSize = 9.sp) }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showRoomSafetyDialog = false }) { Text("DONE", color = Paper, fontWeight = FontWeight.Black) } }
        )
    }

    if (showSignalDialog) {
        AlertDialog(
            onDismissRequest = { showSignalDialog = false },
            confirmButton = { TextButton(onClick = { showSignalDialog = false }) { Text("DONE", color = Paper, fontWeight = FontWeight.Black) } },
            containerColor = Panel,
            title = { Text("DROP A SIGNAL ✳", color = Paper, fontWeight = FontWeight.Black) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("No paragraph needed. Send a tiny ALTROOM signal to the room or private chat.", color = Muted, fontSize = 12.sp, lineHeight = 17.sp)
                    listOf("🖤  SAME FREQUENCY", "⚡  I'M HERE", "🦇  AFTERDARK", "🧷  NEED BACKUP", "👁️  I SEE YOU", "✳  JUST EXISTING").forEach { signal ->
                        TextButton(enabled = !busy, onClick = {
                            showSignalDialog = false
                            task {
                                when (page) {
                                    "room" -> {
                                        val room = selectedRoom ?: throw IOException("Enter a room first.")
                                        api.sendRoomMessage(accessToken, room.id, userId, signal)
                                        roomMessages = api.roomMessages(accessToken, room.id)
                                    }
                                    "privateThread" -> {
                                        val conversation = selectedConversation ?: throw IOException("Open a private chat first.")
                                        api.sendPrivateMessage(accessToken, conversation.id, userId, signal)
                                        privateMessages = api.privateMessages(accessToken, conversation.id)
                                    }
                                }
                            }
                        }, modifier = Modifier.fillMaxWidth().background(Panel2, RoundedCornerShape(9.dp)), contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 10.dp)) {
                            Text(signal, color = Paper, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            },
            dismissButton = { TextButton(onClick = { showSignalDialog = false }) { Text("NOT NOW", color = Muted) } }
        )
    }

    if (showCreateRoomDialog) {
        AlertDialog(
            onDismissRequest = { showCreateRoomDialog = false },
            containerColor = Panel,
            title = { Text("MAKE A ROOM", color = Paper, fontWeight = FontWeight.Black) },
            text = { Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Text("Give your corner a name. Keep it specific, kind, and a little weird.", color = Muted, fontSize = 12.sp, lineHeight = 17.sp)
                AltField("Room name (2–32 characters)", newRoomName, { newRoomName = it })
                AltField("Description (optional)", newRoomDescription, { newRoomDescription = it }, singleLine = false)
            } },
            confirmButton = { TextButton(enabled = !busy, onClick = {
                val name = newRoomName.trim(); val description = newRoomDescription.trim()
                if (name.length !in 2..32) { errorText = "Room names must be 2–32 characters."; return@TextButton }
                task {
                    val createdId = api.createRoom(accessToken, name, description)
                    rooms = api.rooms(accessToken)
                    val created = rooms.firstOrNull { it.id == createdId } ?: rooms.firstOrNull { it.name.equals(name, true) }
                        ?: throw IOException("The room was created, but it did not appear in the room list. Refresh and try again.")
                    api.joinRoom(accessToken, created.id)
                    selectedRoom = created; roomMessages = emptyList(); roomReports = emptyList(); canModerateSelectedRoom = false; page = "room"; tab = "rooms"
                    showCreateRoomDialog = false; infoText = "Room created. You're in."
                }
            }) { Text(if (busy) "CREATING…" else "CREATE ROOM →", color = Paper, fontWeight = FontWeight.Black) } },
            dismissButton = { TextButton(onClick = { showCreateRoomDialog = false }) { Text("CANCEL", color = Muted) } }
        )
    }

    if (selectedVideoUri != null) {
        AlertDialog(
            onDismissRequest = { selectedVideoUri = null },
            containerColor = Panel,
            title = { Text("POST A CLIP", color = Paper, fontWeight = FontWeight.Black) },
            text = { Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Video must be 30 seconds or less and under 18 MB.", color = Muted, fontSize = 12.sp)
                AltField("Caption (optional)", clipCaption, { clipCaption = it }, singleLine = false)
            } },
            confirmButton = { TextButton(enabled = !busy, onClick = {
                val uri = selectedVideoUri ?: return@TextButton
                task {
                    val bytes = readPickedBytes(context, uri, 18 * 1024 * 1024)
                    val duration = videoDurationMs(context, uri)
                    if (duration <= 0) throw IOException("Could not read the clip duration. Try an MP4 file.")
                    if (duration > 30_050) throw IOException("This clip is ${(duration / 1000.0)} seconds. ALTROOM accepts 30 seconds or less.")
                    val mime = context.contentResolver.getType(uri) ?: "video/mp4"
                    val ext = when (mime) { "video/webm" -> "webm"; "video/quicktime" -> "mov"; else -> "mp4" }
                    api.uploadClip(accessToken, userId, clipCaption, bytes, mime, ext)
                    clips = api.shortClips(accessToken, userId)
                    selectedVideoUri = null; infoText = "Your clip was posted to the video club."
                }
            }) { Text(if (busy) "UPLOADING…" else "POST CLIP", color = Paper, fontWeight = FontWeight.Black) } },
            dismissButton = { TextButton(onClick = { selectedVideoUri = null }) { Text("CANCEL", color = Muted) } }
        )
    }

    if (selectedImageUri != null) {
        AlertDialog(
            onDismissRequest = { selectedImageUri = null },
            containerColor = Panel,
            title = { Text("ADD TO THE ART WALL", color = Paper, fontWeight = FontWeight.Black) },
            text = { Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Choose a title. Images must be under 6 MB.", color = Muted, fontSize = 12.sp)
                AltField("Artwork title", artTitle, { artTitle = it })
                AltField("Caption (optional)", artCaption, { artCaption = it }, singleLine = false)
            } },
            confirmButton = { TextButton(enabled = !busy, onClick = {
                val uri = selectedImageUri ?: return@TextButton
                task {
                    if (artTitle.isBlank()) throw IOException("Give your artwork a title.")
                    val bytes = readPickedBytes(context, uri, 6 * 1024 * 1024)
                    val mime = context.contentResolver.getType(uri) ?: "image/jpeg"
                    if (mime !in listOf("image/jpeg", "image/png", "image/webp", "image/gif", "image/avif")) throw IOException("Choose a JPG, PNG, WebP, GIF, or AVIF image.")
                    val ext = when (mime) { "image/png" -> "png"; "image/webp" -> "webp"; "image/gif" -> "gif"; "image/avif" -> "avif"; else -> "jpg" }
                    api.uploadArtwork(accessToken, userId, artTitle, artCaption, bytes, mime, ext)
                    artworks = api.gallery(accessToken)
                    selectedImageUri = null; infoText = "Your artwork was added to the wall."
                }
            }) { Text(if (busy) "UPLOADING…" else "SHARE ART", color = Paper, fontWeight = FontWeight.Black) } },
            dismissButton = { TextButton(onClick = { selectedImageUri = null }) { Text("CANCEL", color = Muted) } }
        )
    }
}

@Composable
private fun AuthScreen(
    mode: String, name: String, onName: (String) -> Unit, email: String, onEmail: (String) -> Unit,
    password: String, onPassword: (String) -> Unit, busy: Boolean, info: String, error: String,
    onMode: (String) -> Unit, onSubmit: () -> Unit
) {
    Column(Modifier.fillMaxSize().background(Ink).padding(horizontal = 23.dp, vertical = 19.dp).imePadding(), verticalArrangement = Arrangement.Center) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(45.dp).background(Paper), contentAlignment = Alignment.Center) { Text("✳", color = Ink, fontSize = 29.sp, fontWeight = FontWeight.Black) }
            Spacer(Modifier.width(12.dp))
            Column { Text("ALTROOM", color = Paper, fontSize = 28.sp, fontWeight = FontWeight.Black, letterSpacing = (-1).sp); Text("NOT BUILT FOR EVERYONE.", color = Muted, fontSize = 9.sp, letterSpacing = 1.4.sp) }
        }
        Spacer(Modifier.height(30.dp))
        Text(if (mode == "login") "COME BACK IN." else "MAKE A LITTLE SPACE.", color = Paper, fontSize = 29.sp, fontWeight = FontWeight.Black, lineHeight = 33.sp)
        Text(if (mode == "login") "Your people are in here." else "A room for the niche, the strange, the handmade.", color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 7.dp, bottom = 19.dp))
        if (mode == "signup") AltField("Display name", name, onName)
        AltField("Email", email, onEmail, keyboardType = KeyboardType.Email)
        AltField("Password", password, onPassword, isPassword = true, keyboardType = KeyboardType.Password, imeAction = ImeAction.Done)
        if (error.isNotBlank()) Text(error, color = Color(0xFFFF9E93), fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))
        if (info.isNotBlank()) Text(info, color = Paper, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))
        Button(onClick = onSubmit, enabled = !busy, modifier = Modifier.fillMaxWidth().padding(top = 13.dp).height(51.dp), shape = RoundedCornerShape(3.dp), colors = ButtonDefaults.buttonColors(containerColor = Paper, contentColor = Ink)) {
            if (busy) CircularProgressIndicator(Modifier.size(19.dp), strokeWidth = 2.dp, color = Ink) else Text(if (mode == "login") "ENTER ALTROOM →" else "CREATE ACCOUNT →", fontWeight = FontWeight.Black, letterSpacing = 1.sp)
        }
        Row(Modifier.fillMaxWidth().padding(top = 13.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
            Text(if (mode == "login") "NEW AROUND HERE?" else "ALREADY HAVE AN ACCOUNT?", color = Muted, fontSize = 10.sp, letterSpacing = .8.sp)
            TextButton(onClick = { onMode(if (mode == "login") "signup" else "login") }) { Text(if (mode == "login") "SIGN UP" else "SIGN IN", color = Paper, fontWeight = FontWeight.Black, fontSize = 11.sp) }
        }
        Spacer(Modifier.height(14.dp))
        Text("OPEN SIGNUP · GROWS WITH THE LIMITS OF THE PLATFORM", color = Rule, fontSize = 8.sp, letterSpacing = .5.sp)
    }
}

@Composable
private fun PendingAccessScreen(info: String, onRetry: () -> Unit, onSignOut: () -> Unit) {
    Column(
        Modifier.fillMaxSize().background(Ink).padding(horizontal = 24.dp, vertical = 20.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.Start
    ) {
        Text("ONE MOMENT.", color = Paper, fontSize = 30.sp, fontWeight = FontWeight.Black, lineHeight = 34.sp)
        Text(
            "ALTROOM has open signup. New accounts are activated securely; accounts restricted by a moderator cannot activate themselves.",
            color = Muted, fontSize = 13.sp, lineHeight = 19.sp,
            modifier = Modifier.padding(top = 12.dp, bottom = 15.dp)
        )
        if (info.isNotBlank()) {
            Text(info, color = Color(0xFFFFB8AD), fontSize = 12.sp, lineHeight = 17.sp, modifier = Modifier.padding(bottom = 12.dp))
        }
        Button(
            onClick = onRetry,
            modifier = Modifier.fillMaxWidth().height(50.dp),
            shape = RoundedCornerShape(3.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Paper, contentColor = Ink)
        ) { Text("CHECK ACCESS AGAIN ↻", fontWeight = FontWeight.Black, letterSpacing = .6.sp) }
        TextButton(onClick = onSignOut, modifier = Modifier.align(Alignment.CenterHorizontally)) { Text("SIGN OUT", color = Muted) }
    }
}

@Composable
private fun SectionHeading(title: String, subtitle: String, action: (() -> Unit)? = null, actionLabel: String = "↻") {
    Row(Modifier.fillMaxWidth().padding(horizontal = 17.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Paper, fontWeight = FontWeight.Black, fontSize = 20.sp, letterSpacing = (-.5).sp)
            Text(subtitle, color = Muted, fontSize = 11.sp, lineHeight = 15.sp, modifier = Modifier.padding(top = 3.dp))
        }
        if (action != null) {
            Spacer(Modifier.width(8.dp))
            Button(onClick = action, colors = ButtonDefaults.buttonColors(containerColor = Panel2, contentColor = Paper), shape = RoundedCornerShape(2.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 11.dp, vertical = 7.dp)) {
                Text(actionLabel, fontSize = 10.sp, fontWeight = FontWeight.Black, letterSpacing = .7.sp)
            }
        }
    }
    Divider(color = Rule)
}

@Composable
private fun RoomCard(room: AltroomRoom, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth()
            .background(Panel, RoundedCornerShape(14.dp))
            .border(1.dp, Rule, RoundedCornerShape(14.dp))
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 15.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(42.dp).background(Ink, RoundedCornerShape(12.dp)).border(1.dp, Rule, RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.Forum, contentDescription = "Community room", tint = Stamp, modifier = Modifier.size(21.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(room.name, color = Paper, fontWeight = FontWeight.Black, fontSize = 15.sp, letterSpacing = .1.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(room.description.ifBlank { "A corner of ALTROOM" }, color = Muted, fontSize = 12.sp, lineHeight = 16.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 4.dp))
        }
        Spacer(Modifier.width(8.dp))
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Enter room", tint = Stamp, modifier = Modifier.size(18.dp).graphicsLayer(rotationZ = 180f))
            Text("ENTER", color = Stamp, fontWeight = FontWeight.Black, fontSize = 8.sp, letterSpacing = .6.sp)
        }
    }
}

@Composable
private fun MessageCard(
    message: AltroomMessage,
    own: Boolean,
    profile: AltroomProfile? = null,
    onProfileClick: (() -> Unit)? = null,
    onJoinCall: (String, String) -> Unit = { _, _ -> },
    privateStyle: Boolean = false
) {
    val callParts = message.body.split('|')
    val isCallInvite = message.body.startsWith("ALTROOM_CALL|") && callParts.size >= 3 && callParts[2].isNotBlank() && callParts[1] in listOf("audio", "video")
    Row(Modifier.fillMaxWidth().padding(horizontal = if (privateStyle) 2.dp else 0.dp, vertical = if (privateStyle) 5.dp else 2.dp), horizontalArrangement = if (own) Arrangement.End else Arrangement.Start, verticalAlignment = Alignment.Bottom) {
        if (!own) {
            ProfileAvatar(profile = profile ?: AltroomProfile("", message.username, message.displayName, "", emptyList(), true, "member"), size = 32.dp,
                modifier = if (onProfileClick != null) Modifier.clickable { onProfileClick() } else Modifier,
                contextDescription = "View ${message.displayName}'s profile")
            Spacer(Modifier.width(8.dp))
        }
        val bubbleShape = if (own) RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp, bottomStart = 18.dp, bottomEnd = 5.dp) else RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp, bottomStart = 5.dp, bottomEnd = 18.dp)
        // Bubbles are content-sized: this percentage is only the maximum for long messages.
        val bubbleWidth = if (privateStyle) { if (own) .72f else .70f } else { if (own) .76f else .82f }
        val bubbleColor = if (own) { if (privateStyle) Color(0xFF36201F) else Color(0xFF292720) } else { if (privateStyle) Color(0xFF171B20) else Color(0xFF141414) }
        val bubbleBorder = if (own) { if (privateStyle) Color(0xFF925148) else Color(0xFF66584D) } else { if (privateStyle) Color(0xFF39434C) else Color(0xFF45443F) }
        val screenWidth = LocalConfiguration.current.screenWidthDp.dp
        val maxBubbleWidth = screenWidth * bubbleWidth
        Column(Modifier.widthIn(max = maxBubbleWidth).wrapContentWidth(Alignment.Start).animateContentSize().background(bubbleColor, bubbleShape).border(1.dp, bubbleBorder, bubbleShape).padding(horizontal = if (privateStyle) 9.dp else 14.dp, vertical = if (privateStyle) 8.dp else 12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(if (own) "YOU" else message.displayName.uppercase(), color = if (own && privateStyle) Stamp else if (own) Paper else if (privateStyle) Color(0xFFB7C7D8) else Stamp, fontWeight = FontWeight.Black, fontSize = 10.sp, letterSpacing = .6.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = if (profile?.role == "owner") 112.dp else 165.dp).let { if (onProfileClick != null) it.clickable { onProfileClick() } else it })
                if (profile?.role == "owner") {
                    Spacer(Modifier.width(4.dp))
                    FounderBadge(compact = true)
                }
                Spacer(Modifier.width(7.dp))
                Text(timeLabel(message.createdAt), color = Muted, fontSize = 9.sp)
            }
            Spacer(Modifier.height(5.dp))
            when {
                isCallInvite -> {
                    val kind = callParts[1]
                    Row(Modifier.fillMaxWidth().background(Ink).border(1.dp, Stamp).clickable { onJoinCall(kind, callParts[2]) }.padding(horizontal = 12.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(if (kind == "video") Icons.Default.Videocam else Icons.Default.Call, null, tint = Stamp)
                        Spacer(Modifier.width(9.dp))
                        Column(Modifier.weight(1f)) {
                            Text("${kind.uppercase()} CALL", color = Paper, fontWeight = FontWeight.Black, fontSize = 12.sp)
                            Text("Tap to join inside ALTROOM", color = Muted, fontSize = 10.sp)
                        }
                        Text("JOIN ↗", color = Stamp, fontWeight = FontWeight.Black, fontSize = 10.sp)
                    }
                }
                message.kind == "sticker" -> Text((message.stickerEmoji + " " + message.stickerText).trim().ifBlank { "Sticker" }, color = Paper, fontSize = 22.sp)
                message.kind == "image" -> {
                    if (message.mediaUrl.isNotBlank()) AsyncImage(model = message.mediaUrl, contentDescription = "Shared image", contentScale = ContentScale.Crop, modifier = Modifier.fillMaxWidth().height(220.dp).clip(RoundedCornerShape(3.dp)).background(Ink))
                    else EmptyCard("IMAGE UNAVAILABLE", "The media link could not be loaded. Refresh the conversation.")
                }
                message.kind == "audio" -> {
                    if (message.mediaUrl.isNotBlank()) AudioMessagePlayer(message.mediaUrl)
                    else EmptyCard("AUDIO UNAVAILABLE", "The audio link could not be loaded. Refresh the conversation.")
                }
                message.kind == "video" -> {
                    if (message.mediaUrl.isNotBlank()) VideoMessagePlayer(message.mediaUrl)
                    else EmptyCard("VIDEO UNAVAILABLE", "The video link could not be loaded. Refresh the conversation.")
                }
                else -> Text(message.body, color = Paper, fontSize = 14.sp, lineHeight = 19.sp)
            }
        }
        if (own) {
            Spacer(Modifier.width(8.dp))
            ProfileAvatar(profile = profile, size = 32.dp, modifier = if (onProfileClick != null) Modifier.clickable { onProfileClick() } else Modifier, contextDescription = "Your profile picture")
        }
    }
}

@Composable
private fun AudioMessagePlayer(url: String) {
    val player = remember(url) { MediaPlayer() }
    var prepared by remember(url) { mutableStateOf(false) }
    var playing by remember(url) { mutableStateOf(false) }
    var failed by remember(url) { mutableStateOf(false) }
    var position by remember(url) { mutableStateOf(0) }
    var duration by remember(url) { mutableStateOf(0) }
    var playbackSpeed by remember(url) { mutableStateOf(1.0f) }
    val context = LocalContext.current

    LaunchedEffect(url) {
        try {
            player.setAudioAttributes(AudioAttributes.Builder().setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            player.setDataSource(url)
            player.setOnPreparedListener { mp -> duration = mp.duration.coerceAtLeast(0); prepared = true }
            player.setOnCompletionListener { playing = false; position = 0; try { it.seekTo(0) } catch (_: Exception) {} }
            player.setOnErrorListener { _, _, _ -> failed = true; playing = false; true }
            player.prepareAsync()
        } catch (_: Exception) { failed = true }
    }
    LaunchedEffect(playing, prepared) {
        while (playing && prepared) {
            try { position = player.currentPosition.coerceAtLeast(0) } catch (_: Exception) { playing = false }
            delay(250)
        }
    }
    DisposableEffect(url) { onDispose { try { player.stop() } catch (_: Exception) {}; try { player.release() } catch (_: Exception) {} } }

    Row(Modifier.fillMaxWidth().background(Ink, RoundedCornerShape(12.dp)).border(1.dp, Rule, RoundedCornerShape(12.dp)).padding(horizontal = 7.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.GraphicEq, contentDescription = "Audio message", tint = Stamp, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(4.dp))
        IconButton(onClick = {
            if (!prepared || failed) return@IconButton
            try { if (playing) { player.pause(); playing = false } else { player.start(); playing = true } } catch (_: Exception) { failed = true }
        }, enabled = prepared && !failed, modifier = Modifier.size(42.dp).background(Panel2, RoundedCornerShape(50))) {
            Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, contentDescription = if (playing) "Pause audio" else "Play audio", tint = Paper)
        }
        Spacer(Modifier.width(7.dp))
        Column(Modifier.weight(1f)) {
            Text(if (failed) "CAN'T PLAY THIS AUDIO" else if (!prepared) "LOADING AUDIO…" else "AUDIO MESSAGE", color = Paper, fontSize = 10.sp, fontWeight = FontWeight.Black, letterSpacing = .6.sp)
            Slider(value = if (duration > 0) position.toFloat().coerceIn(0f, duration.toFloat()) else 0f, onValueChange = { value ->
                position = value.toInt()
                if (prepared) try { player.seekTo(position) } catch (_: Exception) {}
            }, valueRange = 0f..(duration.toFloat().coerceAtLeast(1f)), enabled = prepared && !failed, colors = SliderDefaults.colors(thumbColor = Stamp, activeTrackColor = Stamp, inactiveTrackColor = Rule), modifier = Modifier.height(22.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text("${audioTime(position)} / ${audioTime(duration)}", color = Muted, fontSize = 9.sp)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = {
                        playbackSpeed = when (playbackSpeed) { 1.0f -> 1.25f; 1.25f -> 1.5f; 1.5f -> 2.0f; else -> 1.0f }
                        if (prepared) try { player.playbackParams = player.playbackParams.setSpeed(playbackSpeed) } catch (_: Exception) { }
                    }, enabled = prepared && !failed, contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 5.dp, vertical = 0.dp)) {
                        Icon(Icons.Default.Speed, contentDescription = "Change playback speed", tint = Stamp, modifier = Modifier.size(14.dp))
                        Spacer(Modifier.width(3.dp)); Text("${playbackSpeed}x", color = Stamp, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                    IconButton(onClick = {
                        try {
                            val pathExtension = Uri.parse(url).lastPathSegment.orEmpty().substringAfterLast('.', "mp3").lowercase(Locale.ROOT)
                            val extension = pathExtension.takeIf { it in setOf("mp3", "m4a", "aac", "wav", "ogg", "opus", "flac", "webm") } ?: "mp3"
                            val request = DownloadManager.Request(Uri.parse(url))
                                .setTitle("ALTROOM audio message")
                                .setDescription("Downloading audio message")
                                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "ALTROOM_Audio_${System.currentTimeMillis()}.$extension")
                            (context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
                        } catch (_: Exception) { }
                    }, modifier = Modifier.size(30.dp)) {
                        Icon(Icons.Default.Download, contentDescription = "Download audio message", tint = Paper, modifier = Modifier.size(17.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun VideoMessagePlayer(url: String) {
    AndroidView(
        modifier = Modifier.fillMaxWidth().height(220.dp).background(Color.Black),
        factory = { ctx -> VideoView(ctx).apply {
            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            setMediaController(MediaController(ctx).also { it.setAnchorView(this) })
            setVideoURI(Uri.parse(url))
        } },
        update = { view -> if (view.tag != url) { view.tag = url; view.setVideoURI(Uri.parse(url)) } }
    )
}

@Composable
private fun FounderBadge(compact: Boolean = false) {
    val edge = if (compact) 15.dp else 27.dp
    Box(
        Modifier.size(edge).background(Color(0xFF171718), RoundedCornerShape(if (compact) 5.dp else 8.dp))
            .border(1.dp, Stamp.copy(alpha = .95f), RoundedCornerShape(if (compact) 5.dp else 8.dp)),
        contentAlignment = Alignment.Center
    ) {
        // A small four-point mark: an ALTROOM signature, not a yellow text label.
        Text("✦", color = Paper, fontSize = if (compact) 9.sp else 16.sp, fontWeight = FontWeight.Black, lineHeight = if (compact) 10.sp else 17.sp)
    }
}

@Composable
private fun OwnerModerationMessageCard(
    message: AltroomModerationMessage,
    privateMessage: Boolean,
    onDelete: () -> Unit
) {
    Column(
        Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(10.dp))
            .border(1.dp, if (privateMessage) Color(0xFF6A4931) else Rule, RoundedCornerShape(10.dp))
            .padding(11.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text(message.contextLabel, color = FounderGold, fontSize = 9.sp, fontWeight = FontWeight.Black, lineHeight = 13.sp, letterSpacing = .35.sp)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text(message.displayName, color = Paper, fontSize = 12.sp, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    if (message.username.isNotBlank()) Text("@${message.username}", color = Muted, fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Text("${message.kind.uppercase()} · ${message.createdAt.replace('T', ' ').take(16)}", color = Muted, fontSize = 8.sp, letterSpacing = .2.sp)
            }
            TextButton(onClick = onDelete, contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 3.dp)) {
                Text("REMOVE", color = Stamp, fontWeight = FontWeight.Black, fontSize = 9.sp)
            }
        }
        val preview = message.body.takeIf { it.isNotBlank() } ?: when (message.kind.lowercase()) {
            "audio" -> "[Audio attachment]"
            "image" -> "[Image attachment]"
            "video" -> "[Video attachment]"
            "sticker" -> "[Sticker]"
            else -> "[No text body]"
        }
        Text(preview.take(500), color = Paper, fontSize = 12.sp, lineHeight = 17.sp)
        Text(if (privateMessage) "PRIVATE MESSAGE · FOUNDER-ONLY QUEUE" else "ROOM MESSAGE · GLOBAL MODERATION", color = Muted, fontSize = 8.sp, letterSpacing = .35.sp)
    }
}

@Composable
private fun OwnerAdminMemberCard(
    member: AltroomAdminMember,
    onChangeStatus: (Boolean) -> Unit
) {
    val active = member.approved && member.accountStatus == "active"
    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(10.dp)).border(1.dp, if (active) Rule else Color(0xFF6A4931), RoundedCornerShape(10.dp)).padding(11.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(member.displayName, color = Paper, fontSize = 12.sp, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("@${member.username} · ${member.role.uppercase()} · ${member.accountStatus.uppercase()}", color = Muted, fontSize = 9.sp, lineHeight = 13.sp)
            }
            Text(if (active) "ACTIVE" else "RESTRICTED", color = if (active) FounderGold else Stamp, fontSize = 8.sp, fontWeight = FontWeight.Black, letterSpacing = .3.sp)
        }
        if (member.role == "member") {
            TextButton(onClick = { onChangeStatus(!active) }, contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 3.dp, vertical = 5.dp)) {
                Text(if (active) "SUSPEND MEMBER ACCESS" else "RESTORE MEMBER ACCESS", color = if (active) Stamp else FounderGold, fontSize = 9.sp, fontWeight = FontWeight.Black)
            }
        } else {
            Text("Protected staff account · status cannot be changed from this list.", color = Muted, fontSize = 9.sp, lineHeight = 13.sp, modifier = Modifier.padding(top = 5.dp))
        }
    }
}

@Composable
private fun MemberCard(
    member: AltroomProfile?,
    subtitle: String,
    unreadCount: Int = 0,
    onProfileClick: (() -> Unit)? = null,
    onClick: () -> Unit
) {
    val unread = unreadCount > 0
    val name = member?.displayName ?: "ALTROOM member"
    Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(10.dp)).border(1.dp, if (unread) Stamp else Rule, RoundedCornerShape(10.dp)).clickable(onClick = onClick).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
        ProfileAvatar(profile = member, size = 43.dp, modifier = if (onProfileClick != null) Modifier.clickable { onProfileClick() } else Modifier, contextDescription = "View $name profile")
        Spacer(Modifier.width(11.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                Text(name, color = Paper, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (member?.role == "owner") FounderBadge(compact = true)
            }
            Text(subtitle, color = if (unread) Stamp else Muted, fontSize = 10.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
        if (unread) Box(Modifier.widthIn(min = 20.dp).height(20.dp).background(Stamp, RoundedCornerShape(50)).padding(horizontal = 5.dp), contentAlignment = Alignment.Center) {
            Text(unreadCount.coerceAtMost(99).toString(), color = Ink, fontSize = 10.sp, fontWeight = FontWeight.Black)
        } else Text("↗", color = Stamp, fontWeight = FontWeight.Black, fontSize = 15.sp)
    }
}

@Composable
private fun ProfileAvatar(profile: AltroomProfile?, size: androidx.compose.ui.unit.Dp, modifier: Modifier = Modifier, contextDescription: String = "Profile picture") {
    val name = profile?.displayName ?: "ALTROOM member"
    val avatarUrl = profile?.avatarUrl.orEmpty()
    var imageFailed by remember(avatarUrl) { mutableStateOf(false) }
    Box(
        modifier.size(size).clip(RoundedCornerShape(50)).background(Panel2)
            .border(1.dp, Rule, RoundedCornerShape(50)),
        contentAlignment = Alignment.Center
    ) {
        // Keep a legible fallback behind the image so broken/expired URLs never render as an empty circle.
        if (avatarUrl.isBlank() || imageFailed) {
            Text(initials(name), color = Paper, fontWeight = FontWeight.Black, fontSize = (size.value * .29f).sp)
        }
        if (avatarUrl.isNotBlank() && !imageFailed) {
            AsyncImage(
                model = avatarUrl,
                contentDescription = contextDescription,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
                onState = { state -> if (state is AsyncImagePainter.State.Error) imageFailed = true }
            )
        }
        if (profile?.role == "owner") {
            Box(Modifier.align(Alignment.BottomEnd).size(size * .31f).background(Ink, RoundedCornerShape(50)).border(1.2.dp, Stamp, RoundedCornerShape(50)), contentAlignment = Alignment.Center) {
                Text("✦", color = Paper, fontWeight = FontWeight.Black, fontSize = (size.value * .17f).sp, lineHeight = (size.value * .18f).sp)
            }
        }
    }
}

@OptIn(androidx.media3.common.util.UnstableApi::class, ExperimentalMaterial3Api::class)
@Composable
private fun ClipCard(
    clip: ShortClip,
    author: AltroomProfile?,
    active: Boolean,
    api: AltroomApi,
    accessToken: String,
    userId: String,
    onLike: () -> Unit,
    onSave: () -> Unit,
    onCommentsPosted: () -> Unit = {},
    onPost: () -> Unit = {},
    onAuthorClick: () -> Unit = {},
    onExitShorts: () -> Unit = {}
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val commentScope = rememberCoroutineScope()
    var showComments by remember(clip.id) { mutableStateOf(false) }
    var clipComments by remember(clip.id) { mutableStateOf<List<ShortClipComment>>(emptyList()) }
    var commentDraft by remember(clip.id) { mutableStateOf("") }
    var commentsLoading by remember(clip.id) { mutableStateOf(false) }
    var commentsPosting by remember(clip.id) { mutableStateOf(false) }
    var commentsError by remember(clip.id) { mutableStateOf("") }
    var replyingTo by remember(clip.id) { mutableStateOf<ShortClipComment?>(null) }
    var isPlaying by remember(clip.id) { mutableStateOf(true) }
    var heartVisible by remember(clip.id) { mutableStateOf(false) }
    val commentSheetState = rememberModalBottomSheetState(skipPartiallyExpanded = false)
    val heartScope = rememberCoroutineScope()

    val clipPlayer = remember(clip.id, clip.mediaUrl) {
        androidx.media3.exoplayer.ExoPlayer.Builder(context).build().apply {
            repeatMode = androidx.media3.common.Player.REPEAT_MODE_ONE
            setVolume(1f)
            playWhenReady = false
        }
    }
    LaunchedEffect(clip.mediaUrl, clipPlayer) {
        if (clip.mediaUrl.isNotBlank()) {
            clipPlayer.setMediaItem(androidx.media3.common.MediaItem.fromUri(clip.mediaUrl))
            clipPlayer.prepare()
        }
    }
    LaunchedEffect(active, isPlaying, showComments, clipPlayer) {
        if (active && isPlaying && !showComments) clipPlayer.play() else clipPlayer.pause()
    }
    // Explicitly pause on lifecycle loss; changing screens already releases this player's view,
    // but the lifecycle guard also covers notification shade, Home, and lock-screen transitions.
    DisposableEffect(lifecycleOwner, clipPlayer, active, isPlaying, showComments) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_PAUSE, Lifecycle.Event.ON_STOP -> clipPlayer.pause()
                Lifecycle.Event.ON_RESUME -> if (active && isPlaying && !showComments) clipPlayer.play() else clipPlayer.pause()
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }
    LaunchedEffect(showComments, clip.id) {
        if (showComments) {
            commentsLoading = true
            commentsError = ""
            try {
                clipComments = api.shortComments(accessToken, clip.id)
            } catch (e: Exception) {
                commentsError = readableError(e)
            } finally {
                commentsLoading = false
            }
        }
    }
    DisposableEffect(clipPlayer) {
        onDispose { clipPlayer.pause(); clipPlayer.release() }
    }

    fun submitShortComment() {
        val text = commentDraft.trim()
        if (text.isBlank() || commentsPosting) return
        val target = replyingTo
        commentScope.launch {
            commentsPosting = true
            commentsError = ""
            try {
                // Replies are grouped under the original comment (single-level threads keep the sheet readable).
                val rootParentId = target?.let { it.parentCommentId ?: it.id }
                api.postShortComment(accessToken, userId, clip.id, text, rootParentId)
                commentDraft = ""
                replyingTo = null
                clipComments = api.shortComments(accessToken, clip.id)
                onCommentsPosted()
            } catch (e: Exception) {
                commentsError = readableError(e)
            } finally {
                commentsPosting = false
            }
        }
    }

    BoxWithConstraints(Modifier.fillMaxSize().background(Color.Black)) {
        // Use shorter, bottom-anchored actions on small screens so they do not cover the caption.
        val compactShorts = maxHeight < 650.dp
        val actionButtonSize = if (compactShorts) 34.dp else 40.dp
        val actionIconSize = if (compactShorts) 19.dp else 23.dp
        val actionBottomClearance = if (compactShorts) 180.dp else 190.dp
        if (clip.mediaUrl.isNotBlank()) {
            AndroidView(
                modifier = Modifier.fillMaxSize().background(Color.Black)
                    .pointerInput(clip.id, isPlaying, showComments, clip.likedByMe) {
                        detectTapGestures(
                            onTap = { if (!showComments) isPlaying = !isPlaying },
                            onDoubleTap = {
                                if (!clip.likedByMe) onLike()
                                heartVisible = true
                                heartScope.launch { delay(720); heartVisible = false }
                            }
                        )
                    },
                factory = { ctx ->
                    androidx.media3.ui.PlayerView(ctx).apply {
                        useController = false
                        resizeMode = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT
                        setShutterBackgroundColor(android.graphics.Color.TRANSPARENT)
                        setKeepContentOnPlayerReset(true)
                        player = clipPlayer
                        contentDescription = "Short video by ${author?.displayName ?: "ALTROOM member"}. Tap to pause or play; double tap to like."
                    }
                },
                update = { view ->
                    view.resizeMode = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT
                    if (view.player !== clipPlayer) view.player = clipPlayer
                }
            )
        } else Box(Modifier.fillMaxSize().background(Ink), contentAlignment = Alignment.Center) { Text("VIDEO UNAVAILABLE", color = Muted, fontSize = 11.sp) }

        // Transparent floating chrome keeps the clip itself full-bleed instead of adding black bands.
        Row(Modifier.align(Alignment.TopStart).fillMaxWidth().padding(start = 6.dp, end = 8.dp, top = 5.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(
                onClick = onExitShorts,
                modifier = Modifier.size(38.dp).background(Color.Black.copy(alpha = .28f), RoundedCornerShape(50))
            ) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back to ALTROOM tabs", tint = Paper, modifier = Modifier.size(21.dp))
            }
            Column(Modifier.weight(1f).padding(start = 4.dp)) {
                Text("ALTROOM", color = Paper, fontWeight = FontWeight.Black, fontSize = 12.sp, letterSpacing = 1.4.sp,
                    style = androidx.compose.ui.text.TextStyle(shadow = Shadow(Color.Black.copy(alpha = .65f), androidx.compose.ui.geometry.Offset(1f, 1f), 3f)))
                Text("VIDEO CLUB · ${dateLabel(clip.createdAt)}", color = Paper.copy(alpha = .83f), fontWeight = FontWeight.Bold, fontSize = 9.sp,
                    style = androidx.compose.ui.text.TextStyle(shadow = Shadow(Color.Black.copy(alpha = .7f), androidx.compose.ui.geometry.Offset(1f, 1f), 3f)))
            }
            IconButton(onClick = onPost, modifier = Modifier.size(38.dp).background(Color.Black.copy(alpha = .20f), RoundedCornerShape(50))) {
                Icon(Icons.Default.Add, contentDescription = "Post a new short video", tint = Paper)
            }
        }
        Column(
            Modifier.align(Alignment.BottomEnd)
                .padding(end = if (compactShorts) 4.dp else 6.dp, bottom = actionBottomClearance)
                .width(if (compactShorts) 42.dp else 48.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(if (compactShorts) 0.dp else 2.dp)
        ) {
            IconButton(onClick = onLike, modifier = Modifier.size(actionButtonSize).background(Color.Black.copy(alpha = .24f), RoundedCornerShape(50))) {
                Icon(if (clip.likedByMe) Icons.Default.Favorite else Icons.Default.FavoriteBorder, contentDescription = "Like clip", tint = if (clip.likedByMe) Stamp else Paper, modifier = Modifier.size(actionIconSize))
            }
            Text("${clip.likeCount}", color = Paper, fontWeight = FontWeight.Black, fontSize = 10.sp,
                style = androidx.compose.ui.text.TextStyle(shadow = Shadow(Color.Black.copy(alpha = .8f), androidx.compose.ui.geometry.Offset(1f, 1f), 3f)), modifier = Modifier.padding(bottom = 2.dp))
            IconButton(onClick = { showComments = true }, modifier = Modifier.size(actionButtonSize).background(Color.Black.copy(alpha = .24f), RoundedCornerShape(50))) {
                Icon(Icons.Default.Comment, contentDescription = "View and add comments", tint = Paper, modifier = Modifier.size(actionIconSize))
            }
            Text("${clipComments.size.takeIf { showComments } ?: clip.commentCount}", color = Paper, fontWeight = FontWeight.Black, fontSize = 10.sp,
                style = androidx.compose.ui.text.TextStyle(shadow = Shadow(Color.Black.copy(alpha = .8f), androidx.compose.ui.geometry.Offset(1f, 1f), 3f)), modifier = Modifier.padding(bottom = 2.dp))
            IconButton(onClick = onSave, modifier = Modifier.size(actionButtonSize).background(Color.Black.copy(alpha = .24f), RoundedCornerShape(50))) {
                Icon(if (clip.savedByMe) Icons.Default.Bookmark else Icons.Default.BookmarkBorder, contentDescription = if (clip.savedByMe) "Remove saved clip" else "Save clip", tint = Paper, modifier = Modifier.size(actionIconSize))
            }
            IconButton(onClick = {
                val shareText = buildString {
                    append("Watch this ALTROOM clip")
                    if (clip.caption.isNotBlank()) append(" — ${clip.caption}")
                    append("\n${clip.mediaUrl}")
                }
                val sendIntent = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, shareText)
                try { context.startActivity(Intent.createChooser(sendIntent, "Share ALTROOM clip")) } catch (_: Exception) { }
            }, modifier = Modifier.size(actionButtonSize).background(Color.Black.copy(alpha = .24f), RoundedCornerShape(50))) {
                Icon(Icons.Default.Share, contentDescription = "Share clip", tint = Paper, modifier = Modifier.size(actionIconSize))
            }
        }
        Column(Modifier.align(Alignment.BottomStart).fillMaxWidth().padding(start = 14.dp, end = 70.dp, bottom = 9.dp, top = 8.dp)) {
            Row(Modifier.fillMaxWidth().clickable(onClick = onAuthorClick).padding(bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                ProfileAvatar(profile = author, size = 42.dp, modifier = Modifier.clickable(onClick = onAuthorClick), contextDescription = "Tap to view clip creator profile")
                Spacer(Modifier.width(9.dp))
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text(author?.displayName ?: "ALTROOM MEMBER", color = Paper, fontSize = 12.sp, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            style = androidx.compose.ui.text.TextStyle(shadow = Shadow(Color.Black.copy(alpha = .75f), androidx.compose.ui.geometry.Offset(1f, 1f), 3f)))
                        if (author?.role == "owner") FounderBadge(compact = true)
                    }
                    Text(if (!author?.username.isNullOrBlank()) "@${author?.username}" else "COMMUNITY CREATOR", color = Paper.copy(alpha = .82f), fontSize = 9.sp,
                        style = androidx.compose.ui.text.TextStyle(shadow = Shadow(Color.Black.copy(alpha = .75f), androidx.compose.ui.geometry.Offset(1f, 1f), 3f)))
                }
                Text("VIEW ↗", color = Paper, fontSize = 8.sp, fontWeight = FontWeight.Black,
                    style = androidx.compose.ui.text.TextStyle(shadow = Shadow(Color.Black.copy(alpha = .8f), androidx.compose.ui.geometry.Offset(1f, 1f), 3f)))
            }
            if (clip.caption.isNotBlank()) Text(clip.caption, color = Paper, fontSize = 14.sp, lineHeight = 19.sp, maxLines = 4, overflow = TextOverflow.Ellipsis,
                style = androidx.compose.ui.text.TextStyle(shadow = Shadow(Color.Black.copy(alpha = .85f), androidx.compose.ui.geometry.Offset(1f, 1f), 3f)))
            Text("SWIPE UP FOR NEXT · DOUBLE-TAP TO LIKE", color = Paper.copy(alpha = .84f), fontSize = 8.sp, fontWeight = FontWeight.Bold, letterSpacing = .55.sp, modifier = Modifier.padding(top = 7.dp),
                style = androidx.compose.ui.text.TextStyle(shadow = Shadow(Color.Black.copy(alpha = .85f), androidx.compose.ui.geometry.Offset(1f, 1f), 3f)))
        }
        if (!isPlaying && active && !showComments) {
            Box(Modifier.align(Alignment.Center).size(72.dp).background(Color.Black.copy(alpha = .42f), RoundedCornerShape(50)), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.PlayArrow, contentDescription = "Tap to resume", tint = Paper, modifier = Modifier.size(42.dp))
            }
        }
        if (heartVisible) {
            Icon(Icons.Default.Favorite, contentDescription = "Liked", tint = Stamp, modifier = Modifier.align(Alignment.Center).size(86.dp))
        }
    }

    if (showComments) {
        ModalBottomSheet(
            onDismissRequest = { showComments = false; replyingTo = null },
            sheetState = commentSheetState,
            containerColor = Panel,
            contentColor = Paper,
            scrimColor = Color.Black.copy(alpha = .48f),
            dragHandle = {
                Column(Modifier.fillMaxWidth().padding(top = 5.dp, bottom = 7.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(Modifier.width(38.dp).height(4.dp).background(Muted.copy(alpha = .75f), RoundedCornerShape(50)))
                    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("THE CONVERSATION", color = Paper, fontSize = 14.sp, fontWeight = FontWeight.Black, letterSpacing = .7.sp)
                            Text("${clipComments.size} comments · replies stay in the thread", color = Muted, fontSize = 10.sp, modifier = Modifier.padding(top = 2.dp))
                        }
                        TextButton(onClick = { showComments = false; replyingTo = null }) { Text("DONE", color = Stamp, fontWeight = FontWeight.Black) }
                    }
                }
            }
        ) {
            Column(Modifier.fillMaxWidth().fillMaxHeight(.76f).imePadding().padding(horizontal = 14.dp)) {
                if (commentsLoading) {
                    Box(Modifier.fillMaxWidth().padding(vertical = 15.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Stamp, strokeWidth = 2.dp, modifier = Modifier.size(22.dp)) }
                }
                if (!commentsLoading && clipComments.isEmpty() && commentsError.isBlank()) {
                    Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Text("✦", color = Stamp, fontSize = 30.sp)
                            Text("BE THE FIRST TO SAY SOMETHING", color = Paper, fontWeight = FontWeight.Black, fontSize = 11.sp)
                            Text("Good conversations start small.", color = Muted, fontSize = 11.sp)
                        }
                    }
                } else {
                    LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(top = 5.dp, bottom = 12.dp)) {
                        val topLevel = clipComments.filter { it.parentCommentId.isNullOrBlank() }
                        items(topLevel, key = { it.id }) { comment ->
                            ShortCommentRow(comment = comment, onReply = { replyingTo = comment })
                            val replies = clipComments.filter { it.parentCommentId == comment.id }
                            replies.forEach { reply ->
                                Row(Modifier.fillMaxWidth().padding(start = 28.dp)) {
                                    Box(Modifier.width(2.dp).height(28.dp).background(Rule))
                                    Spacer(Modifier.width(8.dp))
                                    Box(Modifier.weight(1f)) { ShortCommentRow(comment = reply, isReply = true, onReply = { replyingTo = reply }) }
                                }
                            }
                        }
                    }
                }
                if (commentsError.isNotBlank()) Text(commentsError.take(280), color = Color(0xFFFFB8AE), fontSize = 10.sp, lineHeight = 14.sp, modifier = Modifier.padding(vertical = 5.dp))
                replyingTo?.let { target ->
                    Row(Modifier.fillMaxWidth().background(Panel2, RoundedCornerShape(topStart = 9.dp, topEnd = 9.dp)).padding(horizontal = 10.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("Replying to @${target.username.ifBlank { target.displayName }}", color = Stamp, fontSize = 10.sp, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        TextButton(onClick = { replyingTo = null }) { Text("CANCEL", color = Muted, fontSize = 9.sp) }
                    }
                }
                Row(Modifier.fillMaxWidth().padding(top = 7.dp, bottom = 10.dp), verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    OutlinedTextField(
                        value = commentDraft,
                        onValueChange = { commentDraft = it.take(1000) },
                        modifier = Modifier.weight(1f),
                        placeholder = { Text(if (replyingTo == null) "Add to the conversation…" else "Write a reply…", color = Muted, fontSize = 12.sp) },
                        maxLines = 4,
                        shape = RoundedCornerShape(18.dp),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Stamp, unfocusedBorderColor = Rule, focusedTextColor = Paper, unfocusedTextColor = Paper, cursorColor = Paper, focusedContainerColor = Panel2, unfocusedContainerColor = Panel2)
                    )
                    IconButton(onClick = { submitShortComment() }, enabled = commentDraft.isNotBlank() && !commentsPosting, modifier = Modifier.size(48.dp).background(if (commentDraft.isNotBlank() && !commentsPosting) Stamp else Panel2, RoundedCornerShape(50))) {
                        Icon(Icons.AutoMirrored.Filled.Send, contentDescription = if (replyingTo == null) "Post comment" else "Post reply", tint = Paper)
                    }
                }
            }
        }
    }
}

@Composable
private fun ShortCommentRow(comment: ShortClipComment, isReply: Boolean = false, onReply: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
        Box(Modifier.size(if (isReply) 27.dp else 34.dp).background(if (isReply) Color(0xFF252525) else Color(0xFF303030), RoundedCornerShape(50)).border(1.dp, Rule, RoundedCornerShape(50)), contentAlignment = Alignment.Center) {
            Text(initials(comment.displayName), color = Paper, fontSize = if (isReply) 9.sp else 11.sp, fontWeight = FontWeight.Black)
        }
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                Text(comment.displayName, color = Paper, fontSize = 11.sp, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (comment.username.isNotBlank()) Text("@${comment.username}", color = Muted, fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Text(comment.body, color = Paper.copy(alpha = .95f), fontSize = 13.sp, lineHeight = 18.sp, modifier = Modifier.padding(top = 3.dp))
            TextButton(onClick = onReply, contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 0.dp, vertical = 0.dp), modifier = Modifier.height(26.dp)) {
                Text("Reply", color = Stamp, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun ArtworkCard(art: AltroomArtwork, onAuthorClick: () -> Unit = {}) {
    val context = LocalContext.current
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(13.dp)).background(Panel).border(1.dp, Rule.copy(alpha = .8f), RoundedCornerShape(13.dp))) {
        Row(Modifier.fillMaxWidth().clickable(onClick = onAuthorClick).padding(horizontal = 13.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            ProfileAvatar(profile = AltroomProfile(art.userId, art.username, art.displayName, "", emptyList(), true, "member"), size = 40.dp, contextDescription = "View artwork creator profile")
            Spacer(Modifier.width(9.dp))
            Column(Modifier.weight(1f)) {
                Text(art.displayName, color = Paper, fontWeight = FontWeight.Black, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("@${art.username} · ${dateLabel(art.createdAt)}", color = Muted, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Text("ART / DIY", color = Stamp, fontSize = 8.sp, fontWeight = FontWeight.Black, letterSpacing = .7.sp)
        }
        if (art.title.isNotBlank()) Text(art.title, color = Paper, fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.padding(start = 13.dp, end = 13.dp, bottom = 9.dp))
        if (art.imageUrl.isNotBlank()) {
            AsyncImage(model = art.imageUrl, contentDescription = art.title, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxWidth().background(Color(0xFF101010)).heightIn(min = 150.dp, max = 440.dp))
        } else Box(Modifier.fillMaxWidth().height(180.dp).background(Color(0xFF111111)), contentAlignment = Alignment.Center) { Text("IMAGE UNAVAILABLE", color = Muted, fontSize = 10.sp) }
        if (art.caption.isNotBlank()) Text(art.caption, color = Paper.copy(alpha = .92f), fontSize = 13.sp, lineHeight = 19.sp, modifier = Modifier.padding(horizontal = 13.dp, vertical = 10.dp))
        Row(Modifier.fillMaxWidth().clickable(onClick = onAuthorClick).padding(horizontal = 13.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Forum, contentDescription = null, tint = Muted, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(7.dp))
            Text("View creator", color = Muted, fontSize = 10.sp)
            Spacer(Modifier.weight(1f))
            TextButton(onClick = {
                val shareText = buildString {
                    append(art.title.ifBlank { "Artwork from ALTROOM" })
                    if (art.caption.isNotBlank()) append("\n${art.caption}")
                    append("\n${art.imageUrl}")
                }
                try {
                    context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, shareText), "Share ALTROOM artwork"))
                } catch (_: Exception) { }
            }, contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 4.dp, vertical = 0.dp)) {
                Icon(Icons.Default.Share, contentDescription = null, tint = Muted, modifier = Modifier.size(15.dp))
                Spacer(Modifier.width(4.dp))
                Text("Share", color = Muted, fontSize = 10.sp)
            }
        }
    }
}

@Composable
private fun Composer(draft: String, onDraft: (String) -> Unit, hint: String, busy: Boolean, onAttach: () -> Unit = {}, onSignal: (() -> Unit)? = null, onSend: () -> Unit) {
    Row(Modifier.fillMaxWidth().background(Panel).padding(horizontal = 8.dp, vertical = 7.dp).imePadding().animateContentSize(), verticalAlignment = Alignment.Bottom) {
        if (onSignal != null) {
            IconButton(onClick = onSignal, enabled = !busy, modifier = Modifier.size(40.dp).background(Color(0xFF30251F), RoundedCornerShape(12.dp))) {
                Text("✳", color = Stamp, fontSize = 20.sp, fontWeight = FontWeight.Black)
            }
            Spacer(Modifier.width(5.dp))
        }
        IconButton(onClick = onAttach, enabled = !busy, modifier = Modifier.size(43.dp).background(Panel2, RoundedCornerShape(12.dp))) {
            Icon(Icons.Default.Add, contentDescription = "Attach photo or audio", tint = Paper)
        }
        Spacer(Modifier.width(6.dp))
        OutlinedTextField(
            value = draft, onValueChange = onDraft, modifier = Modifier.weight(1f), placeholder = { Text(hint, color = Muted, fontSize = 12.sp) },
            shape = RoundedCornerShape(12.dp), maxLines = 4, keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
            keyboardActions = KeyboardActions(onSend = { if (!busy) onSend() }),
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Paper, unfocusedBorderColor = Rule, focusedTextColor = Paper, unfocusedTextColor = Paper, cursorColor = Paper, focusedContainerColor = Ink, unfocusedContainerColor = Ink)
        )
        Spacer(Modifier.width(6.dp))
        IconButton(onClick = onSend, enabled = !busy && draft.isNotBlank(), modifier = Modifier.size(43.dp).background(Paper, RoundedCornerShape(12.dp))) {
            Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send message", tint = Ink)
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun CallScreen(title: String, kind: String, roomName: String, onClose: () -> Unit) {
    val context = LocalContext.current
    val webViewRef = remember { mutableStateOf<WebView?>(null) }
    DisposableEffect(Unit) {
        onDispose {
            webViewRef.value?.let { view ->
                try { view.stopLoading() } catch (_: Exception) {}
                try { view.loadUrl("about:blank") } catch (_: Exception) {}
                try { view.destroy() } catch (_: Exception) {}
                webViewRef.value = null
            }
        }
    }
    Column(Modifier.fillMaxSize().background(Ink)) {
        Row(Modifier.fillMaxWidth().background(Panel).padding(horizontal = 13.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, color = Paper, fontSize = 14.sp, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(if (kind == "video") "VIDEO CALL · CAMERA + MIC" else "AUDIO CALL · MIC ONLY", color = Stamp, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = .7.sp, modifier = Modifier.padding(top = 3.dp))
            }
            TextButton(onClick = onClose) { Text("END CALL ✕", color = Paper, fontWeight = FontWeight.Black, fontSize = 10.sp) }
        }
        Box(Modifier.weight(1f).fillMaxWidth().background(Color.Black)) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { ctx ->
                    WebView(ctx).apply {
                        webViewRef.value = this
                        tag = roomName
                        setBackgroundColor(android.graphics.Color.BLACK)
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.mediaPlaybackRequiresUserGesture = false
                        settings.javaScriptCanOpenWindowsAutomatically = true
                        settings.setSupportMultipleWindows(false)
                        val callWebView = this
                        webChromeClient = object : WebChromeClient() {
                            override fun onPermissionRequest(request: PermissionRequest) {
                                callWebView.post {
                                    // Only the configured call provider is allowed to request device media.
                                    if (request.origin.host != "meet.jit.si" || request.origin.scheme != "https") {
                                        request.deny()
                                        return@post
                                    }
                                    val allowedResources = request.resources.filter { resource ->
                                        when (resource) {
                                            PermissionRequest.RESOURCE_AUDIO_CAPTURE -> ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                                            PermissionRequest.RESOURCE_VIDEO_CAPTURE -> ctx.checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
                                            else -> false
                                        }
                                    }
                                    if (allowedResources.isNotEmpty()) request.grant(allowedResources.toTypedArray()) else request.deny()
                                }
                            }
                        }
                        webViewClient = object : WebViewClient() {
                            override fun shouldOverrideUrlLoading(view: WebView, urlRequest: android.webkit.WebResourceRequest): Boolean {
                                val scheme = urlRequest.url.scheme.orEmpty()
                                return scheme != "https" && scheme != "http" && scheme != "about"
                            }
                        }
                        val audioConfig = if (kind == "audio") "&config.startWithVideoMuted=true&config.startWithAudioMuted=false" else "&config.startWithVideoMuted=false&config.startWithAudioMuted=false"
                        loadUrl("https://meet.jit.si/${Uri.encode(roomName)}#config.prejoinConfig.enabled=false$audioConfig")
                    }
                },
                update = { view ->
                    if (view.tag != roomName) {
                        view.tag = roomName
                        val audioConfig = if (kind == "audio") "&config.startWithVideoMuted=true&config.startWithAudioMuted=false" else "&config.startWithVideoMuted=false&config.startWithAudioMuted=false"
                        view.loadUrl("https://meet.jit.si/${Uri.encode(roomName)}#config.prejoinConfig.enabled=false$audioConfig")
                    }
                }
            )
        }
    }
}

private fun Context.findAltroomActivity(): Activity? {
    var current: Context = this
    while (current is ContextWrapper) {
        if (current is Activity) return current
        current = current.baseContext
    }
    return current as? Activity
}

@Suppress("DEPRECATION")
private fun Activity.setAltroomImmersiveMode(enabled: Boolean) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        window.insetsController?.let { controller ->
            if (enabled) {
                controller.systemBarsBehavior = android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                controller.hide(android.view.WindowInsets.Type.statusBars() or android.view.WindowInsets.Type.navigationBars())
            } else {
                controller.show(android.view.WindowInsets.Type.statusBars() or android.view.WindowInsets.Type.navigationBars())
            }
        }
    } else {
        window.decorView.systemUiVisibility = if (enabled) {
            android.view.View.SYSTEM_UI_FLAG_FULLSCREEN or
                android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        } else 0
    }
}

private const val ALTROOM_MESSAGE_CHANNEL = "altroom_private_messages"
private const val ALTROOM_SIGNUP_CHANNEL = "altroom_new_signups"

/**
 * Background backup for DM notifications. WorkManager may run later than 15 minutes
 * under Android battery restrictions; foreground polling in AltroomApp remains faster.
 */
class AltroomMessageNotificationWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {
    override suspend fun doWork(): Result {
        val prefs = applicationContext.getSharedPreferences("altroom_native_session", Context.MODE_PRIVATE)
        if (prefs.getBoolean("app_is_foreground", false)) return Result.success()
        val token = prefs.getString("access_token", "").orEmpty()
        val userId = prefs.getString("user_id", "").orEmpty()
        if (token.isBlank() || userId.isBlank()) return Result.success()

        return try {
            val api = AltroomApi(prefs)
            // Best-effort background signup checks. WorkManager can be delayed by Android battery
            // rules, so the foreground watcher also checks as soon as the founder reopens ALTROOM.
            if (prefs.getString("profile_role", "") == "owner") {
                val currentMembers = api.ownerMembers(token)
                val currentMemberIds = currentMembers.map { it.id }.filter { it.isNotBlank() }.toSet()
                val knownMemberIds = prefs.getStringSet("owner_known_member_ids", null)?.toSet()
                if (knownMemberIds == null) {
                    prefs.edit().putStringSet("owner_known_member_ids", currentMemberIds).apply()
                } else {
                    val addedIds = currentMemberIds - knownMemberIds
                    if (addedIds.isNotEmpty()) {
                        val pendingIds = (prefs.getStringSet("owner_pending_signup_ids", emptySet())?.toSet() ?: emptySet()) + addedIds
                        prefs.edit()
                            .putStringSet("owner_pending_signup_ids", pendingIds)
                            .putStringSet("owner_known_member_ids", knownMemberIds + currentMemberIds)
                            .apply()
                        currentMembers.filter { it.id in addedIds }.forEach { member ->
                            applicationContext.showAltroomSignupNotification("signup:${member.id}".hashCode(), member.displayName)
                        }
                    } else {
                        prefs.edit().putStringSet("owner_known_member_ids", knownMemberIds + currentMemberIds).apply()
                    }
                }
            }
            val recent = api.recentPrivateMessages(token)
            val currentIds = recent.map { it.id }.toSet()
            val known = prefs.getStringSet("known_private_message_ids", null)?.toSet()
            if (known == null) {
                prefs.edit().putStringSet("known_private_message_ids", currentIds).apply()
                return Result.success()
            }

            var unread = prefs.getStringSet("unread_conversations", emptySet())?.toSet() ?: emptySet()
            var unreadCounts = decodeUnreadMessageCounts(prefs.getStringSet("unread_message_counts", emptySet()))
            val incoming = recent.filter { it.id !in known && it.userId != userId }.asReversed()
            incoming.forEach { message ->
                unread = unread + message.contextId
                val count = (unreadCounts[message.contextId] ?: 0) + 1
                unreadCounts = unreadCounts + (message.contextId to count)
                val body = if (message.body.startsWith("ALTROOM_CALL|")) {
                    val callType = message.body.split('|').getOrNull(1)?.takeIf { it in listOf("audio", "video") } ?: "voice"
                    "Started a $callType call. Open ALTROOM to join."
                } else message.body.takeIf { it.isNotBlank() }?.take(120) ?: when (message.kind) {
                    "audio" -> "Sent you an audio message 🎧"
                    "image" -> "Sent you a photo ▧"
                    "video" -> "Sent you a video ▶"
                    else -> "Sent you a message ✉"
                }
                applicationContext.showAltroomMessageNotification(message.contextId.hashCode(), message.displayName, body, count)
            }
            val updatedKnown = (known + currentIds).toList().takeLast(300).toSet()
            prefs.edit()
                .putStringSet("known_private_message_ids", updatedKnown)
                .putStringSet("unread_conversations", unread)
                .putStringSet("unread_message_counts", encodeUnreadMessageCounts(unreadCounts))
                .apply()
            Result.success()
        } catch (_: Exception) {
            Result.retry()
        }
    }
}

@Suppress("DEPRECATION")
private fun Context.showAltroomMessageNotification(id: Int, sender: String, message: String, unreadCount: Int = 1) {
    val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
    val intent = Intent(this, MainActivity::class.java).apply {
        flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
    }
    val pendingIntent = PendingIntent.getActivity(
        this, id, intent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
    val notification = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        Notification.Builder(this, ALTROOM_MESSAGE_CHANNEL)
    } else {
        Notification.Builder(this)
    }.setSmallIcon(R.drawable.ic_altroom)
        .setNumber(unreadCount.coerceAtLeast(1))
        .setContentTitle("ALTROOM · $sender")
        .setContentText(message)
        .setStyle(Notification.BigTextStyle().bigText(message))
        .setAutoCancel(true)
        .setContentIntent(pendingIntent)
        .build()
    manager.notify(id, notification)
}

@Suppress("DEPRECATION")
private fun Context.showAltroomSignupNotification(id: Int, displayName: String) {
    if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
    val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    val intent = Intent(this, MainActivity::class.java).apply {
        flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
    }
    val pendingIntent = PendingIntent.getActivity(
        this, id, intent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
    val message = "${displayName.ifBlank { "A new member" }} joined ALTROOM. Open Founder Safety Desk to review."
    val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        Notification.Builder(this, ALTROOM_SIGNUP_CHANNEL)
    } else {
        Notification.Builder(this)
    }
    manager.notify(id, builder.setSmallIcon(R.drawable.ic_altroom)
        .setContentTitle("ALTROOM · NEW SIGNUP")
        .setContentText(message)
        .setStyle(Notification.BigTextStyle().bigText(message))
        .setAutoCancel(true)
        .setContentIntent(pendingIntent)
        .build())
}

private fun isTransientNetworkError(error: Throwable): Boolean {
    var current: Throwable? = error
    while (current != null) {
        val message = current.message.orEmpty().lowercase(Locale.ROOT)
        if (listOf("connection reset", "connection aborted", "socket closed", "unexpected end of stream", "failed to connect", "timed out", "timeout", "network is unreachable", "unknownhostexception").any { it in message }) return true
        current = current.cause
    }
    return false
}

private fun decodeUnreadMessageCounts(encoded: Set<String>?): Map<String, Int> = encoded.orEmpty().mapNotNull { item ->
    val separator = item.lastIndexOf('|')
    if (separator <= 0) null else {
        val id = item.substring(0, separator)
        val count = item.substring(separator + 1).toIntOrNull() ?: 0
        if (id.isBlank() || count <= 0) null else id to count
    }
}.toMap()

private fun encodeUnreadMessageCounts(counts: Map<String, Int>): Set<String> =
    counts.filterValues { it > 0 }.map { (id, count) -> "$id|$count" }.toSet()

private fun audioTime(milliseconds: Int): String {
    val totalSeconds = (milliseconds.coerceAtLeast(0) / 1000)
    return String.format(Locale.getDefault(), "%d:%02d", totalSeconds / 60, totalSeconds % 60)
}

@Composable
private fun AltField(
    label: String, value: String, onValue: (String) -> Unit, singleLine: Boolean = true,
    isPassword: Boolean = false, keyboardType: KeyboardType = KeyboardType.Text, imeAction: ImeAction = ImeAction.Next
) {
    Column(Modifier.fillMaxWidth().padding(bottom = 9.dp)) {
        Text(label.uppercase(), color = Muted, fontSize = 9.sp, fontWeight = FontWeight.Black, letterSpacing = 1.2.sp, modifier = Modifier.padding(bottom = 5.dp))
        OutlinedTextField(
            value = value, onValueChange = onValue, modifier = Modifier.fillMaxWidth(), singleLine = singleLine,
            visualTransformation = if (isPassword) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
            keyboardOptions = KeyboardOptions(keyboardType = keyboardType, imeAction = imeAction),
            shape = RoundedCornerShape(3.dp), minLines = if (singleLine) 1 else 2,
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Paper, unfocusedBorderColor = Rule, focusedTextColor = Paper, unfocusedTextColor = Paper, cursorColor = Paper, focusedContainerColor = Panel, unfocusedContainerColor = Panel, focusedPlaceholderColor = Muted, unfocusedPlaceholderColor = Muted)
        )
    }
}

@Composable
private fun NavChip(
    label: String,
    icon: ImageVector,
    active: Boolean,
    modifier: Modifier = Modifier,
    badgeCount: Int = 0,
    onClick: () -> Unit
) {
    val chipBackground by animateColorAsState(
        targetValue = if (active) Paper else Color.Transparent,
        animationSpec = tween(durationMillis = 180),
        label = "${label}_nav_background"
    )
    val chipIconColor by animateColorAsState(
        targetValue = if (active) Ink else Paper,
        animationSpec = tween(durationMillis = 180),
        label = "${label}_nav_icon"
    )
    val chipLabelColor by animateColorAsState(
        targetValue = if (active) Ink else Muted,
        animationSpec = tween(durationMillis = 180),
        label = "${label}_nav_label"
    )
    Column(
        modifier
            .animateContentSize()
            .clip(RoundedCornerShape(12.dp))
            .background(chipBackground)
            .clickable(onClick = onClick)
            .padding(horizontal = 2.dp, vertical = 7.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(Modifier.size(24.dp), contentAlignment = Alignment.Center) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = chipIconColor,
                modifier = Modifier.size(20.dp)
            )
            if (badgeCount > 0) {
                Box(
                    Modifier.align(Alignment.TopEnd).widthIn(min = 16.dp).height(16.dp)
                        .background(Stamp, RoundedCornerShape(50))
                        .border(1.dp, Panel, RoundedCornerShape(50)).padding(horizontal = 3.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(badgeCount.coerceAtMost(99).toString(), color = Ink, fontSize = 8.sp, fontWeight = FontWeight.Black)
                }
            }
        }
        Text(
            label,
            color = chipLabelColor,
            fontSize = 8.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = .35.sp,
            maxLines = 1,
            softWrap = false,
            modifier = Modifier.padding(top = 2.dp)
        )
    }
}

@Composable
private fun EmptyCard(title: String, body: String) {
    Column(Modifier.fillMaxWidth().background(Panel).border(1.dp, Rule).padding(14.dp)) {
        Text(title, color = Paper, fontWeight = FontWeight.Black, fontSize = 12.sp)
        Text(body, color = Muted, fontSize = 11.sp, lineHeight = 16.sp, modifier = Modifier.padding(top = 4.dp))
    }
}

@Composable
private fun CenterState(title: String, body: String, loading: Boolean, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxWidth().padding(25.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        if (loading) CircularProgressIndicator(color = Paper, strokeWidth = 2.dp, modifier = Modifier.size(26.dp)) else Text("✳", color = Stamp, fontSize = 32.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(15.dp))
        Text(title, color = Paper, fontSize = 17.sp, fontWeight = FontWeight.Black, letterSpacing = .2.sp)
        Text(body, color = Muted, fontSize = 12.sp, lineHeight = 17.sp, modifier = Modifier.padding(top = 7.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
    }
}

@Composable
private fun Tag(text: String) {
    Text(text.uppercase(), Modifier.background(Panel2).border(1.dp, Rule).padding(horizontal = 10.dp, vertical = 7.dp), color = Paper, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = .4.sp)
}

@Composable
private fun RuleLine() { Divider(color = Rule, thickness = 1.dp) }

private fun readableError(e: Exception): String {
    val raw = e.message.orEmpty().removePrefix("java.io.IOException: ")
    return when {
        raw.contains("Invalid login credentials", ignoreCase = true) -> "Email or password is incorrect."
        raw.contains("Email not confirmed", ignoreCase = true) -> "Verify your email first, then sign in."
        raw.contains("JWT expired", ignoreCase = true) || raw.contains("session expired", ignoreCase = true) || raw.contains("could not renew this session", ignoreCase = true) -> "Your ALTROOM session needs refreshing. Sign in again only if the app cannot reconnect."
        raw.contains("Connection reset", ignoreCase = true) || raw.contains("SocketException", ignoreCase = true) || raw.contains("unexpected end of stream", ignoreCase = true) || raw.contains("timed out", ignoreCase = true) || raw.contains("timeout", ignoreCase = true) -> "Connection hiccup. ALTROOM will retry; please try that action again in a moment."
        raw.contains("Failed to connect", ignoreCase = true) -> "Network connection failed. Check your internet and try again."
        raw.contains("UnknownHostException", ignoreCase = true) -> "Could not reach ALTROOM. Check your internet connection."
        raw.isBlank() -> "Something went wrong. Please try again."
        else -> raw.take(420)
    }
}

private fun timeLabel(value: String): String = try {
    val iso = java.time.Instant.parse(value)
    SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date.from(iso))
} catch (_: Exception) { "" }

private fun dateLabel(value: String): String = try {
    val iso = java.time.Instant.parse(value)
    SimpleDateFormat("MMM d", Locale.getDefault()).format(Date.from(iso)).uppercase(Locale.getDefault())
} catch (_: Exception) { "" }

private fun initials(value: String): String = value.trim().split(Regex("\\s+")).filter { it.isNotBlank() }.take(2).joinToString("") { it.take(1).uppercase(Locale.getDefault()) }.ifBlank { "A" }

private fun readPickedBytes(context: Context, uri: Uri, maxBytes: Int): ByteArray {
    val cursor = context.contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)
    val size = cursor?.use { if (it.moveToFirst()) it.getLong(0) else -1L } ?: -1L
    if (size > maxBytes) throw IOException("The selected file is ${(size / 1024 / 1024)} MB. The limit is ${maxBytes / 1024 / 1024} MB.")
    val bytes = context.contentResolver.openInputStream(uri)?.use { input ->
        val output = java.io.ByteArrayOutputStream()
        val buffer = ByteArray(16 * 1024)
        var total = 0
        while (true) {
            val count = input.read(buffer)
            if (count < 0) break
            total += count
            if (total > maxBytes) throw IOException("The selected file is larger than the ${maxBytes / 1024 / 1024} MB limit.")
            output.write(buffer, 0, count)
        }
        output.toByteArray()
    } ?: throw IOException("Couldn't read the selected file. Try selecting it again.")
    if (bytes.isEmpty()) throw IOException("The selected file is empty.")
    return bytes
}

private fun videoDurationMs(context: Context, uri: Uri): Long {
    val retriever = MediaMetadataRetriever()
    return try {
        retriever.setDataSource(context, uri)
        retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: -1L
    } catch (_: Exception) { -1L } finally { try { retriever.release() } catch (_: Exception) {} }
}
