package com.altroom.community

import android.Manifest
import android.app.DownloadManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.net.Uri
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.os.Bundle
import android.os.Build
import android.os.Environment
import android.provider.OpenableColumns
import android.view.ViewGroup
import android.widget.MediaController
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Forum
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayCircleFilled
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import coil.compose.AsyncImage
import coil.compose.AsyncImagePainter
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.concurrent.TimeUnit

private val Ink = Color(0xFF090909)
private val Panel = Color(0xFF151515)
private val Panel2 = Color(0xFF202020)
private val Paper = Color(0xFFF0EEE6)
private val Muted = Color(0xFFA4A29B)
private val Rule = Color(0xFF45443F)
private val Stamp = Color(0xFFC94A3C)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val notificationConstraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()
        val notificationWork = PeriodicWorkRequestBuilder<AltroomMessageNotificationWorker>(15, TimeUnit.MINUTES)
            .setConstraints(notificationConstraints)
            .build()
        WorkManager.getInstance(applicationContext).enqueueUniquePeriodicWork(
            "altroom-private-message-background-check",
            ExistingPeriodicWorkPolicy.KEEP,
            notificationWork
        )
        window.statusBarColor = android.graphics.Color.rgb(9, 9, 9)
        window.navigationBarColor = android.graphics.Color.rgb(9, 9, 9)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                ALTROOM_MESSAGE_CHANNEL,
                "ALTROOM messages",
                NotificationManager.IMPORTANCE_HIGH
            ).apply { description = "New private messages in ALTROOM" }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Paper,
                    onPrimary = Ink,
                    background = Ink,
                    onBackground = Paper,
                    surface = Panel,
                    onSurface = Paper,
                    secondary = Muted,
                    error = Color(0xFFFF8477)
                )
            ) { Surface(modifier = Modifier.fillMaxSize(), color = Ink) { AltroomApp() } }
        }
    }

    override fun onStart() {
        super.onStart()
        getSharedPreferences("altroom_native_session", Context.MODE_PRIVATE)
            .edit().putBoolean("app_is_foreground", true).apply()
    }

    override fun onStop() {
        getSharedPreferences("altroom_native_session", Context.MODE_PRIVATE)
            .edit().putBoolean("app_is_foreground", false).apply()
        super.onStop()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AltroomApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("altroom_native_session", Context.MODE_PRIVATE) }
    val api = remember { AltroomApi() }
    val scope = rememberCoroutineScope()

    var accessToken by remember { mutableStateOf(prefs.getString("access_token", "").orEmpty()) }
    var userId by remember { mutableStateOf(prefs.getString("user_id", "").orEmpty()) }
    var profile by remember { mutableStateOf<AltroomProfile?>(null) }
    var page by remember { mutableStateOf("loading") }
    var tab by remember { mutableStateOf("rooms") }
    var authMode by remember { mutableStateOf("login") }
    var authName by remember { mutableStateOf("") }
    var authEmail by remember { mutableStateOf("") }
    var authPassword by remember { mutableStateOf("") }
    var inviteCode by remember { mutableStateOf("") }
    var newRoomName by remember { mutableStateOf("") }
    var newRoomDescription by remember { mutableStateOf("") }
    var showCreateRoomDialog by remember { mutableStateOf(false) }
    var showRoomSafetyDialog by remember { mutableStateOf(false) }
    var showSignalDialog by remember { mutableStateOf(false) }
    var canModerateSelectedRoom by remember { mutableStateOf(false) }
    var roomReports by remember { mutableStateOf<List<RoomModerationReport>>(emptyList()) }
    var showProfileEditor by remember { mutableStateOf(false) }
    var viewedProfile by remember { mutableStateOf<AltroomProfile?>(null) }
    var selectedAvatarUri by remember { mutableStateOf<Uri?>(null) }
    var editDisplayName by remember { mutableStateOf("") }
    var editBio by remember { mutableStateOf("") }
    var editInterests by remember { mutableStateOf("") }
    var unreadConversations by remember {
        mutableStateOf(prefs.getStringSet("unread_conversations", emptySet())?.toSet() ?: emptySet())
    }
    var knownPrivateMessageIds by remember {
        mutableStateOf(prefs.getStringSet("known_private_message_ids", null)?.toSet())
    }
    var busy by remember { mutableStateOf(false) }
    var errorText by remember { mutableStateOf("") }
    var infoText by remember { mutableStateOf("") }
    var rooms by remember { mutableStateOf<List<AltroomRoom>>(emptyList()) }
    var selectedRoom by remember { mutableStateOf<AltroomRoom?>(null) }
    var roomMessages by remember { mutableStateOf<List<AltroomMessage>>(emptyList()) }
    var roomDraft by remember { mutableStateOf("") }
    var members by remember { mutableStateOf<List<AltroomProfile>>(emptyList()) }
    var conversations by remember { mutableStateOf<List<PrivateConversation>>(emptyList()) }
    var selectedConversation by remember { mutableStateOf<PrivateConversation?>(null) }
    var privateOther by remember { mutableStateOf<AltroomProfile?>(null) }
    var privateMessages by remember { mutableStateOf<List<AltroomMessage>>(emptyList()) }
    var privateDraft by remember { mutableStateOf("") }
    var clips by remember { mutableStateOf<List<ShortClip>>(emptyList()) }
    var artworks by remember { mutableStateOf<List<AltroomArtwork>>(emptyList()) }
    var selectedVideoUri by remember { mutableStateOf<Uri?>(null) }
    var selectedImageUri by remember { mutableStateOf<Uri?>(null) }
    var selectedChatMediaUri by remember { mutableStateOf<Uri?>(null) }
    var selectedChatMediaKind by remember { mutableStateOf("image") }
    var showChatAttachments by remember { mutableStateOf(false) }
    var callKind by remember { mutableStateOf("video") }
    var callRoomName by remember { mutableStateOf("") }
    var callTitle by remember { mutableStateOf("ALTROOM CALL") }
    var pendingCallKind by remember { mutableStateOf("video") }
    var pendingCallRoomName by remember { mutableStateOf("") }
    var pendingCallTitle by remember { mutableStateOf("ALTROOM CALL") }
    var callReturnPage by remember { mutableStateOf("rooms") }
    var clipCaption by remember { mutableStateOf("") }
    var artTitle by remember { mutableStateOf("") }
    var artCaption by remember { mutableStateOf("") }

    val callPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
        val audioOkay = grants[Manifest.permission.RECORD_AUDIO] == true || context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val cameraOkay = pendingCallKind != "video" || grants[Manifest.permission.CAMERA] == true || context.checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        if (audioOkay && cameraOkay) {
            callKind = pendingCallKind
            callRoomName = pendingCallRoomName
            callTitle = pendingCallTitle
            callReturnPage = page
            page = "call"
        } else {
            errorText = if (pendingCallKind == "video") "ALTROOM needs microphone and camera access to start a video call." else "ALTROOM needs microphone access to start an audio call."
        }
    }
    val notificationPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    fun beginProfileEdit() {
        val me = profile
        editDisplayName = me?.displayName.orEmpty()
        editBio = me?.bio.orEmpty()
        editInterests = me?.interests.orEmpty().joinToString(", ")
        selectedAvatarUri = null
        showProfileEditor = true
    }

    fun clearUnread(conversationId: String) {
        val updated = unreadConversations - conversationId
        unreadConversations = updated
        prefs.edit().putStringSet("unread_conversations", updated).apply()
    }

    LaunchedEffect(accessToken) {
        if (accessToken.isNotBlank() && Build.VERSION.SDK_INT >= 33 &&
            context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    suspend fun loadSession(token: String, uid: String, refreshToken: String = prefs.getString("refresh_token", "").orEmpty()) {
        val loaded = api.profile(token, uid)
        profile = loaded
        accessToken = token
        userId = uid
        prefs.edit().putString("access_token", token).putString("user_id", uid).putString("refresh_token", refreshToken).apply()
        page = if (loaded.approved) "rooms" else "invite"
        tab = "rooms"
        errorText = ""
    }

    fun task(showBusy: Boolean = true, work: suspend () -> Unit) {
        scope.launch {
            if (showBusy) busy = true
            errorText = ""
            infoText = ""
            try { work() }
            catch (ce: CancellationException) { throw ce }
            catch (e: Exception) { errorText = readableError(e) }
            finally { if (showBusy) busy = false }
        }
    }
    fun requestCall(kind: String, roomName: String, title: String) {
        pendingCallKind = kind
        pendingCallRoomName = roomName
        pendingCallTitle = title
        val required = mutableListOf<String>()
        if (context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) required += Manifest.permission.RECORD_AUDIO
        if (kind == "video" && context.checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) required += Manifest.permission.CAMERA
        if (required.isEmpty()) {
            callKind = kind
            callRoomName = roomName
            callTitle = title
            callReturnPage = page
            page = "call"
        } else callPermissionLauncher.launch(required.toTypedArray())
    }

    fun makeCall(kind: String, isPrivate: Boolean) {
        val roomName = "ALTROOM-${kind.uppercase()}-${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val title = if (isPrivate) "${kind.uppercase()} CALL · ${privateOther?.displayName ?: "PRIVATE CHAT"}" else "${kind.uppercase()} CALL · ${selectedRoom?.name ?: "COMMUNITY ROOM"}"
        task {
            if (isPrivate) {
                val conversation = selectedConversation ?: throw IOException("Open a private conversation first.")
                api.sendPrivateMessage(accessToken, conversation.id, userId, "ALTROOM_CALL|$kind|$roomName")
                privateMessages = api.privateMessages(accessToken, conversation.id)
            } else {
                val room = selectedRoom ?: throw IOException("Enter a community room first.")
                api.sendRoomMessage(accessToken, room.id, userId, "ALTROOM_CALL|$kind|$roomName")
                roomMessages = api.roomMessages(accessToken, room.id)
            }
            requestCall(kind, roomName, title)
        }
    }

    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        selectedVideoUri = uri
        clipCaption = ""
    }
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        selectedImageUri = uri
        artTitle = ""
        artCaption = ""
    }
    val chatMediaPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) selectedChatMediaUri = uri
    }
    val avatarPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) selectedAvatarUri = uri
    }


    LaunchedEffect(Unit) {
        if (accessToken.isBlank() || userId.isBlank()) {
            page = "auth"
        } else {
            try { loadSession(accessToken, userId) }
            catch (_: Exception) {
                val savedRefresh = prefs.getString("refresh_token", "").orEmpty()
                try {
                    if (savedRefresh.isBlank()) throw IOException("No refresh token saved")
                    val fresh = api.refreshSession(savedRefresh)
                    if (fresh.accessToken.isBlank() || fresh.userId.isBlank()) throw IOException("Session refresh failed")
                    loadSession(fresh.accessToken, fresh.userId, fresh.refreshToken)
                } catch (_: Exception) {
                    prefs.edit().clear().apply()
                    accessToken = ""; userId = ""; profile = null; page = "auth"
                    infoText = "Your saved session expired. Sign in again."
                }
            }
        }
    }

    LaunchedEffect(page, accessToken, userId, selectedRoom?.id, selectedConversation?.id) {
        if (accessToken.isBlank() || userId.isBlank()) return@LaunchedEffect
        try {
            when (page) {
                "rooms" -> rooms = api.rooms(accessToken)
                "private" -> {
                    members = api.members(accessToken)
                    conversations = api.conversations(accessToken, userId)
                }
                "room" -> {
                    val target = selectedRoom ?: return@LaunchedEffect
                    // Keep creator avatars and message profile links available in every room.
                    members = try { api.members(accessToken) } catch (_: Exception) { members }
                    canModerateSelectedRoom = try { api.canModerateRoom(accessToken, target.id) } catch (_: Exception) { false }
                    while (isActive) {
                        roomMessages = api.roomMessages(accessToken, target.id)
                        delay(5_000)
                    }
                }
                "privateThread" -> {
                    val target = selectedConversation ?: return@LaunchedEffect
                    while (isActive) {
                        privateMessages = api.privateMessages(accessToken, target.id)
                        delay(5_000)
                    }
                }
                "shorts" -> {
                    clips = api.shortClips(accessToken, userId)
                    members = try { api.members(accessToken) } catch (_: Exception) { members }
                }
                "gallery" -> artworks = api.gallery(accessToken)
            }
        } catch (ce: CancellationException) { throw ce }
        catch (e: Exception) { errorText = readableError(e) }
    }

    // Poll recent private messages while ALTROOM is running. New messages produce
    // an Android notification and an unread marker on the matching DM.
    LaunchedEffect(accessToken, userId, page, selectedConversation?.id) {
        if (accessToken.isBlank() || userId.isBlank()) return@LaunchedEffect
        while (isActive) {
            try {
                val recent = api.recentPrivateMessages(accessToken)
                val ids = recent.map { it.id }.toSet()
                val storedKnown = prefs.getStringSet("known_private_message_ids", null)?.toSet()
                val known = storedKnown ?: knownPrivateMessageIds
                val savedUnread = prefs.getStringSet("unread_conversations", emptySet())?.toSet() ?: emptySet()
                if (savedUnread != unreadConversations) unreadConversations = savedUnread
                if (known == null) {
                    knownPrivateMessageIds = ids
                    prefs.edit().putStringSet("known_private_message_ids", ids).apply()
                } else {
                    val freshIncoming = recent.filter { it.id !in known && it.userId != userId }.asReversed()
                    freshIncoming.forEach { message ->
                        if (page == "privateThread" && selectedConversation?.id == message.contextId) {
                            clearUnread(message.contextId)
                        } else {
                            val updatedUnread = unreadConversations + message.contextId
                            unreadConversations = updatedUnread
                            prefs.edit().putStringSet("unread_conversations", updatedUnread).apply()
                            val body = if (message.body.startsWith("ALTROOM_CALL|")) {
                                val callType = message.body.split('|').getOrNull(1)?.takeIf { it in listOf("audio", "video") } ?: "voice"
                                "Started a $callType call. Tap the call card to join."
                            } else message.body.takeIf { it.isNotBlank() }?.take(120) ?: when (message.kind) {
                                "audio" -> "Sent you an audio message 🎧"
                                "image" -> "Sent you a photo ▧"
                                "video" -> "Sent you a video ▶"
                                else -> "Sent you a message ✉"
                            }
                            context.showAltroomMessageNotification(message.contextId.hashCode(), message.displayName, body)
                        }
                    }
                    val updatedKnown = (known + ids).toList().takeLast(300).toSet()
                    knownPrivateMessageIds = updatedKnown
                    prefs.edit().putStringSet("known_private_message_ids", updatedKnown).apply()
                }
                if (page == "private") conversations = api.conversations(accessToken, userId)
            } catch (ce: CancellationException) {
                throw ce
            } catch (_: Exception) {
                // Keep the rest of the app usable if a poll briefly loses connectivity.
            }
            delay(10_000)
        }
    }

    fun switchTab(next: String) {
        tab = next
        page = next
        selectedRoom = null
        selectedConversation = null
        privateOther = null
        errorText = ""
    }

    fun signOut() {
        prefs.edit().clear().apply()
        accessToken = ""; userId = ""; profile = null; selectedRoom = null
        selectedConversation = null; roomMessages = emptyList(); privateMessages = emptyList()
        unreadConversations = emptySet(); knownPrivateMessageIds = null
        page = "auth"; tab = "rooms"; authMode = "login"
    }

    BackHandler(enabled = page == "room" || page == "privateThread" || page == "invite" || page == "call" || page == "shorts") {
        when (page) {
            "room" -> { selectedRoom = null; page = "rooms"; tab = "rooms" }
            "privateThread" -> { selectedConversation = null; privateOther = null; page = "private"; tab = "private" }
            "invite" -> { signOut() }
            "call" -> { page = callReturnPage }
            "shorts" -> { switchTab("rooms") }
        }
    }

    Column(
        Modifier.fillMaxSize().background(Ink).animateContentSize().padding(WindowInsets.navigationBars.asPaddingValues())
    ) {
        if (page != "auth" && page != "loading" && page != "shorts" && page != "call") {
            Row(
                Modifier.fillMaxWidth().background(Ink).padding(horizontal = 18.dp, vertical = 15.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(29.dp).background(Paper), contentAlignment = Alignment.Center) {
                        Text("✳", color = Ink, fontSize = 19.sp, fontWeight = FontWeight.Black)
                    }
                    Spacer(Modifier.width(9.dp))
                    Column {
                        Text("ALTROOM", color = Paper, fontSize = 21.sp, fontWeight = FontWeight.Black, letterSpacing = (-0.7).sp)
                        Text("A PLACE FOR THE OTHER ONES", color = Muted, fontSize = 8.sp, letterSpacing = 1.3.sp)
                    }
                }
                if (profile != null) {
                    ProfileAvatar(profile = profile, size = 40.dp, modifier = Modifier.clickable { beginProfileEdit() }, contextDescription = "Customize your profile")
                }
            }
            Divider(color = Rule, thickness = 1.dp)
        }

        if (errorText.isNotBlank() && page != "auth") {
            Column(Modifier.fillMaxWidth().background(Color(0xFF321A18)).padding(horizontal = 15.dp, vertical = 9.dp)) {
                Text(errorText, color = Color(0xFFFFC1B9), fontSize = 12.sp)
                TextButton(onClick = { errorText = "" }) { Text("Dismiss", color = Paper, fontSize = 11.sp) }
            }
        }
        if (infoText.isNotBlank() && page != "auth") {
            Text(infoText, Modifier.fillMaxWidth().background(Panel).padding(12.dp), color = Paper, fontSize = 12.sp)
        }

        when (page) {
            "loading" -> CenterState("OPENING THE ROOM", "Connecting to your ALTROOM account…", true, Modifier.fillMaxSize())
            "auth" -> AuthScreen(
                mode = authMode, name = authName, onName = { authName = it }, email = authEmail, onEmail = { authEmail = it },
                password = authPassword, onPassword = { authPassword = it }, busy = busy, info = infoText, error = errorText,
                onMode = { authMode = it; errorText = ""; infoText = "" },
                onSubmit = {
                    task {
                        if (authEmail.isBlank() || authPassword.isBlank()) throw IOException("Enter your email and password.")
                        if (authMode == "signup") {
                            if (authName.isBlank()) throw IOException("Choose a display name first.")
                            if (authPassword.length < 6) throw IOException("Use a password with at least 6 characters.")
                            val result = api.signUp(authName, authEmail, authPassword)
                            if (result.accessToken.isBlank() || result.userId.isBlank()) {
                                infoText = "Your account request was sent. Check your email to verify it, then sign in."
                                authMode = "login"
                            } else {
                                try { loadSession(result.accessToken, result.userId, result.refreshToken) }
                                catch (e: Exception) { accessToken = result.accessToken; userId = result.userId; prefs.edit().putString("access_token", accessToken).putString("user_id", userId).putString("refresh_token", result.refreshToken).apply(); page = "invite"; infoText = "Your account was created. Redeem an invite to enter ALTROOM." }
                            }
                        } else {
                            val result = api.signIn(authEmail, authPassword)
                            if (result.accessToken.isBlank() || result.userId.isBlank()) throw IOException("Sign in did not return a session. Verify your email and try again.")
                            loadSession(result.accessToken, result.userId, result.refreshToken)
                        }
                    }
                }
            )
            "invite" -> InviteScreen(
                code = inviteCode, onCode = { inviteCode = it }, busy = busy,
                onRedeem = { task { if (inviteCode.isBlank()) throw IOException("Enter the invite code."); api.redeemInvite(accessToken, inviteCode); loadSession(accessToken, userId) } },
                onSignOut = { signOut() }
            )
            "rooms" -> {
                SectionHeading("COMMUNITY ROOMS", "Find your corner. Room stewards keep things safe.", action = { newRoomName = ""; newRoomDescription = ""; showCreateRoomDialog = true }, actionLabel = "+ ROOM")
                if (rooms.isEmpty()) CenterState("THE ROOMS ARE QUIET", "Pull to refresh or check your connection.", false, Modifier.weight(1f))
                else LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 15.dp), verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 22.dp)) {
                    items(rooms, key = { it.id }) { room -> RoomCard(room) {
                        task {
                            api.joinRoom(accessToken, room.id)
                            selectedRoom = room
                            roomMessages = emptyList()
                            roomReports = emptyList()
                            canModerateSelectedRoom = false
                            page = "room"; tab = "rooms"
                        }
                    } }
                }
            }
            "room" -> {
                selectedRoom?.let { room ->
                    Row(Modifier.fillMaxWidth().padding(horizontal = 13.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { selectedRoom = null; page = "rooms"; tab = "rooms" }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Paper) }
                        Column(Modifier.weight(1f)) { Text(room.name.uppercase(), color = Paper, fontWeight = FontWeight.Black, fontSize = 17.sp); Text(room.description, color = Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                        TextButton(onClick = {
                            showRoomSafetyDialog = true
                            if (canModerateSelectedRoom) task(false) { roomReports = api.roomReports(accessToken, room.id) }
                        }, contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 4.dp, vertical = 4.dp)) {
                            Text(if (canModerateSelectedRoom) "⚑ MOD" else "⚑ SAFE", color = Stamp, fontWeight = FontWeight.Black, fontSize = 9.sp)
                        }
                        IconButton(onClick = { makeCall("audio", false) }, modifier = Modifier.size(38.dp)) { Icon(Icons.Default.Call, contentDescription = "Start audio call", tint = Paper) }
                        IconButton(onClick = { makeCall("video", false) }, modifier = Modifier.size(38.dp)) { Icon(Icons.Default.Videocam, contentDescription = "Start video call", tint = Stamp) }
                    }
                    Divider(color = Rule)
                    if (roomMessages.isEmpty()) CenterState("START THE CONVERSATION", "Write the first message. It's only visible in this room.", false, Modifier.weight(1f))
                    else LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 13.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 14.dp)) {
                        items(roomMessages, key = { it.id }) { msg -> MessageCard(
                            msg,
                            own = msg.userId == userId,
                            profile = if (msg.userId == userId) profile else members.firstOrNull { it.id == msg.userId },
                            onProfileClick = {
                                if (msg.userId == userId) beginProfileEdit() else task(false) {
                                    viewedProfile = members.firstOrNull { it.id == msg.userId } ?: api.profile(accessToken, msg.userId)
                                }
                            },
                            onJoinCall = { kind, name -> requestCall(kind, name, "${kind.uppercase()} CALL · ${room.name}") }
                        ) }
                    }
                    Composer(draft = roomDraft, onDraft = { roomDraft = it }, hint = "Message #${room.slug}", busy = busy, onAttach = { showChatAttachments = true }, onSignal = { showSignalDialog = true }, onSend = {
                        val text = roomDraft.trim()
                        if (text.isNotBlank()) task {
                            api.sendRoomMessage(accessToken, room.id, userId, text)
                            roomDraft = ""
                            roomMessages = api.roomMessages(accessToken, room.id)
                        }
                    })
                }
            }
            "private" -> {
                SectionHeading("PRIVATE ROOM", "One-to-one conversations. Find more members as the community grows.", action = { task(false) { members = api.members(accessToken); conversations = api.conversations(accessToken, userId) } }, actionLabel = "↻")
                LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 15.dp), verticalArrangement = Arrangement.spacedBy(9.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 20.dp)) {
                    item { Text("YOUR CHATS", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Black, letterSpacing = 1.4.sp, modifier = Modifier.padding(vertical = 4.dp)) }
                    if (conversations.isEmpty()) item { EmptyCard("NO PRIVATE CHATS YET", "Choose a member below to start a conversation.") }
                    items(conversations, key = { "c-${it.id}" }) { conv ->
                        val otherId = if (conv.userA == userId) conv.userB else conv.userA
                        val other = members.firstOrNull { it.id == otherId }
                        MemberCard(
                            other,
                            subtitle = if (conv.id in unreadConversations) "● NEW MESSAGE · Open chat" else "Open private chat",
                            unread = conv.id in unreadConversations,
                            onProfileClick = { if (other != null) viewedProfile = other }
                        ) {
                            clearUnread(conv.id)
                            task {
                                selectedConversation = conv
                                privateOther = other
                                privateMessages = api.privateMessages(accessToken, conv.id)
                                page = "privateThread"; tab = "private"
                            }
                        }
                    }
                    item { Spacer(Modifier.height(8.dp)); Text("MEMBERS", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Black, letterSpacing = 1.4.sp, modifier = Modifier.padding(vertical = 4.dp)) }
                    items(members.filter { it.id != userId }, key = { "m-${it.id}" }) { member ->
                        MemberCard(member, subtitle = "@${member.username}", onProfileClick = { viewedProfile = member }) {
                            task {
                                val id = api.openConversation(accessToken, member.id)
                                if (id.isBlank()) throw IOException("ALTROOM couldn't open that private conversation.")
                                clearUnread(id)
                                selectedConversation = PrivateConversation(id, userId, member.id, "")
                                privateOther = member
                                privateMessages = api.privateMessages(accessToken, id)
                                page = "privateThread"; tab = "private"
                            }
                        }
                    }
                }
            }
            "privateThread" -> {
                Row(Modifier.fillMaxWidth().padding(horizontal = 13.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { selectedConversation = null; privateOther = null; page = "private"; tab = "private" }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Paper) }
                    ProfileAvatar(profile = privateOther, size = 42.dp, modifier = Modifier.clickable { privateOther?.let { viewedProfile = it } }, contextDescription = "View contact profile")
                    Spacer(Modifier.width(8.dp))
                    Column(Modifier.weight(1f).clickable { privateOther?.let { viewedProfile = it } }) { Text((privateOther?.displayName ?: "PRIVATE CHAT").uppercase(), color = Paper, fontWeight = FontWeight.Black, fontSize = 16.sp); Text("@${privateOther?.username ?: "member"} · PRIVATE CHAT", color = Muted, fontSize = 10.sp) }
                    IconButton(onClick = { makeCall("audio", true) }, modifier = Modifier.size(38.dp)) { Icon(Icons.Default.Call, contentDescription = "Start private audio call", tint = Paper) }
                    IconButton(onClick = { makeCall("video", true) }, modifier = Modifier.size(38.dp)) { Icon(Icons.Default.Videocam, contentDescription = "Start private video call", tint = Stamp) }
                }
                Divider(color = Rule)
                if (privateMessages.isEmpty()) CenterState("A PRIVATE CONVERSATION", "Say hello. Only the two participants can see it.", false, Modifier.weight(1f))
                else LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 13.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(15.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 18.dp)) {
                    items(privateMessages, key = { it.id }) { msg -> MessageCard(
                        msg,
                        own = msg.userId == userId,
                        profile = if (msg.userId == userId) profile else if (privateOther?.id == msg.userId) privateOther else members.firstOrNull { it.id == msg.userId },
                        onProfileClick = {
                            if (msg.userId == userId) beginProfileEdit() else task(false) {
                                viewedProfile = if (privateOther?.id == msg.userId) privateOther else members.firstOrNull { it.id == msg.userId } ?: api.profile(accessToken, msg.userId)
                            }
                        },
                        onJoinCall = { kind, name -> requestCall(kind, name, "${kind.uppercase()} CALL · ${privateOther?.displayName ?: "PRIVATE CHAT"}") }
                    ) }
                }
                Composer(draft = privateDraft, onDraft = { privateDraft = it }, hint = "Private message…", busy = busy, onAttach = { showChatAttachments = true }, onSignal = { showSignalDialog = true }, onSend = {
                    val text = privateDraft.trim(); val conv = selectedConversation
                    if (text.isNotBlank() && conv != null) task {
                        api.sendPrivateMessage(accessToken, conv.id, userId, text)
                        privateDraft = ""
                        privateMessages = api.privateMessages(accessToken, conv.id)
                    }
                })
            }
            "call" -> {
                CallScreen(title = callTitle, kind = callKind, roomName = callRoomName, onClose = { page = callReturnPage })
            }
            "shorts" -> {
                if (clips.isEmpty()) {
                    Column(Modifier.weight(1f).fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        Text("VIDEO CLUB", color = Paper, fontWeight = FontWeight.Black, fontSize = 24.sp, letterSpacing = (-.7).sp)
                        Text("Vertical clips · no more than 30 seconds", color = Muted, fontSize = 12.sp)
                        Button(onClick = { videoPicker.launch("video/*") }, colors = ButtonDefaults.buttonColors(containerColor = Paper, contentColor = Ink), shape = RoundedCornerShape(8.dp)) {
                            Icon(Icons.Default.VideoLibrary, contentDescription = "Post a short video")
                            Spacer(Modifier.width(8.dp)); Text("POST THE FIRST CLIP", fontWeight = FontWeight.Black)
                        }
                        CenterState("THE FEED IS QUIET", "Post the first strange little clip. Keep it under 30 seconds.", false, Modifier.weight(1f))
                    }
                } else {
                    val shortsPager = rememberPagerState(pageCount = { clips.size })
                    VerticalPager(state = shortsPager, modifier = Modifier.weight(1f).fillMaxWidth(), pageSpacing = 0.dp) { pageIndex ->
                        val clip = clips[pageIndex]
                        val clipAuthor = members.firstOrNull { it.id == clip.userId }
                        ClipCard(
                            clip = clip,
                            author = clipAuthor,
                            active = shortsPager.currentPage == pageIndex,
                            onAuthorClick = {
                                task(false) { viewedProfile = clipAuthor ?: api.profile(accessToken, clip.userId) }
                            },
                            onLike = {
                                task(false) {
                                    api.toggleLike(accessToken, userId, clip.id, clip.likedByMe)
                                    clips = api.shortClips(accessToken, userId)
                                }
                            },
                            onPost = { videoPicker.launch("video/*") }
                        )
                    }
                }
            }
            "gallery" -> {
                SectionHeading("ART / DIY WALL", "Made by members. Hand-made, half-finished, entirely yours.", action = { imagePicker.launch("image/*") }, actionLabel = "+ ART")
                if (artworks.isEmpty()) CenterState("THE WALL IS WAITING", "Share the first drawing, collage, photo, or work in progress.", false, Modifier.weight(1f))
                else LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 13.dp), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 18.dp)) {
                    items(artworks, key = { it.id }) { art -> ArtworkCard(art) {
                        task(false) { viewedProfile = members.firstOrNull { it.id == art.userId } ?: api.profile(accessToken, art.userId) }
                    } }
                }
            }
            "profile" -> {
                val me = profile
                Column(
                    Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("YOUR PATCH", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Black, letterSpacing = 1.7.sp, modifier = Modifier.weight(1f))
                        TextButton(onClick = { beginProfileEdit() }) { Icon(Icons.Default.Edit, contentDescription = "Edit profile", tint = Stamp, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(5.dp)); Text("EDIT PROFILE", color = Stamp, fontWeight = FontWeight.Black, fontSize = 10.sp) }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        ProfileAvatar(profile = me, size = 100.dp, modifier = Modifier.clickable { beginProfileEdit() }, contextDescription = "Tap to customize your profile picture")
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(me?.displayName ?: "ALTROOM MEMBER", color = Paper, fontSize = 25.sp, fontWeight = FontWeight.Black, lineHeight = 29.sp)
                            Text("@${me?.username ?: "member"}", color = Stamp, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Text("TAP YOUR PHOTO TO CHANGE IT", color = Muted, fontSize = 9.sp, letterSpacing = .5.sp)
                        }
                    }
                    if (!me?.bio.isNullOrBlank()) Text(me?.bio.orEmpty(), color = Paper, fontSize = 14.sp, lineHeight = 21.sp)
                    else Text("Your bio is your little corner of the internet. Add a line about what makes you, you.", color = Muted, fontSize = 13.sp, lineHeight = 19.sp)
                    RuleLine()
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("INTERESTS", color = Muted, fontWeight = FontWeight.Black, fontSize = 10.sp, letterSpacing = 1.4.sp, modifier = Modifier.weight(1f))
                        TextButton(onClick = { beginProfileEdit() }) { Text("＋ ADD / EDIT", color = Stamp, fontSize = 9.sp, fontWeight = FontWeight.Black) }
                    }
                    if (me?.interests.isNullOrEmpty()) Text("No interests added yet.", color = Muted, fontSize = 13.sp)
                    else Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) { me!!.interests.forEach { Tag(it) } }
                    RuleLine()
                    Text("YOUR ALTROOM", color = Paper, fontWeight = FontWeight.Black, fontSize = 12.sp, letterSpacing = .8.sp)
                    Text("A home for odd interests, art, tiny videos, private chats, audio messages, and people who get it.", color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
                    Button(onClick = { signOut() }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Panel2, contentColor = Paper), shape = RoundedCornerShape(9.dp)) {
                        Icon(Icons.Default.Logout, contentDescription = "Sign out"); Spacer(Modifier.width(8.dp)); Text("SIGN OUT", fontWeight = FontWeight.Black, letterSpacing = 1.sp)
                    }
                    Spacer(Modifier.height(8.dp))
                }
            }
            else -> CenterState("ALTROOM", "Returning to the room…", true)
        }

        if (page in listOf("rooms", "private", "shorts", "gallery", "profile")) {
            Divider(color = Rule)
            Row(
                Modifier.fillMaxWidth().background(Panel).padding(horizontal = 6.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(3.dp), verticalAlignment = Alignment.CenterVertically
            ) {
                NavChip("ROOMS", Icons.Default.Forum, tab == "rooms", Modifier.weight(1f)) { switchTab("rooms") }
                NavChip("DMs", Icons.Default.ChatBubbleOutline, tab == "private", Modifier.weight(1f), badge = unreadConversations.isNotEmpty()) { switchTab("private") }
                NavChip("SHORTS", Icons.Default.PlayCircleFilled, tab == "shorts", Modifier.weight(1f)) { switchTab("shorts") }
                NavChip("ART", Icons.Default.Palette, tab == "gallery", Modifier.weight(1f)) { switchTab("gallery") }
                NavChip("ME", Icons.Default.Person, tab == "profile", Modifier.weight(1f)) { switchTab("profile") }
            }
        }
    }

    if (showChatAttachments) {
        AlertDialog(
            onDismissRequest = { showChatAttachments = false },
            containerColor = Panel,
            title = { Text("ADD TO THE CONVERSATION", color = Paper, fontWeight = FontWeight.Black) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Text("Choose a photo or an audio file. Keep media under 6 MB.", color = Muted, fontSize = 12.sp, lineHeight = 17.sp)
                    Button(onClick = { showChatAttachments = false; selectedChatMediaKind = "image"; chatMediaPicker.launch("image/*") }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Panel2, contentColor = Paper), shape = RoundedCornerShape(3.dp)) { Icon(Icons.Default.Image, null); Spacer(Modifier.width(8.dp)); Text("PHOTO / IMAGE") }
                    Button(onClick = { showChatAttachments = false; selectedChatMediaKind = "audio"; chatMediaPicker.launch("audio/*") }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Panel2, contentColor = Paper), shape = RoundedCornerShape(3.dp)) { Icon(Icons.Default.GraphicEq, null); Spacer(Modifier.width(8.dp)); Text("AUDIO FILE") }
                }
            },
            confirmButton = { TextButton(onClick = { showChatAttachments = false }) { Text("DONE", color = Muted) } }
        )
    }

    if (selectedChatMediaUri != null) {
        AlertDialog(
            onDismissRequest = { selectedChatMediaUri = null },
            containerColor = Panel,
            title = { Text(if (selectedChatMediaKind == "image") "SEND IMAGE" else "SEND AUDIO", color = Paper, fontWeight = FontWeight.Black) },
            text = { Text("This file will be sent to ${if (page == "privateThread") "your private conversation" else "the current room"}.", color = Muted, fontSize = 12.sp) },
            confirmButton = { TextButton(enabled = !busy, onClick = {
                val uri = selectedChatMediaUri ?: return@TextButton
                val kind = selectedChatMediaKind
                task {
                    val limit = 6 * 1024 * 1024
                    val bytes = readPickedBytes(context, uri, limit)
                    val mime = context.contentResolver.getType(uri) ?: if (kind == "image") "image/jpeg" else "audio/mpeg"
                    if (kind == "image" && !mime.startsWith("image/")) throw IOException("Choose an image file.")
                    if (kind == "audio" && !mime.startsWith("audio/")) throw IOException("Choose an audio file.")
                    val ext = when (mime) {
                        "image/png" -> "png"; "image/webp" -> "webp"; "image/gif" -> "gif"; "image/avif" -> "avif"
                        "audio/wav", "audio/x-wav" -> "wav"; "audio/ogg" -> "ogg"; "audio/mp4" -> "m4a"; "audio/aac" -> "aac"; "audio/flac" -> "flac"; else -> if (kind == "image") "jpg" else "mp3"
                    }
                    if (page == "room") {
                        val room = selectedRoom ?: throw IOException("Enter a room first.")
                        api.sendRoomMedia(accessToken, room.id, userId, kind, bytes, mime, ext)
                        roomMessages = api.roomMessages(accessToken, room.id)
                    } else if (page == "privateThread") {
                        val conv = selectedConversation ?: throw IOException("Open a private conversation first.")
                        api.sendPrivateMedia(accessToken, conv.id, userId, kind, bytes, mime, ext)
                        privateMessages = api.privateMessages(accessToken, conv.id)
                    } else throw IOException("Open a room or private conversation before attaching media.")
                    selectedChatMediaUri = null
                    infoText = if (kind == "image") "Image sent." else "Audio sent."
                }
            }) { Text(if (busy) "SENDING…" else "SEND FILE →", color = Paper, fontWeight = FontWeight.Black) } },
            dismissButton = { TextButton(onClick = { selectedChatMediaUri = null }) { Text("CANCEL", color = Muted) } }
        )
    }

    if (showProfileEditor) {
        AlertDialog(
            onDismissRequest = { showProfileEditor = false; selectedAvatarUri = null },
            containerColor = Panel,
            title = { Text("CUSTOMIZE YOUR PATCH", color = Paper, fontWeight = FontWeight.Black, fontSize = 17.sp) },
            text = {
                Column(Modifier.fillMaxWidth().heightIn(max = 520.dp).verticalScroll(rememberScrollState()), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(contentAlignment = Alignment.BottomEnd) {
                        if (selectedAvatarUri != null) {
                            AsyncImage(model = selectedAvatarUri, contentDescription = "Selected profile picture", contentScale = ContentScale.Crop, modifier = Modifier.size(94.dp).clip(RoundedCornerShape(50)).clickable { avatarPicker.launch("image/*") })
                        } else {
                            ProfileAvatar(profile = profile, size = 94.dp, modifier = Modifier.clickable { avatarPicker.launch("image/*") }, contextDescription = "Choose profile picture")
                        }
                        Box(Modifier.size(30.dp).background(Stamp, RoundedCornerShape(50)).clickable { avatarPicker.launch("image/*") }, contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.PhotoCamera, contentDescription = "Change profile picture", tint = Paper, modifier = Modifier.size(16.dp))
                        }
                    }
                    Text("TAP PHOTO TO CHANGE", color = Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = .8.sp)
                    AltField("Display name", editDisplayName, { editDisplayName = it })
                    AltField("Bio · what are you into?", editBio, { editBio = it }, singleLine = false)
                    AltField("Interests · comma separated", editInterests, { editInterests = it }, singleLine = false)
                    Text("Your username and account identity stay the same. Interests appear as profile tags.", color = Muted, fontSize = 10.sp, lineHeight = 15.sp)
                }
            },
            confirmButton = {
                TextButton(enabled = !busy, onClick = {
                    val name = editDisplayName.trim()
                    val bio = editBio.trim()
                    val interests = editInterests.split(",", "\n").map { it.trim() }.filter { it.isNotBlank() }.distinct().take(12)
                    if (name.length !in 2..40) { errorText = "Display name must be 2–40 characters."; return@TextButton }
                    if (bio.length > 200) { errorText = "Bio must be 200 characters or fewer."; return@TextButton }
                    if (interests.any { it.length > 24 }) { errorText = "Each interest must be 24 characters or fewer."; return@TextButton }
                    val avatarUri = selectedAvatarUri
                    task {
                        var avatarPath: String? = null
                        if (avatarUri != null) {
                            val bytes = readPickedBytes(context, avatarUri, 4 * 1024 * 1024)
                            val mime = context.contentResolver.getType(avatarUri) ?: "image/jpeg"
                            if (mime !in listOf("image/jpeg", "image/png", "image/webp", "image/gif", "image/avif")) {
                                throw IOException("Choose a JPG, PNG, WebP, GIF, or AVIF image for your profile picture.")
                            }
                            val ext = when (mime) { "image/png" -> "png"; "image/webp" -> "webp"; "image/gif" -> "gif"; "image/avif" -> "avif"; else -> "jpg" }
                            avatarPath = api.uploadProfileAvatar(accessToken, userId, bytes, mime, ext)
                        }
                        api.updateProfile(accessToken, name, bio, interests, avatarPath)
                        profile = api.profile(accessToken, userId)
                        members = api.members(accessToken)
                        selectedAvatarUri = null
                        showProfileEditor = false
                        infoText = "Your profile has been updated. ✳"
                    }
                }) { Text(if (busy) "SAVING…" else "SAVE PROFILE ✓", color = Stamp, fontWeight = FontWeight.Black) }
            },
            dismissButton = { TextButton(onClick = { showProfileEditor = false; selectedAvatarUri = null }) { Text("CANCEL", color = Muted) } }
        )
    }

    if (viewedProfile != null) {
        val member = viewedProfile!!
        AlertDialog(
            onDismissRequest = { viewedProfile = null },
            containerColor = Panel,
            title = { Text("MEMBER PATCH", color = Paper, fontWeight = FontWeight.Black, fontSize = 16.sp) },
            text = {
                Column(Modifier.fillMaxWidth().heightIn(max = 440.dp).verticalScroll(rememberScrollState()), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    ProfileAvatar(profile = member, size = 100.dp, contextDescription = "Member profile picture")
                    Text(member.displayName, color = Paper, fontWeight = FontWeight.Black, fontSize = 23.sp)
                    Text("@${member.username}", color = Stamp, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    if (member.bio.isNotBlank()) Text(member.bio, color = Paper, fontSize = 13.sp, lineHeight = 19.sp)
                    if (member.interests.isNotEmpty()) {
                        Text("INTERESTS", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Black, letterSpacing = 1.2.sp)
                        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) { member.interests.forEach { Tag(it) } }
                    }
                }
            },
            confirmButton = {
                TextButton(enabled = !busy, onClick = {
                    viewedProfile = null
                    task {
                        val id = api.openConversation(accessToken, member.id)
                        if (id.isBlank()) throw IOException("ALTROOM couldn't open that private conversation.")
                        clearUnread(id)
                        selectedConversation = PrivateConversation(id, userId, member.id, "")
                        privateOther = member
                        privateMessages = api.privateMessages(accessToken, id)
                        page = "privateThread"; tab = "private"
                    }
                }) { Icon(Icons.Default.Send, contentDescription = "Message member", tint = Stamp); Spacer(Modifier.width(6.dp)); Text("MESSAGE", color = Stamp, fontWeight = FontWeight.Black) }
            },
            dismissButton = { TextButton(onClick = { viewedProfile = null }) { Text("CLOSE", color = Muted) } }
        )
    }

    if (showRoomSafetyDialog) {
        val room = selectedRoom
        AlertDialog(
            onDismissRequest = { showRoomSafetyDialog = false },
            containerColor = Panel,
            title = { Text(if (canModerateSelectedRoom) "ROOM STEWARD TOOLS" else "ROOM SAFETY DESK", color = Paper, fontWeight = FontWeight.Black) },
            text = {
                Column(Modifier.fillMaxWidth().heightIn(max = 470.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        if (canModerateSelectedRoom) "You're a steward here. Reported or harmful posts can be removed, repeat offenders can be banned from posting, and trusted members can be promoted to co-stewards."
                        else "See something harmful? Report a message so room stewards can review it. Room creators and moderators can remove posts and restrict repeat offenders.",
                        color = Muted, fontSize = 12.sp, lineHeight = 17.sp
                    )
                    if (canModerateSelectedRoom) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("REPORT QUEUE", color = Paper, fontWeight = FontWeight.Black, fontSize = 11.sp, letterSpacing = .7.sp, modifier = Modifier.weight(1f))
                            TextButton(onClick = { val target = room; if (target != null) task(false) { roomReports = api.roomReports(accessToken, target.id) } }) {
                                Text("REFRESH ↻", color = Stamp, fontWeight = FontWeight.Black, fontSize = 9.sp)
                            }
                        }
                        val openReports = roomReports.filter { it.status == "open" }
                        if (openReports.isEmpty()) {
                            Text("No open reports. The room is quiet for now.", color = Muted, fontSize = 11.sp)
                        } else openReports.forEach { report ->
                            Column(Modifier.fillMaxWidth().background(Color(0xFF2B1A18), RoundedCornerShape(10.dp)).border(1.dp, Stamp, RoundedCornerShape(10.dp)).padding(10.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                Text("REPORTED · ${report.senderName}", color = Stamp, fontSize = 10.sp, fontWeight = FontWeight.Black)
                                Text(report.messageBody.take(130), color = Paper, fontSize = 12.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
                                Text("Reason: ${report.reason}", color = Muted, fontSize = 10.sp)
                                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                                    TextButton(enabled = !busy, onClick = {
                                        val target = room ?: return@TextButton
                                        task {
                                            api.deleteRoomMessage(accessToken, target.id, report.messageId)
                                            roomMessages = api.roomMessages(accessToken, target.id)
                                            roomReports = api.roomReports(accessToken, target.id)
                                            infoText = "Reported message removed."
                                        }
                                    }, contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 6.dp, vertical = 3.dp)) { Text("REMOVE", color = Stamp, fontWeight = FontWeight.Black, fontSize = 9.sp) }
                                    TextButton(enabled = !busy && report.reportedUserId.isNotBlank(), onClick = {
                                        val target = room ?: return@TextButton
                                        task {
                                            api.banRoomMember(accessToken, target.id, report.reportedUserId, "Restricted after report review")
                                            api.updateRoomReportStatus(accessToken, target.id, report.id, "actioned")
                                            roomReports = api.roomReports(accessToken, target.id)
                                            infoText = "Member restricted from posting in this room."
                                        }
                                    }, contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 6.dp, vertical = 3.dp)) { Text("RESTRICT", color = Stamp, fontWeight = FontWeight.Black, fontSize = 9.sp) }
                                    TextButton(enabled = !busy, onClick = {
                                        val target = room ?: return@TextButton
                                        task {
                                            api.updateRoomReportStatus(accessToken, target.id, report.id, "reviewed")
                                            roomReports = api.roomReports(accessToken, target.id)
                                        }
                                    }, contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 6.dp, vertical = 3.dp)) { Text("REVIEWED ✓", color = Paper, fontWeight = FontWeight.Black, fontSize = 9.sp) }
                                }
                                TextButton(enabled = !busy, onClick = {
                                    val target = room ?: return@TextButton
                                    task {
                                        api.updateRoomReportStatus(accessToken, target.id, report.id, "dismissed")
                                        roomReports = api.roomReports(accessToken, target.id)
                                    }
                                }, contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 5.dp, vertical = 2.dp)) { Text("DISMISS REPORT", color = Muted, fontWeight = FontWeight.Black, fontSize = 8.sp) }
                            }
                        }
                        Divider(color = Rule, modifier = Modifier.padding(vertical = 4.dp))
                        Text("RECENT ROOM MESSAGES", color = Paper, fontWeight = FontWeight.Black, fontSize = 11.sp, letterSpacing = .7.sp)
                    }
                    if (roomMessages.isEmpty()) Text("No messages to review yet.", color = Muted, fontSize = 12.sp)
                    roomMessages.takeLast(100).asReversed().forEach { msg ->
                        Column(Modifier.fillMaxWidth().background(Panel2, RoundedCornerShape(10.dp)).border(1.dp, Rule, RoundedCornerShape(10.dp)).padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("${msg.displayName}  ·  ${timeLabel(msg.createdAt)}", color = Stamp, fontWeight = FontWeight.Black, fontSize = 10.sp)
                            Text((msg.body.ifBlank { "[${msg.kind} attachment]" }).take(150), color = Paper, fontSize = 12.sp, lineHeight = 16.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                TextButton(enabled = !busy, onClick = {
                                    val target = room ?: return@TextButton
                                    task {
                                        api.reportRoomMessage(accessToken, target.id, msg.id, "Reported by a room member")
                                        infoText = "Report sent to room stewards. Thanks for helping keep this space safe."
                                    }
                                }, contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 7.dp, vertical = 4.dp)) { Text("⚑ REPORT", color = Muted, fontWeight = FontWeight.Black, fontSize = 9.sp) }
                                if (canModerateSelectedRoom && msg.userId != userId) {
                                    TextButton(enabled = !busy, onClick = {
                                        val target = room ?: return@TextButton
                                        task {
                                            api.deleteRoomMessage(accessToken, target.id, msg.id)
                                            roomMessages = api.roomMessages(accessToken, target.id)
                                            infoText = "Message removed from this room."
                                        }
                                    }, contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 7.dp, vertical = 4.dp)) { Text("✕ DELETE", color = Stamp, fontWeight = FontWeight.Black, fontSize = 9.sp) }
                                    TextButton(enabled = !busy && msg.userId.isNotBlank(), onClick = {
                                        val target = room ?: return@TextButton
                                        task {
                                            api.banRoomMember(accessToken, target.id, msg.userId, "Room safety restriction")
                                            infoText = "Member restricted from posting in this room."
                                        }
                                    }, contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 7.dp, vertical = 4.dp)) { Text("⛔ RESTRICT", color = Stamp, fontWeight = FontWeight.Black, fontSize = 9.sp) }
                                    TextButton(enabled = !busy && msg.userId.isNotBlank(), onClick = {
                                        val target = room ?: return@TextButton
                                        task {
                                            api.promoteRoomModerator(accessToken, target.id, msg.userId)
                                            infoText = "Trusted member added as a room co-steward."
                                        }
                                    }, contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 7.dp, vertical = 4.dp)) { Text("✳ MAKE MOD", color = Paper, fontWeight = FontWeight.Black, fontSize = 9.sp) }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showRoomSafetyDialog = false }) { Text("DONE", color = Paper, fontWeight = FontWeight.Black) } }
        )
    }

    if (showSignalDialog) {
        AlertDialog(
            onDismissRequest = { showSignalDialog = false },
            containerColor = Panel,
            title = { Text("DROP A SIGNAL ✳", color = Paper, fontWeight = FontWeight.Black) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("No paragraph needed. Send a tiny ALTROOM signal to the room or private chat.", color = Muted, fontSize = 12.sp, lineHeight = 17.sp)
                    listOf("🖤  SAME FREQUENCY", "⚡  I'M HERE", "🦇  AFTERDARK", "🧷  NEED BACKUP", "👁️  I SEE YOU", "✳  JUST EXISTING").forEach { signal ->
                        TextButton(enabled = !busy, onClick = {
                            showSignalDialog = false
                            task {
                                when (page) {
                                    "room" -> {
                                        val room = selectedRoom ?: throw IOException("Enter a room first.")
                                        api.sendRoomMessage(accessToken, room.id, userId, signal)
                                        roomMessages = api.roomMessages(accessToken, room.id)
                                    }
                                    "privateThread" -> {
                                        val conversation = selectedConversation ?: throw IOException("Open a private chat first.")
                                        api.sendPrivateMessage(accessToken, conversation.id, userId, signal)
                                        privateMessages = api.privateMessages(accessToken, conversation.id)
                                    }
                                }
                            }
                        }, modifier = Modifier.fillMaxWidth().background(Panel2, RoundedCornerShape(9.dp)), contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 10.dp)) {
                            Text(signal, color = Paper, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            },
            dismissButton = { TextButton(onClick = { showSignalDialog = false }) { Text("NOT NOW", color = Muted) } }
        )
    }

    if (showCreateRoomDialog) {
        AlertDialog(
            onDismissRequest = { showCreateRoomDialog = false },
            containerColor = Panel,
            title = { Text("MAKE A ROOM", color = Paper, fontWeight = FontWeight.Black) },
            text = { Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Text("Give your corner a name. Keep it specific, kind, and a little weird.", color = Muted, fontSize = 12.sp, lineHeight = 17.sp)
                AltField("Room name (2–32 characters)", newRoomName, { newRoomName = it })
                AltField("Description (optional)", newRoomDescription, { newRoomDescription = it }, singleLine = false)
            } },
            confirmButton = { TextButton(enabled = !busy, onClick = {
                val name = newRoomName.trim(); val description = newRoomDescription.trim()
                if (name.length !in 2..32) { errorText = "Room names must be 2–32 characters."; return@TextButton }
                task {
                    val createdId = api.createRoom(accessToken, name, description)
                    rooms = api.rooms(accessToken)
                    val created = rooms.firstOrNull { it.id == createdId } ?: rooms.firstOrNull { it.name.equals(name, true) }
                        ?: throw IOException("The room was created, but it did not appear in the room list. Refresh and try again.")
                    api.joinRoom(accessToken, created.id)
                    selectedRoom = created; roomMessages = emptyList(); roomReports = emptyList(); canModerateSelectedRoom = false; page = "room"; tab = "rooms"
                    showCreateRoomDialog = false; infoText = "Room created. You're in."
                }
            }) { Text(if (busy) "CREATING…" else "CREATE ROOM →", color = Paper, fontWeight = FontWeight.Black) } },
            dismissButton = { TextButton(onClick = { showCreateRoomDialog = false }) { Text("CANCEL", color = Muted) } }
        )
    }

    if (selectedVideoUri != null) {
        AlertDialog(
            onDismissRequest = { selectedVideoUri = null },
            containerColor = Panel,
            title = { Text("POST A CLIP", color = Paper, fontWeight = FontWeight.Black) },
            text = { Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Video must be 30 seconds or less and under 18 MB.", color = Muted, fontSize = 12.sp)
                AltField("Caption (optional)", clipCaption, { clipCaption = it }, singleLine = false)
            } },
            confirmButton = { TextButton(enabled = !busy, onClick = {
                val uri = selectedVideoUri ?: return@TextButton
                task {
                    val bytes = readPickedBytes(context, uri, 18 * 1024 * 1024)
                    val duration = videoDurationMs(context, uri)
                    if (duration <= 0) throw IOException("Could not read the clip duration. Try an MP4 file.")
                    if (duration > 30_050) throw IOException("This clip is ${(duration / 1000.0)} seconds. ALTROOM accepts 30 seconds or less.")
                    val mime = context.contentResolver.getType(uri) ?: "video/mp4"
                    val ext = when (mime) { "video/webm" -> "webm"; "video/quicktime" -> "mov"; else -> "mp4" }
                    api.uploadClip(accessToken, userId, clipCaption, bytes, mime, ext)
                    clips = api.shortClips(accessToken, userId)
                    selectedVideoUri = null; infoText = "Your clip was posted to the video club."
                }
            }) { Text(if (busy) "UPLOADING…" else "POST CLIP", color = Paper, fontWeight = FontWeight.Black) } },
            dismissButton = { TextButton(onClick = { selectedVideoUri = null }) { Text("CANCEL", color = Muted) } }
        )
    }

    if (selectedImageUri != null) {
        AlertDialog(
            onDismissRequest = { selectedImageUri = null },
            containerColor = Panel,
            title = { Text("ADD TO THE ART WALL", color = Paper, fontWeight = FontWeight.Black) },
            text = { Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Choose a title. Images must be under 6 MB.", color = Muted, fontSize = 12.sp)
                AltField("Artwork title", artTitle, { artTitle = it })
                AltField("Caption (optional)", artCaption, { artCaption = it }, singleLine = false)
            } },
            confirmButton = { TextButton(enabled = !busy, onClick = {
                val uri = selectedImageUri ?: return@TextButton
                task {
                    if (artTitle.isBlank()) throw IOException("Give your artwork a title.")
                    val bytes = readPickedBytes(context, uri, 6 * 1024 * 1024)
                    val mime = context.contentResolver.getType(uri) ?: "image/jpeg"
                    if (mime !in listOf("image/jpeg", "image/png", "image/webp", "image/gif", "image/avif")) throw IOException("Choose a JPG, PNG, WebP, GIF, or AVIF image.")
                    val ext = when (mime) { "image/png" -> "png"; "image/webp" -> "webp"; "image/gif" -> "gif"; "image/avif" -> "avif"; else -> "jpg" }
                    api.uploadArtwork(accessToken, userId, artTitle, artCaption, bytes, mime, ext)
                    artworks = api.gallery(accessToken)
                    selectedImageUri = null; infoText = "Your artwork was added to the wall."
                }
            }) { Text(if (busy) "UPLOADING…" else "SHARE ART", color = Paper, fontWeight = FontWeight.Black) } },
            dismissButton = { TextButton(onClick = { selectedImageUri = null }) { Text("CANCEL", color = Muted) } }
        )
    }
}

@Composable
private fun AuthScreen(
    mode: String, name: String, onName: (String) -> Unit, email: String, onEmail: (String) -> Unit,
    password: String, onPassword: (String) -> Unit, busy: Boolean, info: String, error: String,
    onMode: (String) -> Unit, onSubmit: () -> Unit
) {
    Column(Modifier.fillMaxSize().background(Ink).padding(horizontal = 23.dp, vertical = 19.dp).imePadding(), verticalArrangement = Arrangement.Center) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(45.dp).background(Paper), contentAlignment = Alignment.Center) { Text("✳", color = Ink, fontSize = 29.sp, fontWeight = FontWeight.Black) }
            Spacer(Modifier.width(12.dp))
            Column { Text("ALTROOM", color = Paper, fontSize = 28.sp, fontWeight = FontWeight.Black, letterSpacing = (-1).sp); Text("NOT BUILT FOR EVERYONE.", color = Muted, fontSize = 9.sp, letterSpacing = 1.4.sp) }
        }
        Spacer(Modifier.height(30.dp))
        Text(if (mode == "login") "COME BACK IN." else "MAKE A LITTLE SPACE.", color = Paper, fontSize = 29.sp, fontWeight = FontWeight.Black, lineHeight = 33.sp)
        Text(if (mode == "login") "Your people are in here." else "A room for the niche, the strange, the handmade.", color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 7.dp, bottom = 19.dp))
        if (mode == "signup") AltField("Display name", name, onName)
        AltField("Email", email, onEmail, keyboardType = KeyboardType.Email)
        AltField("Password", password, onPassword, isPassword = true, keyboardType = KeyboardType.Password, imeAction = ImeAction.Done)
        if (error.isNotBlank()) Text(error, color = Color(0xFFFF9E93), fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))
        if (info.isNotBlank()) Text(info, color = Paper, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))
        Button(onClick = onSubmit, enabled = !busy, modifier = Modifier.fillMaxWidth().padding(top = 13.dp).height(51.dp), shape = RoundedCornerShape(3.dp), colors = ButtonDefaults.buttonColors(containerColor = Paper, contentColor = Ink)) {
            if (busy) CircularProgressIndicator(Modifier.size(19.dp), strokeWidth = 2.dp, color = Ink) else Text(if (mode == "login") "ENTER ALTROOM →" else "CREATE ACCOUNT →", fontWeight = FontWeight.Black, letterSpacing = 1.sp)
        }
        Row(Modifier.fillMaxWidth().padding(top = 13.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
            Text(if (mode == "login") "NEW AROUND HERE?" else "ALREADY HAVE AN ACCOUNT?", color = Muted, fontSize = 10.sp, letterSpacing = .8.sp)
            TextButton(onClick = { onMode(if (mode == "login") "signup" else "login") }) { Text(if (mode == "login") "SIGN UP" else "SIGN IN", color = Paper, fontWeight = FontWeight.Black, fontSize = 11.sp) }
        }
        Spacer(Modifier.height(14.dp))
        Text("COMMUNITY GROWS TO THE LIMITS OF THE PLATFORM · NO APP-IMPOSED 100-MEMBER CAP", color = Rule, fontSize = 8.sp, letterSpacing = .5.sp)
    }
}

@Composable
private fun InviteScreen(code: String, onCode: (String) -> Unit, busy: Boolean, onRedeem: () -> Unit, onSignOut: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(22.dp), verticalArrangement = Arrangement.Center) {
        Text("YOU'RE AT THE DOOR.", color = Paper, fontSize = 30.sp, fontWeight = FontWeight.Black, lineHeight = 34.sp)
        Text("Your people are welcome here. Enter the invite code you were given to unlock community access.", color = Muted, fontSize = 14.sp, lineHeight = 20.sp, modifier = Modifier.padding(top = 12.dp, bottom = 22.dp))
        AltField("Invite code", code, onCode)
        Button(onClick = onRedeem, enabled = !busy, modifier = Modifier.fillMaxWidth().padding(top = 13.dp).height(50.dp), shape = RoundedCornerShape(3.dp), colors = ButtonDefaults.buttonColors(containerColor = Paper, contentColor = Ink)) {
            if (busy) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = Ink) else Text("REDEEM INVITE →", fontWeight = FontWeight.Black, letterSpacing = 1.sp)
        }
        TextButton(onClick = onSignOut, modifier = Modifier.align(Alignment.CenterHorizontally)) { Text("Sign out", color = Muted) }
    }
}

@Composable
private fun SectionHeading(title: String, subtitle: String, action: (() -> Unit)? = null, actionLabel: String = "↻") {
    Row(Modifier.fillMaxWidth().padding(horizontal = 17.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Paper, fontWeight = FontWeight.Black, fontSize = 20.sp, letterSpacing = (-.5).sp)
            Text(subtitle, color = Muted, fontSize = 11.sp, lineHeight = 15.sp, modifier = Modifier.padding(top = 3.dp))
        }
        if (action != null) {
            Spacer(Modifier.width(8.dp))
            Button(onClick = action, colors = ButtonDefaults.buttonColors(containerColor = Panel2, contentColor = Paper), shape = RoundedCornerShape(2.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 11.dp, vertical = 7.dp)) {
                Text(actionLabel, fontSize = 10.sp, fontWeight = FontWeight.Black, letterSpacing = .7.sp)
            }
        }
    }
    Divider(color = Rule)
}

@Composable
private fun RoomCard(room: AltroomRoom, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth()
            .background(Panel, RoundedCornerShape(14.dp))
            .border(1.dp, Rule, RoundedCornerShape(14.dp))
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 15.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(42.dp).background(Ink, RoundedCornerShape(12.dp)).border(1.dp, Rule, RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.Forum, contentDescription = "Community room", tint = Stamp, modifier = Modifier.size(21.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(room.name, color = Paper, fontWeight = FontWeight.Black, fontSize = 15.sp, letterSpacing = .1.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(room.description.ifBlank { "A corner of ALTROOM" }, color = Muted, fontSize = 12.sp, lineHeight = 16.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 4.dp))
        }
        Spacer(Modifier.width(8.dp))
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Enter room", tint = Stamp, modifier = Modifier.size(18.dp).graphicsLayer(rotationZ = 180f))
            Text("ENTER", color = Stamp, fontWeight = FontWeight.Black, fontSize = 8.sp, letterSpacing = .6.sp)
        }
    }
}

@Composable
private fun MessageCard(
    message: AltroomMessage,
    own: Boolean,
    profile: AltroomProfile? = null,
    onProfileClick: (() -> Unit)? = null,
    onJoinCall: (String, String) -> Unit = { _, _ -> }
) {
    val callParts = message.body.split('|')
    val isCallInvite = message.body.startsWith("ALTROOM_CALL|") && callParts.size >= 3 && callParts[2].isNotBlank() && callParts[1] in listOf("audio", "video")
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = if (own) Arrangement.End else Arrangement.Start, verticalAlignment = Alignment.Bottom) {
        if (!own) {
            ProfileAvatar(profile = profile ?: AltroomProfile("", message.username, message.displayName, "", emptyList(), true, "member"), size = 32.dp,
                modifier = if (onProfileClick != null) Modifier.clickable { onProfileClick() } else Modifier,
                contextDescription = "View ${message.displayName}'s profile")
            Spacer(Modifier.width(8.dp))
        }
        val bubbleShape = if (own) RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp, bottomStart = 16.dp, bottomEnd = 4.dp) else RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp, bottomStart = 4.dp, bottomEnd = 16.dp)
        Column(Modifier.fillMaxWidth(if (own) .76f else .82f).animateContentSize().background(if (own) Color(0xFF292720) else Color(0xFF141414), bubbleShape).border(1.dp, if (own) Color(0xFF66584D) else Color(0xFF45443F), bubbleShape).padding(horizontal = 14.dp, vertical = 12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(if (own) "YOU" else message.displayName.uppercase(), color = if (own) Paper else Stamp, fontWeight = FontWeight.Black, fontSize = 10.sp, letterSpacing = .6.sp, modifier = Modifier.weight(1f).let { if (onProfileClick != null) it.clickable { onProfileClick() } else it })
                Text(timeLabel(message.createdAt), color = Muted, fontSize = 9.sp)
            }
            Spacer(Modifier.height(5.dp))
            when {
                isCallInvite -> {
                    val kind = callParts[1]
                    Row(Modifier.fillMaxWidth().background(Ink).border(1.dp, Stamp).clickable { onJoinCall(kind, callParts[2]) }.padding(horizontal = 12.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(if (kind == "video") Icons.Default.Videocam else Icons.Default.Call, null, tint = Stamp)
                        Spacer(Modifier.width(9.dp))
                        Column(Modifier.weight(1f)) {
                            Text("${kind.uppercase()} CALL", color = Paper, fontWeight = FontWeight.Black, fontSize = 12.sp)
                            Text("Tap to join inside ALTROOM", color = Muted, fontSize = 10.sp)
                        }
                        Text("JOIN ↗", color = Stamp, fontWeight = FontWeight.Black, fontSize = 10.sp)
                    }
                }
                message.kind == "sticker" -> Text((message.stickerEmoji + " " + message.stickerText).trim().ifBlank { "Sticker" }, color = Paper, fontSize = 22.sp)
                message.kind == "image" -> {
                    if (message.mediaUrl.isNotBlank()) AsyncImage(model = message.mediaUrl, contentDescription = "Shared image", contentScale = ContentScale.Crop, modifier = Modifier.fillMaxWidth().height(220.dp).clip(RoundedCornerShape(3.dp)).background(Ink))
                    else EmptyCard("IMAGE UNAVAILABLE", "The media link could not be loaded. Refresh the conversation.")
                }
                message.kind == "audio" -> {
                    if (message.mediaUrl.isNotBlank()) AudioMessagePlayer(message.mediaUrl)
                    else EmptyCard("AUDIO UNAVAILABLE", "The audio link could not be loaded. Refresh the conversation.")
                }
                message.kind == "video" -> {
                    if (message.mediaUrl.isNotBlank()) VideoMessagePlayer(message.mediaUrl)
                    else EmptyCard("VIDEO UNAVAILABLE", "The video link could not be loaded. Refresh the conversation.")
                }
                else -> Text(message.body, color = Paper, fontSize = 14.sp, lineHeight = 19.sp)
            }
        }
        if (own) {
            Spacer(Modifier.width(8.dp))
            ProfileAvatar(profile = profile, size = 32.dp, modifier = if (onProfileClick != null) Modifier.clickable { onProfileClick() } else Modifier, contextDescription = "Your profile picture")
        }
    }
}

@Composable
private fun AudioMessagePlayer(url: String) {
    val player = remember(url) { MediaPlayer() }
    var prepared by remember(url) { mutableStateOf(false) }
    var playing by remember(url) { mutableStateOf(false) }
    var failed by remember(url) { mutableStateOf(false) }
    var position by remember(url) { mutableStateOf(0) }
    var duration by remember(url) { mutableStateOf(0) }
    var playbackSpeed by remember(url) { mutableStateOf(1.0f) }
    val context = LocalContext.current

    LaunchedEffect(url) {
        try {
            player.setAudioAttributes(AudioAttributes.Builder().setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            player.setDataSource(url)
            player.setOnPreparedListener { mp -> duration = mp.duration.coerceAtLeast(0); prepared = true }
            player.setOnCompletionListener { playing = false; position = 0; try { it.seekTo(0) } catch (_: Exception) {} }
            player.setOnErrorListener { _, _, _ -> failed = true; playing = false; true }
            player.prepareAsync()
        } catch (_: Exception) { failed = true }
    }
    LaunchedEffect(playing, prepared) {
        while (playing && prepared) {
            try { position = player.currentPosition.coerceAtLeast(0) } catch (_: Exception) { playing = false }
            delay(250)
        }
    }
    DisposableEffect(url) { onDispose { try { player.stop() } catch (_: Exception) {}; try { player.release() } catch (_: Exception) {} } }

    Row(Modifier.fillMaxWidth().background(Ink, RoundedCornerShape(12.dp)).border(1.dp, Rule, RoundedCornerShape(12.dp)).padding(horizontal = 7.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.GraphicEq, contentDescription = "Audio message", tint = Stamp, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(4.dp))
        IconButton(onClick = {
            if (!prepared || failed) return@IconButton
            try { if (playing) { player.pause(); playing = false } else { player.start(); playing = true } } catch (_: Exception) { failed = true }
        }, enabled = prepared && !failed, modifier = Modifier.size(42.dp).background(Panel2, RoundedCornerShape(50))) {
            Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, contentDescription = if (playing) "Pause audio" else "Play audio", tint = Paper)
        }
        Spacer(Modifier.width(7.dp))
        Column(Modifier.weight(1f)) {
            Text(if (failed) "CAN'T PLAY THIS AUDIO" else if (!prepared) "LOADING AUDIO…" else "AUDIO MESSAGE", color = Paper, fontSize = 10.sp, fontWeight = FontWeight.Black, letterSpacing = .6.sp)
            Slider(value = if (duration > 0) position.toFloat().coerceIn(0f, duration.toFloat()) else 0f, onValueChange = { value ->
                position = value.toInt()
                if (prepared) try { player.seekTo(position) } catch (_: Exception) {}
            }, valueRange = 0f..(duration.toFloat().coerceAtLeast(1f)), enabled = prepared && !failed, colors = SliderDefaults.colors(thumbColor = Stamp, activeTrackColor = Stamp, inactiveTrackColor = Rule), modifier = Modifier.height(22.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text("${audioTime(position)} / ${audioTime(duration)}", color = Muted, fontSize = 9.sp)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = {
                        playbackSpeed = when (playbackSpeed) { 1.0f -> 1.25f; 1.25f -> 1.5f; 1.5f -> 2.0f; else -> 1.0f }
                        if (prepared) try { player.playbackParams = player.playbackParams.setSpeed(playbackSpeed) } catch (_: Exception) { }
                    }, enabled = prepared && !failed, contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 5.dp, vertical = 0.dp)) {
                        Icon(Icons.Default.Speed, contentDescription = "Change playback speed", tint = Stamp, modifier = Modifier.size(14.dp))
                        Spacer(Modifier.width(3.dp)); Text("${playbackSpeed}x", color = Stamp, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                    IconButton(onClick = {
                        try {
                            val pathExtension = Uri.parse(url).lastPathSegment.orEmpty().substringAfterLast('.', "mp3").lowercase(Locale.ROOT)
                            val extension = pathExtension.takeIf { it in setOf("mp3", "m4a", "aac", "wav", "ogg", "opus", "flac", "webm") } ?: "mp3"
                            val request = DownloadManager.Request(Uri.parse(url))
                                .setTitle("ALTROOM audio message")
                                .setDescription("Downloading audio message")
                                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "ALTROOM_Audio_${System.currentTimeMillis()}.$extension")
                            (context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
                        } catch (_: Exception) { }
                    }, modifier = Modifier.size(30.dp)) {
                        Icon(Icons.Default.Download, contentDescription = "Download audio message", tint = Paper, modifier = Modifier.size(17.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun VideoMessagePlayer(url: String) {
    AndroidView(
        modifier = Modifier.fillMaxWidth().height(220.dp).background(Color.Black),
        factory = { ctx -> VideoView(ctx).apply {
            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            setMediaController(MediaController(ctx).also { it.setAnchorView(this) })
            setVideoURI(Uri.parse(url))
        } },
        update = { view -> if (view.tag != url) { view.tag = url; view.setVideoURI(Uri.parse(url)) } }
    )
}

@Composable
private fun MemberCard(
    member: AltroomProfile?,
    subtitle: String,
    unread: Boolean = false,
    onProfileClick: (() -> Unit)? = null,
    onClick: () -> Unit
) {
    val name = member?.displayName ?: "ALTROOM member"
    Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(10.dp)).border(1.dp, if (unread) Stamp else Rule, RoundedCornerShape(10.dp)).clickable(onClick = onClick).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
        ProfileAvatar(profile = member, size = 43.dp, modifier = if (onProfileClick != null) Modifier.clickable { onProfileClick() } else Modifier, contextDescription = "View $name profile")
        Spacer(Modifier.width(11.dp))
        Column(Modifier.weight(1f)) {
            Text(name, color = Paper, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text(subtitle, color = if (unread) Stamp else Muted, fontSize = 10.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
        if (unread) Box(Modifier.size(9.dp).background(Stamp, RoundedCornerShape(50)))
        else Text("↗", color = Stamp, fontWeight = FontWeight.Black, fontSize = 15.sp)
    }
}

@Composable
private fun ProfileAvatar(profile: AltroomProfile?, size: androidx.compose.ui.unit.Dp, modifier: Modifier = Modifier, contextDescription: String = "Profile picture") {
    val name = profile?.displayName ?: "ALTROOM member"
    val avatarUrl = profile?.avatarUrl.orEmpty()
    var imageFailed by remember(avatarUrl) { mutableStateOf(false) }
    Box(
        modifier.size(size).clip(RoundedCornerShape(50)).background(Panel2)
            .border(1.dp, Rule, RoundedCornerShape(50)),
        contentAlignment = Alignment.Center
    ) {
        // Keep a legible fallback behind the image so broken/expired URLs never render as an empty circle.
        if (avatarUrl.isBlank() || imageFailed) {
            Text(initials(name), color = Paper, fontWeight = FontWeight.Black, fontSize = (size.value * .29f).sp)
        }
        if (avatarUrl.isNotBlank() && !imageFailed) {
            AsyncImage(
                model = avatarUrl,
                contentDescription = contextDescription,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
                onState = { state -> if (state is AsyncImagePainter.State.Error) imageFailed = true }
            )
        }
    }
}

@Composable
private fun ClipCard(
    clip: ShortClip,
    author: AltroomProfile?,
    active: Boolean,
    onLike: () -> Unit,
    onPost: () -> Unit = {},
    onAuthorClick: () -> Unit = {}
) {
    var muted by remember(clip.id) { mutableStateOf(true) }
    var mediaPlayer by remember(clip.id) { mutableStateOf<MediaPlayer?>(null) }
    Box(Modifier.fillMaxSize().background(Panel).border(1.dp, Rule)) {
        if (clip.mediaUrl.isNotBlank()) {
            AndroidView(
                modifier = Modifier.fillMaxSize().background(Color.Black),
                factory = { ctx ->
                    VideoView(ctx).apply {
                        layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                        tag = clip.mediaUrl
                        setVideoURI(Uri.parse(clip.mediaUrl))
                        setOnPreparedListener { mp ->
                            mediaPlayer = mp
                            mp.isLooping = true
                            mp.setVolume(if (muted) 0f else 1f, if (muted) 0f else 1f)
                            if (active) start() else pause()
                        }
                    }
                },
                update = { view ->
                    if (view.tag != clip.mediaUrl) { view.tag = clip.mediaUrl; view.setVideoURI(Uri.parse(clip.mediaUrl)) }
                    // VideoView owns the MediaPlayer; playback state follows the visible pager page.
                    mediaPlayer?.setVolume(if (muted) 0f else 1f, if (muted) 0f else 1f)
                    if (!active && view.isPlaying) view.pause()
                    else if (active && !view.isPlaying) try { view.start() } catch (_: Exception) {}
                }
            )
        } else Box(Modifier.fillMaxSize().background(Ink), contentAlignment = Alignment.Center) { Text("VIDEO UNAVAILABLE", color = Muted, fontSize = 11.sp) }

        Row(Modifier.align(Alignment.TopStart).fillMaxWidth().background(Color.Transparent).padding(horizontal = 13.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("ALTROOM / VIDEO CLUB", color = Paper, fontWeight = FontWeight.Black, fontSize = 11.sp, letterSpacing = 1.sp)
                Text("CLIP ${dateLabel(clip.createdAt)} · 30 SEC MAX", color = Stamp, fontWeight = FontWeight.Black, fontSize = 9.sp, modifier = Modifier.padding(top = 3.dp))
            }
            IconButton(onClick = onPost, modifier = Modifier.size(37.dp).background(Color(0xBB090909), RoundedCornerShape(50))) {
                Icon(Icons.Default.Add, contentDescription = "Post a new short video", tint = Paper)
            }
        }
        Column(Modifier.align(Alignment.CenterEnd).padding(end = 9.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            IconButton(onClick = { muted = !muted; mediaPlayer?.setVolume(if (muted) 0f else 1f, if (muted) 0f else 1f) }, modifier = Modifier.size(43.dp).background(Color(0xBB090909), RoundedCornerShape(50))) {
                Icon(if (muted) Icons.Default.VolumeOff else Icons.Default.VolumeUp, contentDescription = if (muted) "Turn clip sound on" else "Mute clip", tint = Paper)
            }
            IconButton(onClick = onLike, modifier = Modifier.size(47.dp).background(Color(0xBB090909), RoundedCornerShape(50))) {
                Icon(if (clip.likedByMe) Icons.Default.Favorite else Icons.Default.FavoriteBorder, contentDescription = "Like clip", tint = if (clip.likedByMe) Stamp else Paper)
            }
            Text("${clip.likeCount}", color = Paper, fontWeight = FontWeight.Black, fontSize = 11.sp, modifier = Modifier.padding(top = 2.dp))
        }
        Column(Modifier.align(Alignment.BottomStart).fillMaxWidth().background(Color.Transparent).padding(horizontal = 13.dp, vertical = 13.dp)) {
            Row(
                Modifier.fillMaxWidth().clickable(onClick = onAuthorClick).padding(bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                ProfileAvatar(profile = author, size = 44.dp, modifier = Modifier.clickable(onClick = onAuthorClick), contextDescription = "Tap to view clip creator profile")
                Spacer(Modifier.width(9.dp))
                Column(Modifier.weight(1f)) {
                    Text(author?.displayName ?: "ALTROOM MEMBER", color = Paper, fontSize = 12.sp, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(if (!author?.username.isNullOrBlank()) "@${author?.username}" else "COMMUNITY CREATOR", color = Muted, fontSize = 9.sp)
                }
                Text("VIEW PROFILE ↗", color = Stamp, fontSize = 9.sp, fontWeight = FontWeight.Black)
            }
            if (clip.caption.isNotBlank()) Text(clip.caption, color = Paper, fontSize = 14.sp, lineHeight = 19.sp, maxLines = 4, overflow = TextOverflow.Ellipsis)
            Text("SWIPE UP FOR NEXT · 30 SEC MAX", color = Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = .6.sp, modifier = Modifier.padding(top = 6.dp))
        }
    }
}

@Composable
private fun ArtworkCard(art: AltroomArtwork, onAuthorClick: () -> Unit = {}) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Panel).border(1.dp, Rule, RoundedCornerShape(14.dp))) {
        if (art.imageUrl.isNotBlank()) {
            AsyncImage(model = art.imageUrl, contentDescription = art.title, modifier = Modifier.fillMaxWidth().height(260.dp).background(Color(0xFF111111)))
        } else Box(Modifier.fillMaxWidth().height(180.dp).background(Color(0xFF111111)), contentAlignment = Alignment.Center) { Text("IMAGE UNAVAILABLE", color = Muted, fontSize = 10.sp) }
        Column(Modifier.padding(13.dp)) {
            Text(art.title.uppercase(), color = Paper, fontWeight = FontWeight.Black, fontSize = 16.sp, letterSpacing = .2.sp)
            Text("BY ${art.displayName} · @${art.username}  ↗", color = Stamp, fontWeight = FontWeight.Bold, fontSize = 9.sp, modifier = Modifier.padding(top = 4.dp).clickable(onClick = onAuthorClick))
            if (art.caption.isNotBlank()) Text(art.caption, color = Muted, fontSize = 12.sp, lineHeight = 17.sp, modifier = Modifier.padding(top = 7.dp))
        }
    }
}

@Composable
private fun Composer(draft: String, onDraft: (String) -> Unit, hint: String, busy: Boolean, onAttach: () -> Unit = {}, onSignal: (() -> Unit)? = null, onSend: () -> Unit) {
    Row(Modifier.fillMaxWidth().background(Panel).padding(horizontal = 8.dp, vertical = 7.dp).imePadding().animateContentSize(), verticalAlignment = Alignment.Bottom) {
        if (onSignal != null) {
            IconButton(onClick = onSignal, enabled = !busy, modifier = Modifier.size(40.dp).background(Color(0xFF30251F), RoundedCornerShape(12.dp))) {
                Text("✳", color = Stamp, fontSize = 20.sp, fontWeight = FontWeight.Black)
            }
            Spacer(Modifier.width(5.dp))
        }
        IconButton(onClick = onAttach, enabled = !busy, modifier = Modifier.size(43.dp).background(Panel2, RoundedCornerShape(12.dp))) {
            Icon(Icons.Default.Add, contentDescription = "Attach photo or audio", tint = Paper)
        }
        Spacer(Modifier.width(6.dp))
        OutlinedTextField(
            value = draft, onValueChange = onDraft, modifier = Modifier.weight(1f), placeholder = { Text(hint, color = Muted, fontSize = 12.sp) },
            shape = RoundedCornerShape(12.dp), maxLines = 4, keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
            keyboardActions = KeyboardActions(onSend = { if (!busy) onSend() }),
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Paper, unfocusedBorderColor = Rule, focusedTextColor = Paper, unfocusedTextColor = Paper, cursorColor = Paper, focusedContainerColor = Ink, unfocusedContainerColor = Ink)
        )
        Spacer(Modifier.width(6.dp))
        IconButton(onClick = onSend, enabled = !busy && draft.isNotBlank(), modifier = Modifier.size(43.dp).background(Paper, RoundedCornerShape(12.dp))) {
            Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send message", tint = Ink)
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun CallScreen(title: String, kind: String, roomName: String, onClose: () -> Unit) {
    val context = LocalContext.current
    val webViewRef = remember { mutableStateOf<WebView?>(null) }
    DisposableEffect(Unit) {
        onDispose {
            webViewRef.value?.let { view ->
                try { view.stopLoading() } catch (_: Exception) {}
                try { view.loadUrl("about:blank") } catch (_: Exception) {}
                try { view.destroy() } catch (_: Exception) {}
                webViewRef.value = null
            }
        }
    }
    Column(Modifier.fillMaxSize().background(Ink)) {
        Row(Modifier.fillMaxWidth().background(Panel).padding(horizontal = 13.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, color = Paper, fontSize = 14.sp, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(if (kind == "video") "VIDEO CALL · CAMERA + MIC" else "AUDIO CALL · MIC ONLY", color = Stamp, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = .7.sp, modifier = Modifier.padding(top = 3.dp))
            }
            TextButton(onClick = onClose) { Text("END CALL ✕", color = Paper, fontWeight = FontWeight.Black, fontSize = 10.sp) }
        }
        Box(Modifier.weight(1f).fillMaxWidth().background(Color.Black)) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { ctx ->
                    WebView(ctx).apply {
                        webViewRef.value = this
                        tag = roomName
                        setBackgroundColor(android.graphics.Color.BLACK)
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.mediaPlaybackRequiresUserGesture = false
                        settings.javaScriptCanOpenWindowsAutomatically = true
                        settings.setSupportMultipleWindows(false)
                        val callWebView = this
                        webChromeClient = object : WebChromeClient() {
                            override fun onPermissionRequest(request: PermissionRequest) {
                                callWebView.post {
                                    // Only the configured call provider is allowed to request device media.
                                    if (request.origin.host != "meet.jit.si" || request.origin.scheme != "https") {
                                        request.deny()
                                        return@post
                                    }
                                    val allowedResources = request.resources.filter { resource ->
                                        when (resource) {
                                            PermissionRequest.RESOURCE_AUDIO_CAPTURE -> ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                                            PermissionRequest.RESOURCE_VIDEO_CAPTURE -> ctx.checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
                                            else -> false
                                        }
                                    }
                                    if (allowedResources.isNotEmpty()) request.grant(allowedResources.toTypedArray()) else request.deny()
                                }
                            }
                        }
                        webViewClient = object : WebViewClient() {
                            override fun shouldOverrideUrlLoading(view: WebView, urlRequest: android.webkit.WebResourceRequest): Boolean {
                                val scheme = urlRequest.url.scheme.orEmpty()
                                return scheme != "https" && scheme != "http" && scheme != "about"
                            }
                        }
                        val audioConfig = if (kind == "audio") "&config.startWithVideoMuted=true&config.startWithAudioMuted=false" else "&config.startWithVideoMuted=false&config.startWithAudioMuted=false"
                        loadUrl("https://meet.jit.si/${Uri.encode(roomName)}#config.prejoinConfig.enabled=false$audioConfig")
                    }
                },
                update = { view ->
                    if (view.tag != roomName) {
                        view.tag = roomName
                        val audioConfig = if (kind == "audio") "&config.startWithVideoMuted=true&config.startWithAudioMuted=false" else "&config.startWithVideoMuted=false&config.startWithAudioMuted=false"
                        view.loadUrl("https://meet.jit.si/${Uri.encode(roomName)}#config.prejoinConfig.enabled=false$audioConfig")
                    }
                }
            )
            Column(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(10.dp)
                    .background(Color(0xEE090909), RoundedCornerShape(14.dp))
                    .border(1.dp, Rule, RoundedCornerShape(14.dp))
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                Text("ALTROOM CALL · Free hosted calling", color = Muted, fontSize = 9.sp)
                Text("If the in-app call does not load, open the same room in your browser.", color = Paper, fontSize = 10.sp)
                Button(
                    onClick = {
                        val audioConfig = if (kind == "audio") "&config.startWithVideoMuted=true&config.startWithAudioMuted=false" else "&config.startWithVideoMuted=false&config.startWithAudioMuted=false"
                        val callUrl = "https://meet.jit.si/${Uri.encode(roomName)}#config.prejoinConfig.enabled=false$audioConfig"
                        try {
                            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(callUrl)))
                        } catch (_: Exception) {
                            android.widget.Toast.makeText(context, "No browser is available to open the call.", android.widget.Toast.LENGTH_LONG).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Paper, contentColor = Ink),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 7.dp)
                ) {
                    Icon(if (kind == "video") Icons.Default.Videocam else Icons.Default.Call, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("OPEN CALL IN BROWSER", fontSize = 10.sp, fontWeight = FontWeight.Black)
                }
            }
        }
    }
}

private const val ALTROOM_MESSAGE_CHANNEL = "altroom_private_messages"

/**
 * Background backup for DM notifications. WorkManager may run later than 15 minutes
 * under Android battery restrictions; foreground polling in AltroomApp remains faster.
 */
class AltroomMessageNotificationWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {
    override suspend fun doWork(): Result {
        val prefs = applicationContext.getSharedPreferences("altroom_native_session", Context.MODE_PRIVATE)
        if (prefs.getBoolean("app_is_foreground", false)) return Result.success()
        val token = prefs.getString("access_token", "").orEmpty()
        val userId = prefs.getString("user_id", "").orEmpty()
        if (token.isBlank() || userId.isBlank()) return Result.success()

        return try {
            val api = AltroomApi()
            // Access tokens expire. Refresh in the background so a sleeping app does not
            // silently stop checking for messages after the first hour.
            val recent = try {
                api.recentPrivateMessages(token)
            } catch (_: Exception) {
                val refreshToken = prefs.getString("refresh_token", "").orEmpty()
                if (refreshToken.isBlank()) throw IOException("No refresh token available for background message check.")
                val refreshed = api.refreshSession(refreshToken)
                if (refreshed.accessToken.isBlank() || refreshed.userId != userId) {
                    throw IOException("Background session refresh failed.")
                }
                prefs.edit()
                    .putString("access_token", refreshed.accessToken)
                    .putString("refresh_token", refreshed.refreshToken)
                    .apply()
                api.recentPrivateMessages(refreshed.accessToken)
            }
            val currentIds = recent.map { it.id }.toSet()
            val known = prefs.getStringSet("known_private_message_ids", null)?.toSet()
            if (known == null) {
                prefs.edit().putStringSet("known_private_message_ids", currentIds).apply()
                return Result.success()
            }

            var unread = prefs.getStringSet("unread_conversations", emptySet())?.toSet() ?: emptySet()
            val incoming = recent.filter { it.id !in known && it.userId != userId }.asReversed()
            incoming.forEach { message ->
                unread = unread + message.contextId
                val body = if (message.body.startsWith("ALTROOM_CALL|")) {
                    val callType = message.body.split('|').getOrNull(1)?.takeIf { it in listOf("audio", "video") } ?: "voice"
                    "Started a $callType call. Open ALTROOM to join."
                } else message.body.takeIf { it.isNotBlank() }?.take(120) ?: when (message.kind) {
                    "audio" -> "Sent you an audio message 🎧"
                    "image" -> "Sent you a photo ▧"
                    "video" -> "Sent you a video ▶"
                    else -> "Sent you a message ✉"
                }
                applicationContext.showAltroomMessageNotification(message.contextId.hashCode(), message.displayName, body)
            }
            val updatedKnown = (known + currentIds).toList().takeLast(300).toSet()
            prefs.edit()
                .putStringSet("known_private_message_ids", updatedKnown)
                .putStringSet("unread_conversations", unread)
                .apply()
            Result.success()
        } catch (_: Exception) {
            Result.retry()
        }
    }
}

@Suppress("DEPRECATION")
private fun Context.showAltroomMessageNotification(id: Int, sender: String, message: String) {
    val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
    val intent = Intent(this, MainActivity::class.java).apply {
        flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
    }
    val pendingIntent = PendingIntent.getActivity(
        this, id, intent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
    val notification = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        Notification.Builder(this, ALTROOM_MESSAGE_CHANNEL)
    } else {
        Notification.Builder(this)
    }.setSmallIcon(R.drawable.ic_altroom)
        .setContentTitle("ALTROOM · $sender")
        .setContentText(message)
        .setStyle(Notification.BigTextStyle().bigText(message))
        .setAutoCancel(true)
        .setContentIntent(pendingIntent)
        .build()
    manager.notify(id, notification)
}

private fun audioTime(milliseconds: Int): String {
    val totalSeconds = (milliseconds.coerceAtLeast(0) / 1000)
    return String.format(Locale.getDefault(), "%d:%02d", totalSeconds / 60, totalSeconds % 60)
}

@Composable
private fun AltField(
    label: String, value: String, onValue: (String) -> Unit, singleLine: Boolean = true,
    isPassword: Boolean = false, keyboardType: KeyboardType = KeyboardType.Text, imeAction: ImeAction = ImeAction.Next
) {
    Column(Modifier.fillMaxWidth().padding(bottom = 9.dp)) {
        Text(label.uppercase(), color = Muted, fontSize = 9.sp, fontWeight = FontWeight.Black, letterSpacing = 1.2.sp, modifier = Modifier.padding(bottom = 5.dp))
        OutlinedTextField(
            value = value, onValueChange = onValue, modifier = Modifier.fillMaxWidth(), singleLine = singleLine,
            visualTransformation = if (isPassword) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
            keyboardOptions = KeyboardOptions(keyboardType = keyboardType, imeAction = imeAction),
            shape = RoundedCornerShape(3.dp), minLines = if (singleLine) 1 else 2,
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Paper, unfocusedBorderColor = Rule, focusedTextColor = Paper, unfocusedTextColor = Paper, cursorColor = Paper, focusedContainerColor = Panel, unfocusedContainerColor = Panel, focusedPlaceholderColor = Muted, unfocusedPlaceholderColor = Muted)
        )
    }
}

@Composable
private fun NavChip(
    label: String,
    icon: ImageVector,
    active: Boolean,
    modifier: Modifier = Modifier,
    badge: Boolean = false,
    onClick: () -> Unit
) {
    val chipBackground by animateColorAsState(
        targetValue = if (active) Paper else Color.Transparent,
        animationSpec = tween(durationMillis = 180),
        label = "${label}_nav_background"
    )
    val chipIconColor by animateColorAsState(
        targetValue = if (active) Ink else Paper,
        animationSpec = tween(durationMillis = 180),
        label = "${label}_nav_icon"
    )
    val chipLabelColor by animateColorAsState(
        targetValue = if (active) Ink else Muted,
        animationSpec = tween(durationMillis = 180),
        label = "${label}_nav_label"
    )
    Column(
        modifier
            .animateContentSize()
            .clip(RoundedCornerShape(12.dp))
            .background(chipBackground)
            .clickable(onClick = onClick)
            .padding(horizontal = 2.dp, vertical = 7.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(Modifier.size(24.dp), contentAlignment = Alignment.Center) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = chipIconColor,
                modifier = Modifier.size(20.dp)
            )
            if (badge) {
                Box(
                    Modifier.align(Alignment.TopEnd).size(8.dp)
                        .background(Stamp, RoundedCornerShape(50))
                        .border(1.dp, Panel, RoundedCornerShape(50))
                )
            }
        }
        Text(
            label,
            color = chipLabelColor,
            fontSize = 8.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = .35.sp,
            maxLines = 1,
            softWrap = false,
            modifier = Modifier.padding(top = 2.dp)
        )
    }
}

@Composable
private fun EmptyCard(title: String, body: String) {
    Column(Modifier.fillMaxWidth().background(Panel).border(1.dp, Rule).padding(14.dp)) {
        Text(title, color = Paper, fontWeight = FontWeight.Black, fontSize = 12.sp)
        Text(body, color = Muted, fontSize = 11.sp, lineHeight = 16.sp, modifier = Modifier.padding(top = 4.dp))
    }
}

@Composable
private fun CenterState(title: String, body: String, loading: Boolean, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxWidth().padding(25.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        if (loading) CircularProgressIndicator(color = Paper, strokeWidth = 2.dp, modifier = Modifier.size(26.dp)) else Text("✳", color = Stamp, fontSize = 32.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(15.dp))
        Text(title, color = Paper, fontSize = 17.sp, fontWeight = FontWeight.Black, letterSpacing = .2.sp)
        Text(body, color = Muted, fontSize = 12.sp, lineHeight = 17.sp, modifier = Modifier.padding(top = 7.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
    }
}

@Composable
private fun Tag(text: String) {
    Text(text.uppercase(), Modifier.background(Panel2).border(1.dp, Rule).padding(horizontal = 10.dp, vertical = 7.dp), color = Paper, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = .4.sp)
}

@Composable
private fun RuleLine() { Divider(color = Rule, thickness = 1.dp) }

private fun readableError(e: Exception): String {
    val raw = e.message.orEmpty().removePrefix("java.io.IOException: ")
    return when {
        raw.contains("Invalid login credentials", ignoreCase = true) -> "Email or password is incorrect."
        raw.contains("Email not confirmed", ignoreCase = true) -> "Verify your email first, then sign in."
        raw.contains("Failed to connect", ignoreCase = true) -> "Network connection failed. Check your internet and try again."
        raw.contains("UnknownHostException", ignoreCase = true) -> "Could not reach ALTROOM. Check your internet connection."
        raw.isBlank() -> "Something went wrong. Please try again."
        else -> raw.take(420)
    }
}

private fun timeLabel(value: String): String = try {
    val iso = java.time.Instant.parse(value)
    SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date.from(iso))
} catch (_: Exception) { "" }

private fun dateLabel(value: String): String = try {
    val iso = java.time.Instant.parse(value)
    SimpleDateFormat("MMM d", Locale.getDefault()).format(Date.from(iso)).uppercase(Locale.getDefault())
} catch (_: Exception) { "" }

private fun initials(value: String): String = value.trim().split(Regex("\\s+")).filter { it.isNotBlank() }.take(2).joinToString("") { it.take(1).uppercase(Locale.getDefault()) }.ifBlank { "A" }

private fun readPickedBytes(context: Context, uri: Uri, maxBytes: Int): ByteArray {
    val cursor = context.contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)
    val size = cursor?.use { if (it.moveToFirst()) it.getLong(0) else -1L } ?: -1L
    if (size > maxBytes) throw IOException("The selected file is ${(size / 1024 / 1024)} MB. The limit is ${maxBytes / 1024 / 1024} MB.")
    val bytes = context.contentResolver.openInputStream(uri)?.use { input ->
        val output = java.io.ByteArrayOutputStream()
        val buffer = ByteArray(16 * 1024)
        var total = 0
        while (true) {
            val count = input.read(buffer)
            if (count < 0) break
            total += count
            if (total > maxBytes) throw IOException("The selected file is larger than the ${maxBytes / 1024 / 1024} MB limit.")
            output.write(buffer, 0, count)
        }
        output.toByteArray()
    } ?: throw IOException("Couldn't read the selected file. Try selecting it again.")
    if (bytes.isEmpty()) throw IOException("The selected file is empty.")
    return bytes
}

private fun videoDurationMs(context: Context, uri: Uri): Long {
    val retriever = MediaMetadataRetriever()
    return try {
        retriever.setDataSource(context, uri)
        retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: -1L
    } catch (_: Exception) { -1L } finally { try { retriever.release() } catch (_: Exception) {} }
}
